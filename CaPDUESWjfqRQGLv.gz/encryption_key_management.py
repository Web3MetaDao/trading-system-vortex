"""
企业级数据加密和密钥管理系统
包含 AES 加密、RSA 加密、密钥轮换、密钥备份
"""

import os
import logging
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import json
import hashlib
import hmac

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend


# ============================================================================
# 数据结构
# ============================================================================

class EncryptionAlgorithm(Enum):
    """加密算法"""
    AES_256 = "aes_256"
    RSA_2048 = "rsa_2048"
    FERNET = "fernet"


class KeyStatus(Enum):
    """密钥状态"""
    ACTIVE = "active"
    ROTATING = "rotating"
    RETIRED = "retired"
    COMPROMISED = "compromised"


@dataclass
class EncryptionKey:
    """加密密钥"""
    key_id: str
    algorithm: EncryptionAlgorithm
    key_material: bytes
    status: KeyStatus = KeyStatus.ACTIVE
    created_at: datetime = field(default_factory=datetime.utcnow)
    rotated_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    version: int = 1
    
    def is_expired(self) -> bool:
        """检查密钥是否过期"""
        if self.expires_at is None:
            return False
        return datetime.utcnow() > self.expires_at


@dataclass
class EncryptedData:
    """加密数据"""
    ciphertext: bytes
    key_id: str
    algorithm: EncryptionAlgorithm
    iv: Optional[bytes] = None
    tag: Optional[bytes] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)


# ============================================================================
# 加密管理系统
# ============================================================================

class EncryptionManager:
    """加密管理系统"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.keys: Dict[str, EncryptionKey] = {}
        self.key_rotation_interval = timedelta(days=90)
        self.key_backup_dir = "/secure/key_backups"
    
    def generate_fernet_key(self, key_id: str) -> EncryptionKey:
        """生成 Fernet 密钥"""
        key_material = Fernet.generate_key()
        
        key = EncryptionKey(
            key_id=key_id,
            algorithm=EncryptionAlgorithm.FERNET,
            key_material=key_material,
            expires_at=datetime.utcnow() + self.key_rotation_interval,
        )
        
        self.keys[key_id] = key
        self.logger.info(f"Fernet key generated: {key_id}")
        
        return key
    
    def generate_rsa_key_pair(self, key_id: str, key_size: int = 2048) -> Tuple[EncryptionKey, EncryptionKey]:
        """生成 RSA 密钥对"""
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=key_size,
            backend=default_backend()
        )
        
        private_key_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        public_key_pem = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        private_key_obj = EncryptionKey(
            key_id=f"{key_id}_private",
            algorithm=EncryptionAlgorithm.RSA_2048,
            key_material=private_key_pem,
            expires_at=datetime.utcnow() + self.key_rotation_interval,
        )
        
        public_key_obj = EncryptionKey(
            key_id=f"{key_id}_public",
            algorithm=EncryptionAlgorithm.RSA_2048,
            key_material=public_key_pem,
            expires_at=datetime.utcnow() + self.key_rotation_interval,
        )
        
        self.keys[private_key_obj.key_id] = private_key_obj
        self.keys[public_key_obj.key_id] = public_key_obj
        
        self.logger.info(f"RSA key pair generated: {key_id}")
        
        return private_key_obj, public_key_obj
    
    def encrypt_with_fernet(self, key_id: str, plaintext: str) -> EncryptedData:
        """使用 Fernet 加密"""
        if key_id not in self.keys:
            raise ValueError(f"Key {key_id} not found")
        
        key = self.keys[key_id]
        
        if key.is_expired():
            raise ValueError(f"Key {key_id} is expired")
        
        cipher = Fernet(key.key_material)
        ciphertext = cipher.encrypt(plaintext.encode())
        
        encrypted_data = EncryptedData(
            ciphertext=ciphertext,
            key_id=key_id,
            algorithm=EncryptionAlgorithm.FERNET,
        )
        
        return encrypted_data
    
    def decrypt_with_fernet(self, encrypted_data: EncryptedData) -> str:
        """使用 Fernet 解密"""
        if encrypted_data.key_id not in self.keys:
            raise ValueError(f"Key {encrypted_data.key_id} not found")
        
        key = self.keys[encrypted_data.key_id]
        cipher = Fernet(key.key_material)
        
        plaintext = cipher.decrypt(encrypted_data.ciphertext).decode()
        
        return plaintext
    
    def encrypt_with_rsa(self, key_id: str, plaintext: str) -> EncryptedData:
        """使用 RSA 加密"""
        public_key_id = f"{key_id}_public"
        
        if public_key_id not in self.keys:
            raise ValueError(f"Key {public_key_id} not found")
        
        key = self.keys[public_key_id]
        
        if key.is_expired():
            raise ValueError(f"Key {public_key_id} is expired")
        
        public_key_pem = key.key_material
        public_key = serialization.load_pem_public_key(
            public_key_pem,
            backend=default_backend()
        )
        
        ciphertext = public_key.encrypt(
            plaintext.encode(),
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        
        encrypted_data = EncryptedData(
            ciphertext=ciphertext,
            key_id=key_id,
            algorithm=EncryptionAlgorithm.RSA_2048,
        )
        
        return encrypted_data
    
    def decrypt_with_rsa(self, encrypted_data: EncryptedData) -> str:
        """使用 RSA 解密"""
        private_key_id = f"{encrypted_data.key_id}_private"
        
        if private_key_id not in self.keys:
            raise ValueError(f"Key {private_key_id} not found")
        
        key = self.keys[private_key_id]
        
        private_key_pem = key.key_material
        private_key = serialization.load_pem_private_key(
            private_key_pem,
            password=None,
            backend=default_backend()
        )
        
        plaintext = private_key.decrypt(
            encrypted_data.ciphertext,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        ).decode()
        
        return plaintext


# ============================================================================
# 密钥管理系统
# ============================================================================

class KeyManagementSystem:
    """密钥管理系统"""
    
    def __init__(self, logger: logging.Logger, encryption_manager: EncryptionManager):
        self.logger = logger
        self.encryption_manager = encryption_manager
        self.key_registry: Dict[str, Dict] = {}
        self.key_rotation_history: Dict[str, list] = {}
    
    def register_key(self, key_id: str, key: EncryptionKey, owner: str, purpose: str) -> bool:
        """注册密钥"""
        self.key_registry[key_id] = {
            "key": key,
            "owner": owner,
            "purpose": purpose,
            "registered_at": datetime.utcnow(),
            "access_log": [],
        }
        
        self.logger.info(f"Key registered: {key_id} (owner: {owner}, purpose: {purpose})")
        
        return True
    
    def rotate_key(self, key_id: str) -> bool:
        """轮换密钥"""
        if key_id not in self.encryption_manager.keys:
            raise ValueError(f"Key {key_id} not found")
        
        old_key = self.encryption_manager.keys[key_id]
        
        # 生成新密钥
        if old_key.algorithm == EncryptionAlgorithm.FERNET:
            new_key = self.encryption_manager.generate_fernet_key(f"{key_id}_v{old_key.version + 1}")
        elif old_key.algorithm == EncryptionAlgorithm.RSA_2048:
            new_key, _ = self.encryption_manager.generate_rsa_key_pair(f"{key_id}_v{old_key.version + 1}")
        else:
            raise ValueError(f"Unsupported algorithm: {old_key.algorithm}")
        
        # 更新旧密钥状态
        old_key.status = KeyStatus.RETIRED
        old_key.rotated_at = datetime.utcnow()
        
        # 记录轮换历史
        if key_id not in self.key_rotation_history:
            self.key_rotation_history[key_id] = []
        
        self.key_rotation_history[key_id].append({
            "old_key_id": old_key.key_id,
            "new_key_id": new_key.key_id,
            "rotated_at": datetime.utcnow(),
            "reason": "Scheduled rotation",
        })
        
        self.logger.info(f"Key rotated: {key_id} (old: {old_key.key_id}, new: {new_key.key_id})")
        
        return True
    
    def backup_key(self, key_id: str, backup_dir: str = "/secure/key_backups") -> bool:
        """备份密钥"""
        if key_id not in self.encryption_manager.keys:
            raise ValueError(f"Key {key_id} not found")
        
        key = self.encryption_manager.keys[key_id]
        
        # 创建备份目录
        os.makedirs(backup_dir, exist_ok=True)
        
        # 备份密钥
        backup_file = os.path.join(backup_dir, f"{key_id}_backup_{datetime.utcnow().timestamp()}.json")
        
        backup_data = {
            "key_id": key.key_id,
            "algorithm": key.algorithm.value,
            "key_material": key.key_material.hex(),
            "status": key.status.value,
            "created_at": key.created_at.isoformat(),
            "version": key.version,
            "backup_timestamp": datetime.utcnow().isoformat(),
        }
        
        with open(backup_file, "w") as f:
            json.dump(backup_data, f, indent=2)
        
        # 计算备份文件的哈希
        with open(backup_file, "rb") as f:
            file_hash = hashlib.sha256(f.read()).hexdigest()
        
        self.logger.info(f"Key backed up: {key_id} (file: {backup_file}, hash: {file_hash})")
        
        return True
    
    def restore_key(self, backup_file: str) -> bool:
        """恢复密钥"""
        with open(backup_file, "r") as f:
            backup_data = json.load(f)
        
        key = EncryptionKey(
            key_id=backup_data["key_id"],
            algorithm=EncryptionAlgorithm(backup_data["algorithm"]),
            key_material=bytes.fromhex(backup_data["key_material"]),
            status=KeyStatus(backup_data["status"]),
            created_at=datetime.fromisoformat(backup_data["created_at"]),
            version=backup_data["version"],
        )
        
        self.encryption_manager.keys[key.key_id] = key
        
        self.logger.info(f"Key restored: {key.key_id} (from: {backup_file})")
        
        return True
    
    def log_key_access(self, key_id: str, user_id: str, operation: str, success: bool) -> bool:
        """记录密钥访问"""
        if key_id not in self.key_registry:
            return False
        
        access_log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "user_id": user_id,
            "operation": operation,
            "success": success,
        }
        
        self.key_registry[key_id]["access_log"].append(access_log_entry)
        
        return True
    
    def detect_key_compromise(self, key_id: str) -> bool:
        """检测密钥泄露"""
        if key_id not in self.key_registry:
            return False
        
        key = self.encryption_manager.keys[key_id]
        access_log = self.key_registry[key_id]["access_log"]
        
        # 检查异常访问模式
        recent_accesses = [
            log for log in access_log
            if datetime.fromisoformat(log["timestamp"]) > datetime.utcnow() - timedelta(hours=1)
        ]
        
        # 如果 1 小时内访问超过 100 次，可能是泄露
        if len(recent_accesses) > 100:
            key.status = KeyStatus.COMPROMISED
            self.logger.warning(f"Key compromise detected: {key_id}")
            return True
        
        return False


# ============================================================================
# 主程序
# ============================================================================

def main():
    """主程序"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    # 初始化加密管理系统
    encryption_manager = EncryptionManager(logger)
    
    # 初始化密钥管理系统
    key_management = KeyManagementSystem(logger, encryption_manager)
    
    logger.info("=== Encryption and Key Management System Test ===")
    
    # 1. 生成 Fernet 密钥
    fernet_key = encryption_manager.generate_fernet_key("api_key_encryption")
    key_management.register_key("api_key_encryption", fernet_key, "system", "API key encryption")
    
    # 2. 生成 RSA 密钥对
    rsa_private_key, rsa_public_key = encryption_manager.generate_rsa_key_pair("data_encryption")
    key_management.register_key("data_encryption", rsa_private_key, "system", "Data encryption")
    
    # 3. 加密数据
    plaintext = "super_secret_api_key_12345"
    encrypted_data = encryption_manager.encrypt_with_fernet("api_key_encryption", plaintext)
    logger.info(f"Data encrypted: {encrypted_data.ciphertext[:50]}...")
    
    # 4. 解密数据
    decrypted_data = encryption_manager.decrypt_with_fernet(encrypted_data)
    logger.info(f"Data decrypted: {decrypted_data}")
    
    # 5. 备份密钥
    key_management.backup_key("api_key_encryption")
    
    # 6. 记录密钥访问
    key_management.log_key_access("api_key_encryption", "user_001", "encrypt", True)
    key_management.log_key_access("api_key_encryption", "user_001", "decrypt", True)
    
    # 7. 检测密钥泄露
    is_compromised = key_management.detect_key_compromise("api_key_encryption")
    logger.info(f"Key compromise detected: {is_compromised}")
    
    # 8. 轮换密钥
    key_management.rotate_key("api_key_encryption")
    logger.info("Key rotated successfully")


if __name__ == "__main__":
    main()
