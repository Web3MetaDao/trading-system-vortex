"""
风控优化迭代 - 高级风控规则和实时风险评估
包含高级风控规则、实时风险评估、动态风险调整、异常检测增强
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from decimal import Decimal
import numpy as np


# ============================================================================
# 数据结构
# ============================================================================

class RiskLevel(Enum):
    """风险等级"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class RiskType(Enum):
    """风险类型"""
    POSITION_RISK = "position_risk"
    DRAWDOWN_RISK = "drawdown_risk"
    CONCENTRATION_RISK = "concentration_risk"
    CORRELATION_RISK = "correlation_risk"
    LIQUIDITY_RISK = "liquidity_risk"
    COUNTERPARTY_RISK = "counterparty_risk"
    OPERATIONAL_RISK = "operational_risk"


@dataclass
class RiskIndicator:
    """风险指标"""
    name: str
    value: float
    threshold: float
    risk_level: RiskLevel
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class RiskAssessment:
    """风险评估"""
    symbol: str
    overall_risk_level: RiskLevel
    indicators: List[RiskIndicator]
    recommendations: List[str]
    timestamp: datetime = field(default_factory=datetime.utcnow)


# ============================================================================
# 高级风控规则引擎
# ============================================================================

class AdvancedRiskControlEngine:
    """高级风控规则引擎"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.rules: Dict[str, Dict] = {}
        self._initialize_rules()
    
    def _initialize_rules(self):
        """初始化风控规则"""
        # 头寸风险规则
        self.rules["position_limit"] = {
            "type": "position",
            "single_symbol_limit": 100,
            "total_position_limit": 500,
            "max_leverage": 3,
        }
        
        # 回撤风险规则
        self.rules["drawdown_limit"] = {
            "type": "drawdown",
            "daily_loss_limit": 5000,
            "weekly_loss_limit": 15000,
            "monthly_loss_limit": 50000,
            "max_drawdown_limit": 0.20,
        }
        
        # 集中度风险规则
        self.rules["concentration_limit"] = {
            "type": "concentration",
            "single_symbol_concentration": 0.30,
            "sector_concentration": 0.50,
            "top_5_concentration": 0.70,
        }
        
        # 相关性风险规则
        self.rules["correlation_limit"] = {
            "type": "correlation",
            "max_correlation": 0.80,
            "correlation_window": 30,
        }
        
        # 流动性风险规则
        self.rules["liquidity_limit"] = {
            "type": "liquidity",
            "min_daily_volume": 1000000,
            "max_order_size_ratio": 0.10,
        }
    
    def check_position_risk(self, positions: Dict[str, float]) -> Tuple[RiskLevel, List[str]]:
        """检查头寸风险"""
        recommendations = []
        risk_level = RiskLevel.LOW
        
        limits = self.rules["position_limit"]
        
        # 检查单个标的头寸
        for symbol, position in positions.items():
            if position > limits["single_symbol_limit"]:
                risk_level = RiskLevel.HIGH
                recommendations.append(f"Reduce {symbol} position: {position} > {limits['single_symbol_limit']}")
        
        # 检查总头寸
        total_position = sum(positions.values())
        if total_position > limits["total_position_limit"]:
            risk_level = RiskLevel.CRITICAL
            recommendations.append(f"Reduce total position: {total_position} > {limits['total_position_limit']}")
        
        return risk_level, recommendations
    
    def check_drawdown_risk(self, account_value: float, peak_value: float, 
                           daily_loss: float, weekly_loss: float) -> Tuple[RiskLevel, List[str]]:
        """检查回撤风险"""
        recommendations = []
        risk_level = RiskLevel.LOW
        
        limits = self.rules["drawdown_limit"]
        
        # 检查最大回撤
        drawdown = (peak_value - account_value) / peak_value if peak_value > 0 else 0
        if drawdown > limits["max_drawdown_limit"]:
            risk_level = RiskLevel.HIGH
            recommendations.append(f"Max drawdown exceeded: {drawdown:.2%} > {limits['max_drawdown_limit']:.2%}")
        
        # 检查日度亏损
        if daily_loss > limits["daily_loss_limit"]:
            risk_level = RiskLevel.HIGH
            recommendations.append(f"Daily loss limit exceeded: {daily_loss} > {limits['daily_loss_limit']}")
        
        # 检查周度亏损
        if weekly_loss > limits["weekly_loss_limit"]:
            risk_level = RiskLevel.CRITICAL
            recommendations.append(f"Weekly loss limit exceeded: {weekly_loss} > {limits['weekly_loss_limit']}")
        
        return risk_level, recommendations
    
    def check_concentration_risk(self, positions: Dict[str, float], 
                                total_value: float) -> Tuple[RiskLevel, List[str]]:
        """检查集中度风险"""
        recommendations = []
        risk_level = RiskLevel.LOW
        
        limits = self.rules["concentration_limit"]
        
        # 检查单个标的集中度
        for symbol, position in positions.items():
            concentration = position / total_value if total_value > 0 else 0
            if concentration > limits["single_symbol_concentration"]:
                risk_level = RiskLevel.MEDIUM
                recommendations.append(
                    f"{symbol} concentration too high: {concentration:.2%} > {limits['single_symbol_concentration']:.2%}"
                )
        
        return risk_level, recommendations
    
    def check_correlation_risk(self, correlation_matrix: np.ndarray) -> Tuple[RiskLevel, List[str]]:
        """检查相关性风险"""
        recommendations = []
        risk_level = RiskLevel.LOW
        
        limits = self.rules["correlation_limit"]
        
        # 检查相关性
        high_corr_pairs = []
        for i in range(len(correlation_matrix)):
            for j in range(i + 1, len(correlation_matrix)):
                if correlation_matrix[i][j] > limits["max_correlation"]:
                    high_corr_pairs.append((i, j, correlation_matrix[i][j]))
        
        if high_corr_pairs:
            risk_level = RiskLevel.MEDIUM
            for i, j, corr in high_corr_pairs:
                recommendations.append(f"High correlation between {i} and {j}: {corr:.2f}")
        
        return risk_level, recommendations
    
    def check_liquidity_risk(self, positions: Dict[str, Dict]) -> Tuple[RiskLevel, List[str]]:
        """检查流动性风险"""
        recommendations = []
        risk_level = RiskLevel.LOW
        
        limits = self.rules["liquidity_limit"]
        
        for symbol, pos_data in positions.items():
            daily_volume = pos_data.get("daily_volume", 0)
            position_size = pos_data.get("position_size", 0)
            
            # 检查日成交量
            if daily_volume < limits["min_daily_volume"]:
                risk_level = RiskLevel.MEDIUM
                recommendations.append(f"{symbol} daily volume too low: {daily_volume} < {limits['min_daily_volume']}")
            
            # 检查订单大小占比
            order_size_ratio = position_size / daily_volume if daily_volume > 0 else 0
            if order_size_ratio > limits["max_order_size_ratio"]:
                risk_level = RiskLevel.HIGH
                recommendations.append(
                    f"{symbol} order size ratio too high: {order_size_ratio:.2%} > {limits['max_order_size_ratio']:.2%}"
                )
        
        return risk_level, recommendations


# ============================================================================
# 实时风险评估
# ============================================================================

class RealtimeRiskAssessor:
    """实时风险评估器"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.risk_engine = AdvancedRiskControlEngine(logger)
        self.risk_history: List[RiskAssessment] = []
    
    def assess_risk(self, symbol: str, market_data: Dict, portfolio_data: Dict) -> RiskAssessment:
        """评估风险"""
        indicators = []
        recommendations = []
        risk_levels = []
        
        # 1. 评估头寸风险
        positions = portfolio_data.get("positions", {})
        pos_risk_level, pos_recommendations = self.risk_engine.check_position_risk(positions)
        risk_levels.append(pos_risk_level)
        recommendations.extend(pos_recommendations)
        
        # 2. 评估回撤风险
        account_value = portfolio_data.get("account_value", 100000)
        peak_value = portfolio_data.get("peak_value", 100000)
        daily_loss = portfolio_data.get("daily_loss", 0)
        weekly_loss = portfolio_data.get("weekly_loss", 0)
        
        dd_risk_level, dd_recommendations = self.risk_engine.check_drawdown_risk(
            account_value, peak_value, daily_loss, weekly_loss
        )
        risk_levels.append(dd_risk_level)
        recommendations.extend(dd_recommendations)
        
        # 3. 评估集中度风险
        total_value = sum(positions.values())
        conc_risk_level, conc_recommendations = self.risk_engine.check_concentration_risk(
            positions, total_value
        )
        risk_levels.append(conc_risk_level)
        recommendations.extend(conc_recommendations)
        
        # 4. 评估流动性风险
        positions_data = {
            symbol: {
                "position_size": positions.get(symbol, 0),
                "daily_volume": market_data.get(symbol, {}).get("daily_volume", 0),
            }
            for symbol in positions
        }
        liq_risk_level, liq_recommendations = self.risk_engine.check_liquidity_risk(positions_data)
        risk_levels.append(liq_risk_level)
        recommendations.extend(liq_recommendations)
        
        # 确定总体风险等级
        overall_risk_level = self._determine_overall_risk_level(risk_levels)
        
        assessment = RiskAssessment(
            symbol=symbol,
            overall_risk_level=overall_risk_level,
            indicators=indicators,
            recommendations=recommendations,
        )
        
        self.risk_history.append(assessment)
        
        return assessment
    
    def _determine_overall_risk_level(self, risk_levels: List[RiskLevel]) -> RiskLevel:
        """确定总体风险等级"""
        level_values = {
            RiskLevel.LOW: 1,
            RiskLevel.MEDIUM: 2,
            RiskLevel.HIGH: 3,
            RiskLevel.CRITICAL: 4,
        }
        
        max_level = max(level_values[level] for level in risk_levels)
        
        for level, value in level_values.items():
            if value == max_level:
                return level
        
        return RiskLevel.LOW


# ============================================================================
# 动态风险调整
# ============================================================================

class DynamicRiskAdjuster:
    """动态风险调整器"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.base_limits = {
            "position_limit": 100,
            "daily_loss_limit": 5000,
            "max_drawdown": 0.20,
        }
        self.current_limits = self.base_limits.copy()
        self.adjustment_history: List[Dict] = []
    
    def adjust_limits(self, market_volatility: float, account_performance: str):
        """根据市场条件和账户表现调整风控限制"""
        # 根据波动率调整
        if market_volatility > 0.05:
            # 高波动率：降低限制
            adjustment_factor = 0.7
        elif market_volatility > 0.03:
            # 中等波动率：保持基准
            adjustment_factor = 1.0
        else:
            # 低波动率：提高限制
            adjustment_factor = 1.3
        
        # 根据账户表现调整
        if account_performance == "good":
            adjustment_factor *= 1.2
        elif account_performance == "poor":
            adjustment_factor *= 0.6
        
        # 应用调整
        self.current_limits["position_limit"] = int(self.base_limits["position_limit"] * adjustment_factor)
        self.current_limits["daily_loss_limit"] = int(self.base_limits["daily_loss_limit"] * adjustment_factor)
        self.current_limits["max_drawdown"] = self.base_limits["max_drawdown"] * adjustment_factor
        
        self.adjustment_history.append({
            "timestamp": datetime.utcnow(),
            "market_volatility": market_volatility,
            "account_performance": account_performance,
            "adjustment_factor": adjustment_factor,
            "limits": self.current_limits.copy(),
        })
        
        self.logger.info(f"Risk limits adjusted: {self.current_limits}")
    
    def get_current_limits(self) -> Dict:
        """获取当前限制"""
        return self.current_limits.copy()


# ============================================================================
# 异常检测增强
# ============================================================================

class AnomalyDetectionEnhanced:
    """增强的异常检测"""
    
    def __init__(self, logger: logging.Logger, window_size: int = 30):
        self.logger = logger
        self.window_size = window_size
        self.price_history: Dict[str, List[float]] = {}
        self.volume_history: Dict[str, List[float]] = {}
        self.anomalies: List[Dict] = []
    
    def detect_anomalies(self, symbol: str, price: float, volume: float) -> List[str]:
        """检测异常"""
        anomalies = []
        
        # 初始化历史数据
        if symbol not in self.price_history:
            self.price_history[symbol] = []
            self.volume_history[symbol] = []
        
        # 添加新数据
        self.price_history[symbol].append(price)
        self.volume_history[symbol].append(volume)
        
        # 保持窗口大小
        if len(self.price_history[symbol]) > self.window_size:
            self.price_history[symbol].pop(0)
            self.volume_history[symbol].pop(0)
        
        # 检查价格异常
        if len(self.price_history[symbol]) > 5:
            price_anomaly = self._detect_price_anomaly(symbol)
            if price_anomaly:
                anomalies.append(f"Price anomaly detected for {symbol}: {price_anomaly}")
        
        # 检查成交量异常
        if len(self.volume_history[symbol]) > 5:
            volume_anomaly = self._detect_volume_anomaly(symbol)
            if volume_anomaly:
                anomalies.append(f"Volume anomaly detected for {symbol}: {volume_anomaly}")
        
        return anomalies
    
    def _detect_price_anomaly(self, symbol: str) -> Optional[str]:
        """检测价格异常"""
        prices = self.price_history[symbol]
        
        # 计算统计量
        mean_price = np.mean(prices)
        std_price = np.std(prices)
        
        # 检查最新价格是否超过 3 倍标准差
        latest_price = prices[-1]
        z_score = abs(latest_price - mean_price) / (std_price + 0.001)
        
        if z_score > 3:
            return f"Price z-score: {z_score:.2f}"
        
        return None
    
    def _detect_volume_anomaly(self, symbol: str) -> Optional[str]:
        """检测成交量异常"""
        volumes = self.volume_history[symbol]
        
        # 计算统计量
        mean_volume = np.mean(volumes)
        std_volume = np.std(volumes)
        
        # 检查最新成交量是否超过 3 倍标准差
        latest_volume = volumes[-1]
        z_score = abs(latest_volume - mean_volume) / (std_volume + 0.001)
        
        if z_score > 3:
            return f"Volume z-score: {z_score:.2f}"
        
        return None


# ============================================================================
# 主程序
# ============================================================================

def main():
    """主程序"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    logger.info("=== Risk Control Optimization - Advanced Rules & Real-time Assessment ===")
    
    # 1. 高级风控规则引擎
    logger.info("Testing advanced risk control engine...")
    risk_engine = AdvancedRiskControlEngine(logger)
    
    positions = {"BTCUSDT": 50, "ETHUSDT": 30}
    pos_risk, pos_rec = risk_engine.check_position_risk(positions)
    logger.info(f"Position risk: {pos_risk}, Recommendations: {pos_rec}")
    
    # 2. 实时风险评估
    logger.info("Testing realtime risk assessment...")
    assessor = RealtimeRiskAssessor(logger)
    
    market_data = {
        "BTCUSDT": {"daily_volume": 5000000},
        "ETHUSDT": {"daily_volume": 3000000},
    }
    
    portfolio_data = {
        "positions": positions,
        "account_value": 100000,
        "peak_value": 105000,
        "daily_loss": 1000,
        "weekly_loss": 3000,
    }
    
    assessment = assessor.assess_risk("BTCUSDT", market_data, portfolio_data)
    logger.info(f"Risk assessment: {assessment}")
    
    # 3. 动态风险调整
    logger.info("Testing dynamic risk adjustment...")
    adjuster = DynamicRiskAdjuster(logger)
    adjuster.adjust_limits(0.04, "good")
    logger.info(f"Current limits: {adjuster.get_current_limits()}")
    
    # 4. 异常检测
    logger.info("Testing anomaly detection...")
    detector = AnomalyDetectionEnhanced(logger)
    
    # 模拟价格数据
    prices = [50000 + i * 10 for i in range(30)]
    for price in prices:
        anomalies = detector.detect_anomalies("BTCUSDT", price, 1000000)
        if anomalies:
            logger.warning(f"Anomalies detected: {anomalies}")


if __name__ == "__main__":
    main()
