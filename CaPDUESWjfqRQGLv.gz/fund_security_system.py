"""
企业级资金安全保护系统
包含资金隔离、提现审批、异常检测、对账机制
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from decimal import Decimal
import hashlib
import hmac

# ============================================================================
# 数据结构
# ============================================================================

class AccountType(Enum):
    """账户类型"""
    TRADING = "trading"  # 交易账户
    RESERVE = "reserve"  # 预留账户
    WITHDRAWAL = "withdrawal"  # 提现账户
    SETTLEMENT = "settlement"  # 结算账户


class TransactionType(Enum):
    """交易类型"""
    DEPOSIT = "deposit"  # 入金
    WITHDRAWAL = "withdrawal"  # 出金
    TRANSFER = "transfer"  # 转账
    TRADE = "trade"  # 交易
    FEE = "fee"  # 费用
    DIVIDEND = "dividend"  # 分红


class WithdrawalStatus(Enum):
    """提现状态"""
    PENDING = "pending"  # 待审批
    APPROVED = "approved"  # 已批准
    REJECTED = "rejected"  # 已拒绝
    PROCESSING = "processing"  # 处理中
    COMPLETED = "completed"  # 已完成
    FAILED = "failed"  # 失败


@dataclass
class Account:
    """账户"""
    account_id: str
    account_type: AccountType
    balance: Decimal = Decimal("0")
    available_balance: Decimal = Decimal("0")
    frozen_balance: Decimal = Decimal("0")
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    def __post_init__(self):
        self.available_balance = self.balance - self.frozen_balance


@dataclass
class Transaction:
    """交易记录"""
    transaction_id: str
    account_id: str
    transaction_type: TransactionType
    amount: Decimal
    balance_before: Decimal
    balance_after: Decimal
    description: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    status: str = "completed"
    
    def calculate_hash(self) -> str:
        """计算交易哈希"""
        data = f"{self.transaction_id}{self.account_id}{self.amount}{self.balance_before}{self.balance_after}"
        return hashlib.sha256(data.encode()).hexdigest()


@dataclass
class WithdrawalRequest:
    """提现请求"""
    request_id: str
    account_id: str
    amount: Decimal
    destination_address: str
    reason: str
    status: WithdrawalStatus = WithdrawalStatus.PENDING
    created_at: datetime = field(default_factory=datetime.utcnow)
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None
    rejected_by: Optional[str] = None
    rejection_reason: Optional[str] = None
    completed_at: Optional[datetime] = None
    transaction_hash: Optional[str] = None


# ============================================================================
# 资金隔离系统
# ============================================================================

class FundIsolationManager:
    """资金隔离管理器"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.accounts: Dict[str, Account] = {}
        self.transactions: List[Transaction] = []
        self.transaction_lock = asyncio.Lock()
    
    def create_account(self, account_id: str, account_type: AccountType) -> Account:
        """创建账户"""
        if account_id in self.accounts:
            raise ValueError(f"Account {account_id} already exists")
        
        account = Account(account_id=account_id, account_type=account_type)
        self.accounts[account_id] = account
        self.logger.info(f"Account created: {account_id} ({account_type.value})")
        return account
    
    async def transfer(self, from_account_id: str, to_account_id: str, 
                       amount: Decimal, description: str) -> Transaction:
        """转账"""
        async with self.transaction_lock:
            # 验证账户
            if from_account_id not in self.accounts:
                raise ValueError(f"Source account {from_account_id} not found")
            if to_account_id not in self.accounts:
                raise ValueError(f"Destination account {to_account_id} not found")
            
            from_account = self.accounts[from_account_id]
            to_account = self.accounts[to_account_id]
            
            # 验证余额
            if from_account.available_balance < amount:
                raise ValueError(f"Insufficient balance in {from_account_id}")
            
            # 执行转账
            from_account.balance -= amount
            from_account.available_balance -= amount
            from_account.updated_at = datetime.utcnow()
            
            to_account.balance += amount
            to_account.available_balance += amount
            to_account.updated_at = datetime.utcnow()
            
            # 记录交易
            transaction = Transaction(
                transaction_id=f"TXN_{datetime.utcnow().timestamp()}",
                account_id=from_account_id,
                transaction_type=TransactionType.TRANSFER,
                amount=amount,
                balance_before=from_account.balance + amount,
                balance_after=from_account.balance,
                description=description,
            )
            self.transactions.append(transaction)
            
            self.logger.info(f"Transfer completed: {from_account_id} -> {to_account_id}: {amount}")
            return transaction
    
    async def freeze_balance(self, account_id: str, amount: Decimal, reason: str) -> bool:
        """冻结余额"""
        async with self.transaction_lock:
            if account_id not in self.accounts:
                raise ValueError(f"Account {account_id} not found")
            
            account = self.accounts[account_id]
            
            if account.available_balance < amount:
                self.logger.warning(f"Insufficient available balance to freeze: {account_id}")
                return False
            
            account.frozen_balance += amount
            account.available_balance -= amount
            account.updated_at = datetime.utcnow()
            
            self.logger.info(f"Balance frozen: {account_id}: {amount} ({reason})")
            return True
    
    async def unfreeze_balance(self, account_id: str, amount: Decimal, reason: str) -> bool:
        """解冻余额"""
        async with self.transaction_lock:
            if account_id not in self.accounts:
                raise ValueError(f"Account {account_id} not found")
            
            account = self.accounts[account_id]
            
            if account.frozen_balance < amount:
                self.logger.warning(f"Insufficient frozen balance to unfreeze: {account_id}")
                return False
            
            account.frozen_balance -= amount
            account.available_balance += amount
            account.updated_at = datetime.utcnow()
            
            self.logger.info(f"Balance unfrozen: {account_id}: {amount} ({reason})")
            return True
    
    def get_account_balance(self, account_id: str) -> Dict[str, Decimal]:
        """获取账户余额"""
        if account_id not in self.accounts:
            raise ValueError(f"Account {account_id} not found")
        
        account = self.accounts[account_id]
        return {
            "balance": account.balance,
            "available_balance": account.available_balance,
            "frozen_balance": account.frozen_balance,
        }


# ============================================================================
# 提现审批系统
# ============================================================================

class WithdrawalApprovalSystem:
    """提现审批系统"""
    
    def __init__(self, logger: logging.Logger, fund_manager: FundIsolationManager):
        self.logger = logger
        self.fund_manager = fund_manager
        self.withdrawal_requests: Dict[str, WithdrawalRequest] = {}
        self.approval_rules = {
            "small": {"limit": Decimal("10000"), "approvers": 1},
            "medium": {"limit": Decimal("100000"), "approvers": 2},
            "large": {"limit": Decimal("1000000"), "approvers": 3},
        }
    
    def submit_withdrawal_request(self, account_id: str, amount: Decimal, 
                                  destination_address: str, reason: str) -> WithdrawalRequest:
        """提交提现请求"""
        request_id = f"WDR_{datetime.utcnow().timestamp()}"
        
        request = WithdrawalRequest(
            request_id=request_id,
            account_id=account_id,
            amount=amount,
            destination_address=destination_address,
            reason=reason,
        )
        
        self.withdrawal_requests[request_id] = request
        self.logger.info(f"Withdrawal request submitted: {request_id} ({amount})")
        
        return request
    
    def get_required_approvers(self, amount: Decimal) -> int:
        """获取所需审批人数"""
        if amount <= self.approval_rules["small"]["limit"]:
            return self.approval_rules["small"]["approvers"]
        elif amount <= self.approval_rules["medium"]["limit"]:
            return self.approval_rules["medium"]["approvers"]
        else:
            return self.approval_rules["large"]["approvers"]
    
    async def approve_withdrawal(self, request_id: str, approver_id: str) -> bool:
        """审批提现请求"""
        if request_id not in self.withdrawal_requests:
            raise ValueError(f"Withdrawal request {request_id} not found")
        
        request = self.withdrawal_requests[request_id]
        
        if request.status != WithdrawalStatus.PENDING:
            raise ValueError(f"Withdrawal request {request_id} is not pending")
        
        # 检查是否已经有审批
        if request.approved_by is None:
            request.approved_by = approver_id
            request.approved_at = datetime.utcnow()
            request.status = WithdrawalStatus.APPROVED
            
            self.logger.info(f"Withdrawal request approved: {request_id} by {approver_id}")
            
            # 冻结资金
            await self.fund_manager.freeze_balance(
                request.account_id,
                request.amount,
                f"Withdrawal request {request_id}"
            )
            
            return True
        
        return False
    
    async def reject_withdrawal(self, request_id: str, approver_id: str, reason: str) -> bool:
        """拒绝提现请求"""
        if request_id not in self.withdrawal_requests:
            raise ValueError(f"Withdrawal request {request_id} not found")
        
        request = self.withdrawal_requests[request_id]
        
        if request.status != WithdrawalStatus.PENDING:
            raise ValueError(f"Withdrawal request {request_id} is not pending")
        
        request.status = WithdrawalStatus.REJECTED
        request.rejected_by = approver_id
        request.rejection_reason = reason
        
        self.logger.info(f"Withdrawal request rejected: {request_id} by {approver_id}")
        
        return True
    
    async def process_withdrawal(self, request_id: str) -> bool:
        """处理提现请求"""
        if request_id not in self.withdrawal_requests:
            raise ValueError(f"Withdrawal request {request_id} not found")
        
        request = self.withdrawal_requests[request_id]
        
        if request.status != WithdrawalStatus.APPROVED:
            raise ValueError(f"Withdrawal request {request_id} is not approved")
        
        request.status = WithdrawalStatus.PROCESSING
        
        # 模拟提现处理
        try:
            # 这里应该调用实际的提现接口
            await asyncio.sleep(1)
            
            # 解冻资金
            await self.fund_manager.unfreeze_balance(
                request.account_id,
                request.amount,
                f"Withdrawal processed {request_id}"
            )
            
            # 从账户扣款
            await self.fund_manager.transfer(
                request.account_id,
                "withdrawal_account",
                request.amount,
                f"Withdrawal {request_id}"
            )
            
            request.status = WithdrawalStatus.COMPLETED
            request.completed_at = datetime.utcnow()
            request.transaction_hash = f"TXN_{datetime.utcnow().timestamp()}"
            
            self.logger.info(f"Withdrawal completed: {request_id}")
            return True
        
        except Exception as e:
            request.status = WithdrawalStatus.FAILED
            self.logger.error(f"Withdrawal failed: {request_id}: {e}")
            return False


# ============================================================================
# 异常交易检测系统
# ============================================================================

class AnomalyDetectionSystem:
    """异常交易检测系统"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.transaction_history: List[Transaction] = []
        self.normal_patterns = {
            "max_daily_withdrawal": Decimal("50000"),
            "max_withdrawal_frequency": 3,  # 每天最多 3 次
            "max_single_withdrawal": Decimal("20000"),
            "normal_withdrawal_hours": list(range(8, 18)),  # 8:00 - 18:00
        }
    
    def detect_anomalies(self, withdrawal_request: WithdrawalRequest) -> List[str]:
        """检测异常交易"""
        anomalies = []
        
        # 检查单笔提现金额
        if withdrawal_request.amount > self.normal_patterns["max_single_withdrawal"]:
            anomalies.append(f"Unusual withdrawal amount: {withdrawal_request.amount}")
        
        # 检查每日提现总额
        today_withdrawals = self._get_today_withdrawals(withdrawal_request.account_id)
        today_total = sum(wd.amount for wd in today_withdrawals)
        
        if today_total + withdrawal_request.amount > self.normal_patterns["max_daily_withdrawal"]:
            anomalies.append(f"Daily withdrawal limit exceeded: {today_total + withdrawal_request.amount}")
        
        # 检查提现频率
        if len(today_withdrawals) >= self.normal_patterns["max_withdrawal_frequency"]:
            anomalies.append(f"Withdrawal frequency limit exceeded: {len(today_withdrawals)}")
        
        # 检查提现时间
        current_hour = datetime.utcnow().hour
        if current_hour not in self.normal_patterns["normal_withdrawal_hours"]:
            anomalies.append(f"Unusual withdrawal time: {current_hour}:00")
        
        # 检查提现地址
        if not self._is_whitelisted_address(withdrawal_request.destination_address):
            anomalies.append(f"Withdrawal address not whitelisted: {withdrawal_request.destination_address}")
        
        return anomalies
    
    def _get_today_withdrawals(self, account_id: str) -> List[WithdrawalRequest]:
        """获取今天的提现记录"""
        today = datetime.utcnow().date()
        return [
            txn for txn in self.transaction_history
            if txn.account_id == account_id and txn.created_at.date() == today
        ]
    
    def _is_whitelisted_address(self, address: str) -> bool:
        """检查地址是否在白名单中"""
        # 这里应该从数据库查询白名单
        return True


# ============================================================================
# 对账系统
# ============================================================================

class ReconciliationSystem:
    """对账系统"""
    
    def __init__(self, logger: logging.Logger, fund_manager: FundIsolationManager):
        self.logger = logger
        self.fund_manager = fund_manager
        self.reconciliation_records: List[Dict] = []
    
    async def reconcile_accounts(self) -> Dict[str, any]:
        """对账所有账户"""
        reconciliation_result = {
            "timestamp": datetime.utcnow(),
            "accounts": {},
            "discrepancies": [],
            "status": "success",
        }
        
        for account_id, account in self.fund_manager.accounts.items():
            # 验证余额一致性
            expected_balance = self._calculate_expected_balance(account_id)
            actual_balance = account.balance
            
            if expected_balance != actual_balance:
                discrepancy = {
                    "account_id": account_id,
                    "expected_balance": expected_balance,
                    "actual_balance": actual_balance,
                    "difference": actual_balance - expected_balance,
                }
                reconciliation_result["discrepancies"].append(discrepancy)
                self.logger.warning(f"Balance discrepancy detected: {discrepancy}")
            
            reconciliation_result["accounts"][account_id] = {
                "balance": actual_balance,
                "available_balance": account.available_balance,
                "frozen_balance": account.frozen_balance,
                "status": "matched" if expected_balance == actual_balance else "mismatch",
            }
        
        if reconciliation_result["discrepancies"]:
            reconciliation_result["status"] = "warning"
        
        self.reconciliation_records.append(reconciliation_result)
        self.logger.info(f"Reconciliation completed: {reconciliation_result['status']}")
        
        return reconciliation_result
    
    def _calculate_expected_balance(self, account_id: str) -> Decimal:
        """计算预期余额"""
        # 这里应该根据交易历史计算预期余额
        return Decimal("0")


# ============================================================================
# 主程序
# ============================================================================

async def main():
    """主程序"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    # 初始化资金管理系统
    fund_manager = FundIsolationManager(logger)
    
    # 创建账户
    trading_account = fund_manager.create_account("trading_001", AccountType.TRADING)
    reserve_account = fund_manager.create_account("reserve_001", AccountType.RESERVE)
    withdrawal_account = fund_manager.create_account("withdrawal_001", AccountType.WITHDRAWAL)
    
    # 初始化提现审批系统
    approval_system = WithdrawalApprovalSystem(logger, fund_manager)
    
    # 初始化异常检测系统
    anomaly_detector = AnomalyDetectionSystem(logger)
    
    # 初始化对账系统
    reconciliation_system = ReconciliationSystem(logger, fund_manager)
    
    # 测试流程
    logger.info("=== Fund Security System Test ===")
    
    # 1. 转账到交易账户
    trading_account.balance = Decimal("100000")
    trading_account.available_balance = Decimal("100000")
    logger.info(f"Trading account balance: {trading_account.balance}")
    
    # 2. 提交提现请求
    withdrawal_request = approval_system.submit_withdrawal_request(
        account_id="trading_001",
        amount=Decimal("5000"),
        destination_address="0x1234567890",
        reason="Profit withdrawal"
    )
    logger.info(f"Withdrawal request submitted: {withdrawal_request.request_id}")
    
    # 3. 检测异常
    anomalies = anomaly_detector.detect_anomalies(withdrawal_request)
    if anomalies:
        logger.warning(f"Anomalies detected: {anomalies}")
    else:
        logger.info("No anomalies detected")
    
    # 4. 审批提现
    await approval_system.approve_withdrawal(withdrawal_request.request_id, "approver_001")
    logger.info("Withdrawal request approved")
    
    # 5. 处理提现
    await approval_system.process_withdrawal(withdrawal_request.request_id)
    logger.info("Withdrawal processed")
    
    # 6. 对账
    reconciliation_result = await reconciliation_system.reconcile_accounts()
    logger.info(f"Reconciliation result: {reconciliation_result['status']}")


if __name__ == "__main__":
    asyncio.run(main())
