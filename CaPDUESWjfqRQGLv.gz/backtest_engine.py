#!/usr/bin/env python3
"""
交易系统回测引擎

功能：
1. 历史数据回放
2. 信号生成和执行
3. 风控管理
4. 性能计算
"""

import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, List, Tuple, Optional
from backtest_framework import (
    BacktestConfig, BacktestPortfolio, BacktestMetrics,
    Order, OrderType, OrderStatus, Position
)


class SignalGenerator:
    """信号生成器"""
    
    @staticmethod
    def calculate_ema(data: pd.Series, period: int) -> pd.Series:
        """计算 EMA"""
        return data.ewm(span=period, adjust=False).mean()
    
    @staticmethod
    def calculate_vwap(df: pd.DataFrame, lookback: int = 24) -> pd.Series:
        """计算 VWAP"""
        typical_price = (df['high'] + df['low'] + df['close']) / 3
        vwap = (typical_price * df['volume']).rolling(lookback).sum() / df['volume'].rolling(lookback).sum()
        return vwap
    
    @staticmethod
    def generate_signals(df: pd.DataFrame, config: BacktestConfig) -> pd.DataFrame:
        """生成交易信号"""
        df = df.copy()
        
        # 计算技术指标
        df['ema_fast'] = SignalGenerator.calculate_ema(df['close'], config.ema_fast)
        df['ema_slow'] = SignalGenerator.calculate_ema(df['close'], config.ema_slow)
        df['vwap'] = SignalGenerator.calculate_vwap(df, config.vwap_lookback)
        
        # 生成信号
        df['signal'] = 0
        
        # 买入信号：快线穿越慢线 + 价格在 VWAP 上方
        buy_condition = (df['ema_fast'] > df['ema_slow']) & (df['close'] > df['vwap'])
        df.loc[buy_condition, 'signal'] = 1
        
        # 卖出信号：快线穿越慢线 + 价格在 VWAP 下方
        sell_condition = (df['ema_fast'] < df['ema_slow']) & (df['close'] < df['vwap'])
        df.loc[sell_condition, 'signal'] = -1
        
        return df


class RiskManager:
    """风控管理器"""
    
    def __init__(self, config: BacktestConfig):
        self.config = config
        self.daily_loss = 0.0
        self.consecutive_losses = 0
        self.last_loss_date = None
    
    def check_position_size(self, portfolio: BacktestPortfolio, entry_price: float, quantity: float) -> bool:
        """检查头寸大小是否合规"""
        position_value = entry_price * quantity
        total_value = portfolio.cash + sum(
            pos.quantity * pos.entry_price for pos in portfolio.open_positions.values()
        )
        
        # 检查最大头寸占比
        if position_value > total_value * self.config.max_position_size:
            return False
        
        # 检查最大开放头寸数
        if len(portfolio.open_positions) >= self.config.max_open_positions:
            return False
        
        return True
    
    def check_daily_loss_limit(self, portfolio: BacktestPortfolio, current_date: datetime) -> bool:
        """检查日度亏损限制"""
        # 如果是新的一天，重置日度亏损
        if not portfolio.snapshots or portfolio.snapshots[-1].timestamp.date() != current_date.date():
            self.daily_loss = 0.0
            self.last_loss_date = current_date
        
        # 检查日度亏损限制
        if abs(self.daily_loss) > self.config.daily_loss_limit:
            return False
        
        return True
    
    def check_consecutive_loss_limit(self, portfolio: BacktestPortfolio) -> bool:
        """检查连续亏损限制"""
        if self.consecutive_losses >= self.config.consecutive_loss_limit:
            return False
        
        return True
    
    def update_loss_tracking(self, pnl: float):
        """更新亏损追踪"""
        self.daily_loss += pnl
        
        if pnl < 0:
            self.consecutive_losses += 1
        else:
            self.consecutive_losses = 0


class BacktestEngine:
    """回测引擎"""
    
    def __init__(self, config: BacktestConfig):
        self.config = config
        self.portfolio = BacktestPortfolio(config)
        self.risk_manager = RiskManager(config)
        self.signal_generator = SignalGenerator()
    
    def run_backtest(self, df: pd.DataFrame) -> Dict:
        """运行回测"""
        print("开始回测...")
        
        # 生成信号
        df = self.signal_generator.generate_signals(df, self.config)
        
        # 按时间顺序遍历数据
        for idx, row in df.iterrows():
            timestamp = row['timestamp']
            symbol = row['symbol']
            current_price = row['close']
            signal = row['signal']
            
            # 获取当前价格字典
            current_prices = {symbol: current_price}
            
            # 更新投资组合快照
            self.portfolio.add_snapshot(timestamp, current_prices)
            
            # 检查风控
            if not self.risk_manager.check_daily_loss_limit(self.portfolio, timestamp):
                continue
            
            # 处理现有头寸的止损/止盈
            self._process_existing_positions(symbol, current_price, timestamp)
            
            # 处理新信号
            if signal == 1:  # 买入信号
                self._execute_buy_signal(symbol, current_price, timestamp)
            elif signal == -1:  # 卖出信号
                self._execute_sell_signal(symbol, current_price, timestamp)
        
        # 计算回测指标
        metrics = BacktestMetrics.calculate_metrics(self.portfolio)
        
        print("回测完成！")
        return {
            "portfolio": self.portfolio,
            "metrics": metrics,
            "data": df
        }
    
    def _execute_buy_signal(self, symbol: str, price: float, timestamp: datetime):
        """执行买入信号"""
        # 检查是否已有该标的的头寸
        if symbol in self.portfolio.open_positions:
            return
        
        # 计算头寸大小
        available_capital = self.portfolio.cash * 0.5  # 使用 50% 的可用资金
        quantity = available_capital / price
        
        # 检查风控
        if not self.risk_manager.check_position_size(self.portfolio, price, quantity):
            return
        
        if not self.risk_manager.check_consecutive_loss_limit(self.portfolio):
            return
        
        # 考虑手续费和滑点
        actual_price = price * (1 + self.config.slippage_rate)
        commission = available_capital * self.config.commission_rate
        
        # 创建头寸
        position = Position(
            symbol=symbol,
            entry_time=timestamp,
            entry_price=actual_price,
            quantity=quantity,
            side="long"
        )
        
        # 更新投资组合
        self.portfolio.open_positions[symbol] = position
        self.portfolio.cash -= (available_capital + commission)
        
        # 记录订单
        order = Order(
            order_id=f"{symbol}_{timestamp.timestamp()}",
            timestamp=timestamp,
            symbol=symbol,
            order_type=OrderType.BUY,
            quantity=quantity,
            price=actual_price,
            status=OrderStatus.FILLED,
            filled_price=actual_price,
            filled_quantity=quantity,
            commission=commission
        )
        self.portfolio.orders.append(order)
    
    def _execute_sell_signal(self, symbol: str, price: float, timestamp: datetime):
        """执行卖出信号"""
        # 检查是否有该标的的头寸
        if symbol not in self.portfolio.open_positions:
            return
        
        position = self.portfolio.open_positions[symbol]
        
        # 考虑手续费和滑点
        actual_price = price * (1 - self.config.slippage_rate)
        pnl = (actual_price - position.entry_price) * position.quantity
        commission = pnl * self.config.commission_rate
        
        # 更新头寸
        position.exit_time = timestamp
        position.exit_price = actual_price
        position.pnl = pnl - commission
        position.pnl_pct = (pnl - commission) / (position.entry_price * position.quantity)
        position.holding_days = (timestamp - position.entry_time).days
        
        # 更新投资组合
        self.portfolio.cash += (actual_price * position.quantity - commission)
        del self.portfolio.open_positions[symbol]
        self.portfolio.closed_positions.append(position)
        
        # 更新风控
        self.risk_manager.update_loss_tracking(position.pnl)
        
        # 记录订单
        order = Order(
            order_id=f"{symbol}_{timestamp.timestamp()}_close",
            timestamp=timestamp,
            symbol=symbol,
            order_type=OrderType.SELL,
            quantity=position.quantity,
            price=actual_price,
            status=OrderStatus.FILLED,
            filled_price=actual_price,
            filled_quantity=position.quantity,
            commission=commission
        )
        self.portfolio.orders.append(order)
    
    def _process_existing_positions(self, symbol: str, current_price: float, timestamp: datetime):
        """处理现有头寸的止损/止盈"""
        if symbol not in self.portfolio.open_positions:
            return
        
        position = self.portfolio.open_positions[symbol]
        
        # 计算当前 PnL
        current_pnl_pct = (current_price - position.entry_price) / position.entry_price
        
        # 止盈
        if current_pnl_pct >= self.config.take_profit_pct / 100:
            self._execute_sell_signal(symbol, current_price, timestamp)
            return
        
        # 止损
        if current_pnl_pct <= -self.config.stop_loss_pct / 100:
            self._execute_sell_signal(symbol, current_price, timestamp)
            return


class BacktestAnalyzer:
    """回测分析器"""
    
    @staticmethod
    def analyze_results(backtest_result: Dict) -> Dict:
        """分析回测结果"""
        portfolio = backtest_result['portfolio']
        metrics = backtest_result['metrics']
        data = backtest_result['data']
        
        analysis = {
            "summary": {
                "total_trades": metrics.get('total_trades', 0),
                "winning_trades": metrics.get('winning_trades', 0),
                "losing_trades": metrics.get('losing_trades', 0),
                "win_rate": metrics.get('win_rate', 0),
            },
            "returns": {
                "total_pnl": metrics.get('total_pnl', 0),
                "total_return": metrics.get('total_return', 0),
                "avg_pnl_per_trade": metrics.get('avg_pnl', 0),
            },
            "risk": {
                "max_drawdown": metrics.get('max_drawdown', 0),
                "sharpe_ratio": metrics.get('sharpe_ratio', 0),
                "profit_factor": metrics.get('profit_factor', 0),
            },
            "streaks": {
                "max_consecutive_wins": metrics.get('max_consecutive_wins', 0),
                "max_consecutive_losses": metrics.get('max_consecutive_losses', 0),
            }
        }
        
        return analysis
    
    @staticmethod
    def get_monthly_returns(portfolio: BacktestPortfolio) -> pd.DataFrame:
        """计算月度收益"""
        if not portfolio.snapshots:
            return pd.DataFrame()
        
        snapshots_df = pd.DataFrame([
            {
                'timestamp': s.timestamp,
                'total_value': s.total_value,
                'daily_pnl': s.daily_pnl
            }
            for s in portfolio.snapshots
        ])
        
        snapshots_df['month'] = snapshots_df['timestamp'].dt.to_period('M')
        monthly_returns = snapshots_df.groupby('month')['daily_pnl'].sum()
        
        return monthly_returns
    
    @staticmethod
    def get_drawdown_series(portfolio: BacktestPortfolio) -> pd.Series:
        """计算回撤序列"""
        if not portfolio.snapshots:
            return pd.Series()
        
        values = [s.total_value for s in portfolio.snapshots]
        timestamps = [s.timestamp for s in portfolio.snapshots]
        
        peak = values[0]
        drawdowns = []
        
        for value in values:
            if value > peak:
                peak = value
            dd = (peak - value) / peak if peak > 0 else 0
            drawdowns.append(dd)
        
        return pd.Series(drawdowns, index=timestamps)


# 示例使用
if __name__ == "__main__":
    from backtest_framework import BacktestDataSource
    
    # 创建配置
    config = BacktestConfig()
    
    # 生成示例数据
    data = BacktestDataSource.generate_sample_data("BTCUSDT", days=60)
    
    # 创建回测引擎
    engine = BacktestEngine(config)
    
    # 运行回测
    result = engine.run_backtest(data)
    
    # 分析结果
    analyzer = BacktestAnalyzer()
    analysis = analyzer.analyze_results(result)
    
    print("\n回测结果:")
    import json
    print(json.dumps(analysis, indent=2, ensure_ascii=False))
