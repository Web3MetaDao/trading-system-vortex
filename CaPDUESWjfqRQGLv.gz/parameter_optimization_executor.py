#!/usr/bin/env python3
"""
参数优化执行器和分析工具

功能：
1. 执行参数优化
2. 分析优化结果
3. 生成优化报告
4. 可视化优化过程
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
from typing import Dict, List, Tuple

from backtest_framework import BacktestConfig, BacktestDataSource
from parameter_optimization_framework import (
    ParameterOptimizationFramework,
    TrendFollowingOptimizationConfig,
    HybridOptimizationConfig,
    ScalpingOptimizationConfig
)
from trading_strategies import (
    TrendFollowingStrategy,
    HybridStrategy,
    ScalpingStrategy
)


# 设置中文字体
rcParams['font.sans-serif'] = ['Noto Sans CJK SC', 'DejaVu Sans']
rcParams['axes.unicode_minus'] = False


class ParameterOptimizationExecutor:
    """参数优化执行器"""
    
    @staticmethod
    def optimize_trend_following(
        data: pd.DataFrame,
        metric: str = 'sharpe_ratio',
        method: str = 'grid'
    ) -> Dict:
        """优化趋势跟踪策略"""
        print("\n" + "="*60)
        print("优化趋势跟踪策略")
        print("="*60)
        
        config = BacktestConfig()
        framework = ParameterOptimizationFramework(data, config)
        
        param_ranges = TrendFollowingOptimizationConfig.get_param_ranges()
        
        if method == 'grid':
            best_result = framework.grid_search(
                param_ranges,
                TrendFollowingStrategy,
                metric=metric
            )
        else:
            best_result = framework.random_search(
                param_ranges,
                TrendFollowingStrategy,
                num_iterations=50,
                metric=metric
            )
        
        return {
            'strategy': 'trend_following',
            'framework': framework,
            'best_result': best_result,
            'config': TrendFollowingOptimizationConfig
        }
    
    @staticmethod
    def optimize_hybrid(
        data: pd.DataFrame,
        metric: str = 'sharpe_ratio',
        method: str = 'grid'
    ) -> Dict:
        """优化组合策略"""
        print("\n" + "="*60)
        print("优化组合策略")
        print("="*60)
        
        config = BacktestConfig()
        framework = ParameterOptimizationFramework(data, config)
        
        param_ranges = HybridOptimizationConfig.get_param_ranges()
        
        if method == 'grid':
            best_result = framework.grid_search(
                param_ranges,
                HybridStrategy,
                metric=metric
            )
        else:
            best_result = framework.random_search(
                param_ranges,
                HybridStrategy,
                num_iterations=50,
                metric=metric
            )
        
        return {
            'strategy': 'hybrid',
            'framework': framework,
            'best_result': best_result,
            'config': HybridOptimizationConfig
        }
    
    @staticmethod
    def optimize_scalping(
        data: pd.DataFrame,
        metric: str = 'sharpe_ratio',
        method: str = 'grid'
    ) -> Dict:
        """优化短线交易策略"""
        print("\n" + "="*60)
        print("优化短线交易策略")
        print("="*60)
        
        config = BacktestConfig()
        framework = ParameterOptimizationFramework(data, config)
        
        param_ranges = ScalpingOptimizationConfig.get_param_ranges()
        
        if method == 'grid':
            best_result = framework.grid_search(
                param_ranges,
                ScalpingStrategy,
                metric=metric
            )
        else:
            best_result = framework.random_search(
                param_ranges,
                ScalpingStrategy,
                num_iterations=50,
                metric=metric
            )
        
        return {
            'strategy': 'scalping',
            'framework': framework,
            'best_result': best_result,
            'config': ScalpingOptimizationConfig
        }


class OptimizationAnalyzer:
    """优化结果分析器"""
    
    @staticmethod
    def print_optimization_summary(opt_result: Dict):
        """打印优化摘要"""
        strategy = opt_result['strategy']
        best_result = opt_result['best_result']
        
        print(f"\n{'='*60}")
        print(f"策略: {strategy}")
        print(f"{'='*60}")
        print(f"\n最优参数:")
        for param_name, param_value in best_result.parameters.items():
            print(f"  {param_name}: {param_value:.4f}")
        
        print(f"\n最优指标:")
        for metric_name, metric_value in best_result.metrics.items():
            if isinstance(metric_value, (int, float)):
                print(f"  {metric_name}: {metric_value:.4f}")
    
    @staticmethod
    def get_top_results_table(opt_result: Dict, n: int = 10) -> pd.DataFrame:
        """获取前 N 个最优结果表"""
        framework = opt_result['framework']
        top_results = framework.get_top_results(n)
        
        data = []
        for rank, result in enumerate(top_results, 1):
            row = {
                '排名': rank,
                '指标值': f"{result.metric_value:.4f}",
            }
            for param_name, param_value in result.parameters.items():
                row[param_name] = f"{param_value:.4f}"
            data.append(row)
        
        return pd.DataFrame(data)
    
    @staticmethod
    def analyze_parameter_sensitivity(opt_result: Dict, param_name: str) -> pd.DataFrame:
        """分析参数敏感性"""
        framework = opt_result['framework']
        sensitivity = framework.analyze_parameter_sensitivity(param_name)
        return sensitivity
    
    @staticmethod
    def plot_optimization_surface(
        opt_result: Dict,
        param1_name: str,
        param2_name: str,
        output_path: str = "optimization_surface.png"
    ):
        """绘制优化曲面"""
        framework = opt_result['framework']
        df = framework.get_results_dataframe()
        
        # 检查参数是否存在
        if param1_name not in df.columns or param2_name not in df.columns:
            print(f"参数 {param1_name} 或 {param2_name} 不存在")
            return
        
        # 创建透视表
        pivot = df.pivot_table(
            values='metric_value',
            index=param2_name,
            columns=param1_name,
            aggfunc='mean'
        )
        
        # 绘制热力图
        fig, ax = plt.subplots(figsize=(12, 8))
        im = ax.imshow(pivot.values, cmap='RdYlGn', aspect='auto')
        
        ax.set_xticks(range(len(pivot.columns)))
        ax.set_yticks(range(len(pivot.index)))
        ax.set_xticklabels([f"{v:.2f}" for v in pivot.columns], rotation=45)
        ax.set_yticklabels([f"{v:.2f}" for v in pivot.index])
        ax.set_xlabel(param1_name, fontsize=12)
        ax.set_ylabel(param2_name, fontsize=12)
        ax.set_title(f'参数优化曲面: {param1_name} vs {param2_name}', fontsize=14, fontweight='bold')
        
        # 添加颜色条
        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label('指标值', fontsize=11)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 优化曲面已保存: {output_path}")
    
    @staticmethod
    def plot_parameter_sensitivity(
        opt_result: Dict,
        param_name: str,
        output_path: str = "parameter_sensitivity.png"
    ):
        """绘制参数敏感性"""
        sensitivity = OptimizationAnalyzer.analyze_parameter_sensitivity(opt_result, param_name)
        
        fig, ax = plt.subplots(figsize=(12, 6))
        
        # 绘制平均值和标准差
        ax.errorbar(
            range(len(sensitivity)),
            sensitivity['mean'],
            yerr=sensitivity['std'],
            marker='o',
            linewidth=2,
            markersize=8,
            capsize=5,
            label='平均值 ± 标准差'
        )
        
        # 绘制最大最小值
        ax.fill_between(
            range(len(sensitivity)),
            sensitivity['min'],
            sensitivity['max'],
            alpha=0.2,
            label='最大值 - 最小值'
        )
        
        ax.set_xticks(range(len(sensitivity)))
        ax.set_xticklabels([f"{v:.2f}" for v in sensitivity.index], rotation=45)
        ax.set_xlabel(param_name, fontsize=12)
        ax.set_ylabel('指标值', fontsize=12)
        ax.set_title(f'参数敏感性分析: {param_name}', fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3)
        ax.legend()
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 参数敏感性图已保存: {output_path}")
    
    @staticmethod
    def plot_optimization_convergence(
        opt_result: Dict,
        output_path: str = "optimization_convergence.png"
    ):
        """绘制优化收敛过程"""
        framework = opt_result['framework']
        df = framework.get_results_dataframe()
        
        # 计算累计最优值
        df['cumulative_best'] = df['metric_value'].cummax()
        
        fig, ax = plt.subplots(figsize=(12, 6))
        
        # 绘制所有点
        ax.scatter(range(len(df)), df['metric_value'], alpha=0.5, s=30, label='所有结果')
        
        # 绘制累计最优值
        ax.plot(range(len(df)), df['cumulative_best'], linewidth=2, color='red', label='累计最优值')
        
        ax.set_xlabel('迭代次数', fontsize=12)
        ax.set_ylabel('指标值', fontsize=12)
        ax.set_title('优化收敛过程', fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3)
        ax.legend()
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 收敛过程图已保存: {output_path}")


# 示例使用
if __name__ == "__main__":
    # 生成数据
    print("生成测试数据...")
    data = BacktestDataSource.generate_sample_data("BTCUSDT", days=120)
    
    # 优化趋势跟踪策略
    tf_result = ParameterOptimizationExecutor.optimize_trend_following(data, metric='sharpe_ratio')
    OptimizationAnalyzer.print_optimization_summary(tf_result)
    
    # 显示前 10 个结果
    print("\n前 10 个最优结果:")
    top_results = OptimizationAnalyzer.get_top_results_table(tf_result, n=10)
    print(top_results.to_string(index=False))
    
    # 分析参数敏感性
    print("\nEMA 快线参数敏感性:")
    sensitivity = OptimizationAnalyzer.analyze_parameter_sensitivity(tf_result, 'ema_fast')
    print(sensitivity)
    
    print("\n✓ 优化完成！")
