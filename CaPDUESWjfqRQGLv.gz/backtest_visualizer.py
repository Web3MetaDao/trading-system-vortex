#!/usr/bin/env python3
"""
回测可视化和参数优化

功能：
1. 生成回测报告图表
2. 参数网格搜索
3. 参数优化分析
"""

import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib import rcParams
from datetime import datetime
from typing import Dict, List, Tuple
from backtest_framework import BacktestConfig, BacktestDataSource
from backtest_engine import BacktestEngine, BacktestAnalyzer


# 设置中文字体
rcParams['font.sans-serif'] = ['Noto Sans CJK SC', 'DejaVu Sans']
rcParams['axes.unicode_minus'] = False


class BacktestVisualizer:
    """回测可视化"""
    
    @staticmethod
    def plot_equity_curve(portfolio, output_path: str = "equity_curve.png"):
        """绘制权益曲线"""
        if not portfolio.snapshots:
            return
        
        timestamps = [s.timestamp for s in portfolio.snapshots]
        values = [s.total_value for s in portfolio.snapshots]
        
        fig, ax = plt.subplots(figsize=(14, 6))
        ax.plot(timestamps, values, linewidth=2, color='#1f77b4', label='权益')
        ax.fill_between(timestamps, values, alpha=0.3, color='#1f77b4')
        
        ax.set_xlabel('时间', fontsize=12)
        ax.set_ylabel('账户价值 (USDT)', fontsize=12)
        ax.set_title('权益曲线', fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3)
        ax.legend()
        
        # 格式化 x 轴
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        ax.xaxis.set_major_locator(mdates.AutoDateLocator())
        plt.xticks(rotation=45)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 权益曲线已保存: {output_path}")
    
    @staticmethod
    def plot_drawdown(portfolio, output_path: str = "drawdown.png"):
        """绘制回撤图"""
        if not portfolio.snapshots:
            return
        
        timestamps = [s.timestamp for s in portfolio.snapshots]
        values = [s.total_value for s in portfolio.snapshots]
        
        peak = values[0]
        drawdowns = []
        
        for value in values:
            if value > peak:
                peak = value
            dd = (peak - value) / peak * 100 if peak > 0 else 0
            drawdowns.append(dd)
        
        fig, ax = plt.subplots(figsize=(14, 6))
        ax.fill_between(timestamps, drawdowns, alpha=0.5, color='#d62728', label='回撤')
        ax.plot(timestamps, drawdowns, linewidth=2, color='#d62728')
        
        ax.set_xlabel('时间', fontsize=12)
        ax.set_ylabel('回撤 (%)', fontsize=12)
        ax.set_title('最大回撤', fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3)
        ax.legend()
        
        # 格式化 x 轴
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        ax.xaxis.set_major_locator(mdates.AutoDateLocator())
        plt.xticks(rotation=45)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 回撤图已保存: {output_path}")
    
    @staticmethod
    def plot_monthly_returns(portfolio, output_path: str = "monthly_returns.png"):
        """绘制月度收益"""
        analyzer = BacktestAnalyzer()
        monthly_returns = analyzer.get_monthly_returns(portfolio)
        
        if monthly_returns.empty:
            return
        
        fig, ax = plt.subplots(figsize=(12, 6))
        
        colors = ['#2ca02c' if x > 0 else '#d62728' for x in monthly_returns.values]
        ax.bar(range(len(monthly_returns)), monthly_returns.values, color=colors, alpha=0.7)
        
        ax.set_xlabel('月份', fontsize=12)
        ax.set_ylabel('月度收益 (USDT)', fontsize=12)
        ax.set_title('月度收益分布', fontsize=14, fontweight='bold')
        ax.set_xticks(range(len(monthly_returns)))
        ax.set_xticklabels([str(m) for m in monthly_returns.index], rotation=45)
        ax.grid(True, alpha=0.3, axis='y')
        ax.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 月度收益图已保存: {output_path}")
    
    @staticmethod
    def plot_trade_distribution(portfolio, output_path: str = "trade_distribution.png"):
        """绘制交易分布"""
        if not portfolio.closed_positions:
            return
        
        pnls = [p.pnl for p in portfolio.closed_positions]
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
        
        # 直方图
        ax1.hist(pnls, bins=20, color='#1f77b4', alpha=0.7, edgecolor='black')
        ax1.set_xlabel('PnL (USDT)', fontsize=12)
        ax1.set_ylabel('频数', fontsize=12)
        ax1.set_title('交易 PnL 分布', fontsize=14, fontweight='bold')
        ax1.axvline(x=0, color='red', linestyle='--', linewidth=2)
        ax1.grid(True, alpha=0.3, axis='y')
        
        # 累积分布
        sorted_pnls = sorted(pnls)
        cumulative = np.cumsum(sorted_pnls)
        ax2.plot(range(len(sorted_pnls)), cumulative, linewidth=2, color='#2ca02c')
        ax2.fill_between(range(len(sorted_pnls)), cumulative, alpha=0.3, color='#2ca02c')
        ax2.set_xlabel('交易序号', fontsize=12)
        ax2.set_ylabel('累积 PnL (USDT)', fontsize=12)
        ax2.set_title('累积 PnL', fontsize=14, fontweight='bold')
        ax2.grid(True, alpha=0.3)
        ax2.axhline(y=0, color='red', linestyle='--', linewidth=1)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 交易分布图已保存: {output_path}")
    
    @staticmethod
    def plot_performance_metrics(metrics: Dict, output_path: str = "performance_metrics.png"):
        """绘制性能指标"""
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # 准备数据
        metric_names = [
            '胜率(%)',
            '夏普比率',
            '利润因子',
            '最大回撤(%)'
        ]
        
        metric_values = [
            metrics.get('win_rate', 0),
            metrics.get('sharpe_ratio', 0) * 10,  # 放大 10 倍便于显示
            metrics.get('profit_factor', 0),
            abs(metrics.get('max_drawdown', 0))
        ]
        
        # 归一化到 0-100
        max_val = max(metric_values) if max(metric_values) > 0 else 1
        normalized_values = [v / max_val * 100 for v in metric_values]
        
        colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
        bars = ax.barh(metric_names, normalized_values, color=colors, alpha=0.7)
        
        # 添加数值标签
        for i, (bar, value) in enumerate(zip(bars, metric_values)):
            ax.text(bar.get_width() + 2, bar.get_y() + bar.get_height()/2,
                   f'{value:.2f}', va='center', fontsize=10)
        
        ax.set_xlabel('相对值', fontsize=12)
        ax.set_title('性能指标对比', fontsize=14, fontweight='bold')
        ax.set_xlim(0, 120)
        ax.grid(True, alpha=0.3, axis='x')
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 性能指标图已保存: {output_path}")


class ParameterOptimizer:
    """参数优化器"""
    
    @staticmethod
    def grid_search(
        data: pd.DataFrame,
        param_grid: Dict[str, List],
        metric: str = 'total_return'
    ) -> Tuple[Dict, List[Dict]]:
        """网格搜索最优参数"""
        
        print(f"\n开始网格搜索 ({metric})...")
        
        results = []
        best_params = None
        best_value = -float('inf')
        
        # 生成所有参数组合
        param_combinations = ParameterOptimizer._generate_combinations(param_grid)
        total_combinations = len(param_combinations)
        
        for idx, params in enumerate(param_combinations):
            # 创建配置
            config = BacktestConfig()
            for key, value in params.items():
                if hasattr(config, key):
                    setattr(config, key, value)
            
            # 运行回测
            engine = BacktestEngine(config)
            result = engine.run_backtest(data)
            metrics = result['metrics']
            
            # 获取指标值
            metric_value = metrics.get(metric, 0)
            
            # 记录结果
            result_dict = {
                'params': params,
                'metrics': metrics,
                'metric_value': metric_value
            }
            results.append(result_dict)
            
            # 更新最优参数
            if metric_value > best_value:
                best_value = metric_value
                best_params = params
            
            # 进度输出
            if (idx + 1) % max(1, total_combinations // 10) == 0:
                print(f"  进度: {idx + 1}/{total_combinations} ({(idx + 1) / total_combinations * 100:.1f}%)")
        
        print(f"✓ 网格搜索完成！最优值: {best_value:.4f}")
        
        return best_params, results
    
    @staticmethod
    def _generate_combinations(param_grid: Dict[str, List]) -> List[Dict]:
        """生成参数组合"""
        import itertools
        
        keys = param_grid.keys()
        values = param_grid.values()
        
        combinations = []
        for combination in itertools.product(*values):
            combinations.append(dict(zip(keys, combination)))
        
        return combinations
    
    @staticmethod
    def plot_optimization_results(results: List[Dict], metric: str, output_path: str = "optimization_results.png"):
        """绘制优化结果"""
        
        # 提取数据
        param_names = list(results[0]['params'].keys())
        metric_values = [r['metric_value'] for r in results]
        
        if len(param_names) == 1:
            # 单参数优化
            param_values = [r['params'][param_names[0]] for r in results]
            
            fig, ax = plt.subplots(figsize=(12, 6))
            ax.plot(param_values, metric_values, marker='o', linewidth=2, markersize=8, color='#1f77b4')
            ax.set_xlabel(param_names[0], fontsize=12)
            ax.set_ylabel(metric, fontsize=12)
            ax.set_title(f'参数优化结果 - {metric}', fontsize=14, fontweight='bold')
            ax.grid(True, alpha=0.3)
            
            # 标记最优点
            best_idx = np.argmax(metric_values)
            ax.plot(param_values[best_idx], metric_values[best_idx], 'r*', markersize=20, label='最优')
            ax.legend()
        
        elif len(param_names) == 2:
            # 双参数优化
            param1_name = param_names[0]
            param2_name = param_names[1]
            
            # 构建矩阵
            param1_values = sorted(set(r['params'][param1_name] for r in results))
            param2_values = sorted(set(r['params'][param2_name] for r in results))
            
            matrix = np.zeros((len(param2_values), len(param1_values)))
            
            for r in results:
                i = param1_values.index(r['params'][param1_name])
                j = param2_values.index(r['params'][param2_name])
                matrix[j, i] = r['metric_value']
            
            fig, ax = plt.subplots(figsize=(10, 8))
            im = ax.imshow(matrix, cmap='RdYlGn', aspect='auto')
            
            ax.set_xticks(range(len(param1_values)))
            ax.set_yticks(range(len(param2_values)))
            ax.set_xticklabels(param1_values)
            ax.set_yticklabels(param2_values)
            ax.set_xlabel(param1_name, fontsize=12)
            ax.set_ylabel(param2_name, fontsize=12)
            ax.set_title(f'参数优化热力图 - {metric}', fontsize=14, fontweight='bold')
            
            # 添加颜色条
            cbar = plt.colorbar(im, ax=ax)
            cbar.set_label(metric, fontsize=12)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 优化结果图已保存: {output_path}")


# 示例使用
if __name__ == "__main__":
    # 生成示例数据
    data = BacktestDataSource.generate_sample_data("BTCUSDT", days=60)
    
    # 创建配置和引擎
    config = BacktestConfig()
    engine = BacktestEngine(config)
    
    # 运行回测
    result = engine.run_backtest(data)
    portfolio = result['portfolio']
    metrics = result['metrics']
    
    # 生成可视化
    visualizer = BacktestVisualizer()
    visualizer.plot_equity_curve(portfolio, "results/equity_curve.png")
    visualizer.plot_drawdown(portfolio, "results/drawdown.png")
    visualizer.plot_monthly_returns(portfolio, "results/monthly_returns.png")
    visualizer.plot_trade_distribution(portfolio, "results/trade_distribution.png")
    visualizer.plot_performance_metrics(metrics, "results/performance_metrics.png")
    
    print("\n✓ 所有可视化已生成")
