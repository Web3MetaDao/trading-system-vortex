"""
运维优化迭代 - 自动化运维和智能监控
包含自动化部署、智能监控、自动告警、故障自愈
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
import threading
import time


# ============================================================================
# 数据结构
# ============================================================================

class AlertSeverity(Enum):
    """告警严重等级"""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


class ServiceStatus(Enum):
    """服务状态"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


@dataclass
class HealthCheck:
    """健康检查"""
    service_name: str
    status: ServiceStatus
    response_time_ms: float
    error_message: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class Alert:
    """告警"""
    alert_id: str
    severity: AlertSeverity
    service_name: str
    message: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    acknowledged: bool = False
    resolved: bool = False


@dataclass
class MetricPoint:
    """指标数据点"""
    metric_name: str
    value: float
    timestamp: datetime = field(default_factory=datetime.utcnow)
    tags: Dict[str, str] = field(default_factory=dict)


# ============================================================================
# 健康检查系统
# ============================================================================

class HealthCheckSystem:
    """健康检查系统"""
    
    def __init__(self, logger: logging.Logger, check_interval: int = 10):
        self.logger = logger
        self.check_interval = check_interval
        self.services: Dict[str, Dict] = {}
        self.health_history: List[HealthCheck] = []
        self.running = False
    
    def register_service(self, service_name: str, check_func: Callable):
        """注册服务"""
        self.services[service_name] = {
            "check_func": check_func,
            "last_check": None,
            "consecutive_failures": 0,
            "status": ServiceStatus.HEALTHY,
        }
        self.logger.info(f"Service {service_name} registered for health check")
    
    def start(self):
        """启动健康检查"""
        self.running = True
        thread = threading.Thread(target=self._check_loop, daemon=True)
        thread.start()
        self.logger.info("Health check system started")
    
    def stop(self):
        """停止健康检查"""
        self.running = False
        self.logger.info("Health check system stopped")
    
    def _check_loop(self):
        """检查循环"""
        while self.running:
            for service_name, service_info in self.services.items():
                self._check_service(service_name, service_info)
            
            time.sleep(self.check_interval)
    
    def _check_service(self, service_name: str, service_info: Dict):
        """检查单个服务"""
        try:
            start_time = time.time()
            check_func = service_info["check_func"]
            
            # 执行检查
            result = check_func()
            
            response_time = (time.time() - start_time) * 1000
            
            if result:
                status = ServiceStatus.HEALTHY
                error_message = None
                service_info["consecutive_failures"] = 0
            else:
                status = ServiceStatus.UNHEALTHY
                error_message = "Check failed"
                service_info["consecutive_failures"] += 1
            
            # 如果连续失败超过 3 次，标记为不健康
            if service_info["consecutive_failures"] > 3:
                status = ServiceStatus.UNHEALTHY
            
            service_info["status"] = status
            service_info["last_check"] = datetime.utcnow()
            
            # 记录健康检查
            health_check = HealthCheck(
                service_name=service_name,
                status=status,
                response_time_ms=response_time,
                error_message=error_message,
            )
            self.health_history.append(health_check)
        
        except Exception as e:
            self.logger.error(f"Error checking service {service_name}: {e}")
            service_info["consecutive_failures"] += 1
    
    def get_service_status(self, service_name: str) -> Optional[ServiceStatus]:
        """获取服务状态"""
        if service_name in self.services:
            return self.services[service_name]["status"]
        return None
    
    def get_all_statuses(self) -> Dict[str, ServiceStatus]:
        """获取所有服务状态"""
        return {
            name: info["status"]
            for name, info in self.services.items()
        }


# ============================================================================
# 智能监控系统
# ============================================================================

class IntelligentMonitoringSystem:
    """智能监控系统"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.metrics: Dict[str, List[MetricPoint]] = {}
        self.thresholds: Dict[str, Dict] = {}
        self.anomaly_detector = AnomalyDetector(logger)
    
    def register_metric(self, metric_name: str, threshold: Dict):
        """注册指标"""
        self.metrics[metric_name] = []
        self.thresholds[metric_name] = threshold
        self.logger.info(f"Metric {metric_name} registered")
    
    def record_metric(self, metric_point: MetricPoint):
        """记录指标"""
        if metric_point.metric_name not in self.metrics:
            self.metrics[metric_point.metric_name] = []
        
        self.metrics[metric_point.metric_name].append(metric_point)
        
        # 保持最近 1000 个数据点
        if len(self.metrics[metric_point.metric_name]) > 1000:
            self.metrics[metric_point.metric_name].pop(0)
    
    def check_thresholds(self, metric_name: str) -> Optional[Alert]:
        """检查阈值"""
        if metric_name not in self.metrics:
            return None
        
        metric_points = self.metrics[metric_name]
        if not metric_points:
            return None
        
        latest_value = metric_points[-1].value
        threshold = self.thresholds.get(metric_name, {})
        
        # 检查上限
        if "upper_limit" in threshold and latest_value > threshold["upper_limit"]:
            alert = Alert(
                alert_id=f"ALERT_{metric_name}_{int(time.time())}",
                severity=AlertSeverity.CRITICAL,
                service_name=metric_name,
                message=f"{metric_name} exceeded upper limit: {latest_value} > {threshold['upper_limit']}",
            )
            return alert
        
        # 检查下限
        if "lower_limit" in threshold and latest_value < threshold["lower_limit"]:
            alert = Alert(
                alert_id=f"ALERT_{metric_name}_{int(time.time())}",
                severity=AlertSeverity.WARNING,
                service_name=metric_name,
                message=f"{metric_name} below lower limit: {latest_value} < {threshold['lower_limit']}",
            )
            return alert
        
        return None
    
    def detect_anomalies(self, metric_name: str) -> List[Alert]:
        """检测异常"""
        if metric_name not in self.metrics:
            return []
        
        metric_points = self.metrics[metric_name]
        if len(metric_points) < 10:
            return []
        
        # 获取最近 100 个数据点
        recent_points = metric_points[-100:]
        values = [p.value for p in recent_points]
        
        # 检测异常
        anomalies = self.anomaly_detector.detect(values)
        
        alerts = []
        for anomaly_idx in anomalies:
            if anomaly_idx < len(recent_points):
                point = recent_points[anomaly_idx]
                alert = Alert(
                    alert_id=f"ANOMALY_{metric_name}_{int(time.time())}",
                    severity=AlertSeverity.WARNING,
                    service_name=metric_name,
                    message=f"Anomaly detected in {metric_name}: {point.value}",
                )
                alerts.append(alert)
        
        return alerts


# ============================================================================
# 异常检测器
# ============================================================================

class AnomalyDetector:
    """异常检测器"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
    
    def detect(self, values: List[float], threshold: float = 2.5) -> List[int]:
        """检测异常"""
        if len(values) < 5:
            return []
        
        import numpy as np
        
        values_array = np.array(values)
        mean = np.mean(values_array)
        std = np.std(values_array)
        
        # 使用 Z-score 检测异常
        z_scores = np.abs((values_array - mean) / (std + 0.001))
        anomalies = np.where(z_scores > threshold)[0]
        
        return anomalies.tolist()


# ============================================================================
# 自动告警系统
# ============================================================================

class AutomatedAlertingSystem:
    """自动告警系统"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.alerts: Dict[str, Alert] = {}
        self.alert_handlers: Dict[AlertSeverity, List[Callable]] = {
            AlertSeverity.INFO: [],
            AlertSeverity.WARNING: [],
            AlertSeverity.CRITICAL: [],
        }
    
    def register_alert_handler(self, severity: AlertSeverity, handler: Callable):
        """注册告警处理器"""
        self.alert_handlers[severity].append(handler)
        self.logger.info(f"Alert handler registered for {severity.value}")
    
    def send_alert(self, alert: Alert):
        """发送告警"""
        self.alerts[alert.alert_id] = alert
        
        # 调用相应的处理器
        handlers = self.alert_handlers.get(alert.severity, [])
        for handler in handlers:
            try:
                handler(alert)
            except Exception as e:
                self.logger.error(f"Error handling alert: {e}")
    
    def acknowledge_alert(self, alert_id: str):
        """确认告警"""
        if alert_id in self.alerts:
            self.alerts[alert_id].acknowledged = True
            self.logger.info(f"Alert {alert_id} acknowledged")
    
    def resolve_alert(self, alert_id: str):
        """解决告警"""
        if alert_id in self.alerts:
            self.alerts[alert_id].resolved = True
            self.logger.info(f"Alert {alert_id} resolved")
    
    def get_active_alerts(self) -> List[Alert]:
        """获取活跃告警"""
        return [
            alert for alert in self.alerts.values()
            if not alert.resolved
        ]


# ============================================================================
# 故障自愈系统
# ============================================================================

class FaultSelfHealingSystem:
    """故障自愈系统"""
    
    def __init__(self, logger: logging.Logger, health_check_system: HealthCheckSystem):
        self.logger = logger
        self.health_check_system = health_check_system
        self.healing_actions: Dict[str, Callable] = {}
        self.healing_history: List[Dict] = []
    
    def register_healing_action(self, service_name: str, action: Callable):
        """注册自愈动作"""
        self.healing_actions[service_name] = action
        self.logger.info(f"Healing action registered for {service_name}")
    
    def start_healing(self):
        """启动自愈"""
        thread = threading.Thread(target=self._healing_loop, daemon=True)
        thread.start()
        self.logger.info("Fault self-healing system started")
    
    def _healing_loop(self):
        """自愈循环"""
        while True:
            # 检查所有服务状态
            statuses = self.health_check_system.get_all_statuses()
            
            for service_name, status in statuses.items():
                if status == ServiceStatus.UNHEALTHY:
                    self._try_heal(service_name)
            
            time.sleep(30)
    
    def _try_heal(self, service_name: str):
        """尝试自愈"""
        if service_name not in self.healing_actions:
            self.logger.warning(f"No healing action for {service_name}")
            return
        
        try:
            self.logger.info(f"Attempting to heal {service_name}...")
            action = self.healing_actions[service_name]
            action()
            
            self.healing_history.append({
                "service_name": service_name,
                "timestamp": datetime.utcnow(),
                "status": "success",
            })
            
            self.logger.info(f"Successfully healed {service_name}")
        
        except Exception as e:
            self.logger.error(f"Failed to heal {service_name}: {e}")
            
            self.healing_history.append({
                "service_name": service_name,
                "timestamp": datetime.utcnow(),
                "status": "failed",
                "error": str(e),
            })


# ============================================================================
# 主程序
# ============================================================================

def main():
    """主程序"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    logger.info("=== Operations Optimization - Automation & Intelligent Monitoring ===")
    
    # 1. 健康检查系统
    logger.info("Testing health check system...")
    health_check = HealthCheckSystem(logger, check_interval=2)
    
    # 注册服务
    health_check.register_service("service_1", lambda: True)
    health_check.register_service("service_2", lambda: False)
    
    health_check.start()
    time.sleep(3)
    
    statuses = health_check.get_all_statuses()
    logger.info(f"Service statuses: {statuses}")
    
    # 2. 智能监控系统
    logger.info("Testing intelligent monitoring system...")
    monitoring = IntelligentMonitoringSystem(logger)
    
    # 注册指标
    monitoring.register_metric("cpu_usage", {
        "upper_limit": 80,
        "lower_limit": 10,
    })
    
    # 记录指标
    for i in range(20):
        metric = MetricPoint(
            metric_name="cpu_usage",
            value=50 + i * 2,
        )
        monitoring.record_metric(metric)
    
    # 检查阈值
    alert = monitoring.check_thresholds("cpu_usage")
    if alert:
        logger.warning(f"Alert: {alert.message}")
    
    # 3. 自动告警系统
    logger.info("Testing automated alerting system...")
    alerting = AutomatedAlertingSystem(logger)
    
    # 注册告警处理器
    def handle_critical_alert(alert: Alert):
        logger.critical(f"CRITICAL ALERT: {alert.message}")
    
    alerting.register_alert_handler(AlertSeverity.CRITICAL, handle_critical_alert)
    
    # 发送告警
    test_alert = Alert(
        alert_id="TEST_001",
        severity=AlertSeverity.CRITICAL,
        service_name="test_service",
        message="Test critical alert",
    )
    alerting.send_alert(test_alert)
    
    # 4. 故障自愈系统
    logger.info("Testing fault self-healing system...")
    healing = FaultSelfHealingSystem(logger, health_check)
    
    # 注册自愈动作
    def heal_service_1():
        logger.info("Healing service_1...")
    
    healing.register_healing_action("service_1", heal_service_1)
    
    health_check.stop()


if __name__ == "__main__":
    main()
