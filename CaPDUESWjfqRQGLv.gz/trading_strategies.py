#!/usr/bin/env python3
"""
多种交易策略实现

包括：
1. 趋势跟踪策略（Trend Following）
2. 均值回归策略（Mean Reversion）
3. 动量策略（Momentum）
4. 组合策略（Hybrid）
5. 高级组合策略（Advanced Hybrid）
"""

import pandas as pd
import numpy as np
from typing import Dict, Tuple
from backtest_framework import BacktestConfig


class TrendFollowingStrategy:
    """趋势跟踪策略
    
    原理：
    - 使用快速 EMA 和慢速 EMA 的交叉作为信号
    - 快线在慢线上方为上升趋势，产生买入信号
    - 快线在慢线下方为下降趋势，产生卖出信号
    """
    
    name = "趋势跟踪策略"
    
    @staticmethod
    def generate_signals(df: pd.DataFrame, config: BacktestConfig) -> pd.DataFrame:
        """生成趋势跟踪信号"""
        df = df.copy()
        
        # 计算 EMA
        df['ema_fast'] = df['close'].ewm(span=config.ema_fast, adjust=False).mean()
        df['ema_slow'] = df['close'].ewm(span=config.ema_slow, adjust=False).mean()
        
        # 生成信号
        df['signal'] = 0
        df.loc[df['ema_fast'] > df['ema_slow'], 'signal'] = 1  # 买入
        df.loc[df['ema_fast'] < df['ema_slow'], 'signal'] = -1  # 卖出
        
        return df


class MeanReversionStrategy:
    """均值回归策略
    
    原理：
    - 使用布林带（Bollinger Bands）识别超买超卖
    - 价格触及上轨时卖出（超买）
    - 价格触及下轨时买入（超卖）
    """
    
    name = "均值回归策略"
    
    @staticmethod
    def generate_signals(df: pd.DataFrame, config: BacktestConfig) -> pd.DataFrame:
        """生成均值回归信号"""
        df = df.copy()
        
        # 计算布林带
        period = 20
        df['sma'] = df['close'].rolling(window=period).mean()
        df['std'] = df['close'].rolling(window=period).std()
        df['upper_band'] = df['sma'] + (df['std'] * 2)
        df['lower_band'] = df['sma'] - (df['std'] * 2)
        
        # 生成信号
        df['signal'] = 0
        df.loc[df['close'] < df['lower_band'], 'signal'] = 1   # 买入（超卖）
        df.loc[df['close'] > df['upper_band'], 'signal'] = -1  # 卖出（超买）
        
        return df


class MomentumStrategy:
    """动量策略
    
    原理：
    - 使用 ROC（Rate of Change）衡量价格动量
    - 正动量表示上升趋势，产生买入信号
    - 负动量表示下降趋势，产生卖出信号
    """
    
    name = "动量策略"
    
    @staticmethod
    def generate_signals(df: pd.DataFrame, config: BacktestConfig) -> pd.DataFrame:
        """生成动量信号"""
        df = df.copy()
        
        # 计算 ROC（Rate of Change）
        period = 12
        df['roc'] = ((df['close'] - df['close'].shift(period)) / df['close'].shift(period)) * 100
        
        # 计算 RSI（Relative Strength Index）
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # 生成信号
        df['signal'] = 0
        df.loc[(df['roc'] > 0) & (df['rsi'] < 70), 'signal'] = 1   # 买入
        df.loc[(df['roc'] < 0) & (df['rsi'] > 30), 'signal'] = -1  # 卖出
        
        return df


class HybridStrategy:
    """组合策略
    
    原理：
    - 结合趋势跟踪和均值回归
    - 在强趋势中使用趋势跟踪
    - 在盘整中使用均值回归
    """
    
    name = "组合策略"
    
    @staticmethod
    def generate_signals(df: pd.DataFrame, config: BacktestConfig) -> pd.DataFrame:
        """生成组合信号"""
        df = df.copy()
        
        # 计算趋势指标
        df['ema_fast'] = df['close'].ewm(span=config.ema_fast, adjust=False).mean()
        df['ema_slow'] = df['close'].ewm(span=config.ema_slow, adjust=False).mean()
        df['trend'] = df['ema_fast'] - df['ema_slow']
        
        # 计算波动率
        df['volatility'] = df['close'].rolling(window=20).std()
        
        # 计算布林带
        df['sma'] = df['close'].rolling(window=20).mean()
        df['std'] = df['close'].rolling(window=20).std()
        df['upper_band'] = df['sma'] + (df['std'] * 2)
        df['lower_band'] = df['sma'] - (df['std'] * 2)
        
        # 生成信号
        df['signal'] = 0
        
        # 强趋势中使用趋势跟踪
        strong_trend = abs(df['trend']) > df['volatility'] * 0.5
        df.loc[strong_trend & (df['ema_fast'] > df['ema_slow']), 'signal'] = 1
        df.loc[strong_trend & (df['ema_fast'] < df['ema_slow']), 'signal'] = -1
        
        # 弱趋势中使用均值回归
        weak_trend = ~strong_trend
        df.loc[weak_trend & (df['close'] < df['lower_band']), 'signal'] = 1
        df.loc[weak_trend & (df['close'] > df['upper_band']), 'signal'] = -1
        
        return df


class AdvancedHybridStrategy:
    """高级组合策略
    
    原理：
    - 结合多个技术指标
    - 使用信号融合提高准确性
    - 动态调整风控参数
    """
    
    name = "高级组合策略"
    
    @staticmethod
    def generate_signals(df: pd.DataFrame, config: BacktestConfig) -> pd.DataFrame:
        """生成高级组合信号"""
        df = df.copy()
        
        # 1. 趋势指标
        df['ema_fast'] = df['close'].ewm(span=config.ema_fast, adjust=False).mean()
        df['ema_slow'] = df['close'].ewm(span=config.ema_slow, adjust=False).mean()
        df['trend_signal'] = (df['ema_fast'] > df['ema_slow']).astype(int)
        
        # 2. 动量指标
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        df['momentum_signal'] = ((df['rsi'] > 50).astype(int) - (df['rsi'] < 50).astype(int))
        
        # 3. 波动率指标
        df['volatility'] = df['close'].rolling(window=20).std()
        df['volatility_signal'] = (df['volatility'] > df['volatility'].rolling(window=50).mean()).astype(int)
        
        # 4. 成交量指标
        df['volume_ma'] = df['volume'].rolling(window=20).mean()
        df['volume_signal'] = (df['volume'] > df['volume_ma']).astype(int)
        
        # 5. 价格位置指标
        df['sma'] = df['close'].rolling(window=20).mean()
        df['price_position'] = (df['close'] - df['sma']) / df['sma']
        df['position_signal'] = (df['price_position'] > 0).astype(int) - (df['price_position'] < 0).astype(int)
        
        # 信号融合
        df['signal_strength'] = (
            df['trend_signal'] * 0.4 +
            df['momentum_signal'] * 0.3 +
            df['volatility_signal'] * 0.15 +
            df['volume_signal'] * 0.1 +
            df['position_signal'] * 0.05
        )
        
        # 生成最终信号
        df['signal'] = 0
        df.loc[df['signal_strength'] > 0.5, 'signal'] = 1
        df.loc[df['signal_strength'] < -0.5, 'signal'] = -1
        
        return df


class ScalpingStrategy:
    """短线交易策略
    
    原理：
    - 快速进出，捕捉小幅波动
    - 使用短周期 EMA
    - 严格的止损和止盈
    """
    
    name = "短线交易策略"
    
    @staticmethod
    def generate_signals(df: pd.DataFrame, config: BacktestConfig) -> pd.DataFrame:
        """生成短线交易信号"""
        df = df.copy()
        
        # 使用更短的周期
        df['ema_5'] = df['close'].ewm(span=5, adjust=False).mean()
        df['ema_10'] = df['close'].ewm(span=10, adjust=False).mean()
        df['ema_20'] = df['close'].ewm(span=20, adjust=False).mean()
        
        # 生成信号
        df['signal'] = 0
        
        # 快速上升：三条线都向上排列
        bullish = (df['ema_5'] > df['ema_10']) & (df['ema_10'] > df['ema_20'])
        df.loc[bullish, 'signal'] = 1
        
        # 快速下降：三条线都向下排列
        bearish = (df['ema_5'] < df['ema_10']) & (df['ema_10'] < df['ema_20'])
        df.loc[bearish, 'signal'] = -1
        
        return df


class SwingTradingStrategy:
    """波段交易策略
    
    原理：
    - 捕捉中期波段
    - 使用 MACD 和 Stochastic
    - 较长的持仓周期
    """
    
    name = "波段交易策略"
    
    @staticmethod
    def generate_signals(df: pd.DataFrame, config: BacktestConfig) -> pd.DataFrame:
        """生成波段交易信号"""
        df = df.copy()
        
        # 计算 MACD
        ema_12 = df['close'].ewm(span=12, adjust=False).mean()
        ema_26 = df['close'].ewm(span=26, adjust=False).mean()
        df['macd'] = ema_12 - ema_26
        df['signal_line'] = df['macd'].ewm(span=9, adjust=False).mean()
        df['histogram'] = df['macd'] - df['signal_line']
        
        # 计算 Stochastic
        low_14 = df['low'].rolling(window=14).min()
        high_14 = df['high'].rolling(window=14).max()
        df['k'] = 100 * (df['close'] - low_14) / (high_14 - low_14)
        df['d'] = df['k'].rolling(window=3).mean()
        
        # 生成信号
        df['signal'] = 0
        
        # MACD 金叉且 Stochastic 低位
        df.loc[(df['histogram'] > 0) & (df['k'] < 30), 'signal'] = 1
        
        # MACD 死叉且 Stochastic 高位
        df.loc[(df['histogram'] < 0) & (df['k'] > 70), 'signal'] = -1
        
        return df


# 策略注册表
STRATEGIES = {
    'trend_following': TrendFollowingStrategy,
    'mean_reversion': MeanReversionStrategy,
    'momentum': MomentumStrategy,
    'hybrid': HybridStrategy,
    'advanced_hybrid': AdvancedHybridStrategy,
    'scalping': ScalpingStrategy,
    'swing_trading': SwingTradingStrategy,
}


class StrategyManager:
    """策略管理器"""
    
    @staticmethod
    def get_strategy(strategy_name: str):
        """获取策略"""
        if strategy_name not in STRATEGIES:
            raise ValueError(f"未知策略: {strategy_name}")
        return STRATEGIES[strategy_name]
    
    @staticmethod
    def list_strategies():
        """列出所有策略"""
        return list(STRATEGIES.keys())
    
    @staticmethod
    def get_strategy_info(strategy_name: str) -> Dict:
        """获取策略信息"""
        strategy = StrategyManager.get_strategy(strategy_name)
        return {
            'name': strategy.name,
            'class': strategy.__name__,
            'description': strategy.__doc__
        }


# 示例使用
if __name__ == "__main__":
    print("可用策略:")
    for strategy_name in StrategyManager.list_strategies():
        info = StrategyManager.get_strategy_info(strategy_name)
        print(f"\n{strategy_name}:")
        print(f"  名称: {info['name']}")
        print(f"  类: {info['class']}")
