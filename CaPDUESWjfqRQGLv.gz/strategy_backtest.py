#!/usr/bin/env python3
"""
策略回测执行和对比分析

功能：
1. 对多个策略进行回测
2. 收集和对比性能指标
3. 生成对比分析报告
4. 可视化策略对比
"""

import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib import rcParams
from typing import Dict, List, Tuple
from datetime import datetime

from backtest_framework import BacktestConfig, BacktestDataSource
from backtest_engine import BacktestEngine
from trading_strategies import StrategyManager, STRATEGIES


# 设置中文字体
rcParams['font.sans-serif'] = ['Noto Sans CJK SC', 'DejaVu Sans']
rcParams['axes.unicode_minus'] = False


class StrategyBacktestRunner:
    """策略回测执行器"""
    
    def __init__(self, data: pd.DataFrame, base_config: BacktestConfig = None):
        """初始化回测执行器
        
        Args:
            data: 历史数据
            base_config: 基础配置
        """
        self.data = data
        self.base_config = base_config or BacktestConfig()
        self.results = {}
    
    def run_all_strategies(self) -> Dict:
        """运行所有策略的回测"""
        print(f"开始对 {len(STRATEGIES)} 个策略进行回测...\n")
        
        for strategy_name, strategy_class in STRATEGIES.items():
            print(f"正在回测: {strategy_class.name}...", end=" ")
            
            try:
                # 生成信号
                data_with_signals = strategy_class.generate_signals(self.data, self.base_config)
                
                # 运行回测
                engine = BacktestEngine(self.base_config)
                result = engine.run_backtest(data_with_signals)
                
                # 保存结果
                self.results[strategy_name] = {
                    'strategy_name': strategy_class.name,
                    'metrics': result['metrics'],
                    'portfolio': result['portfolio'],
                    'data': data_with_signals
                }
                
                print(f"✓ 完成 (胜率: {result['metrics']['win_rate']:.1f}%)")
            
            except Exception as e:
                print(f"✗ 失败: {str(e)}")
        
        print(f"\n✓ 所有策略回测完成！")
        return self.results
    
    def run_single_strategy(self, strategy_name: str) -> Dict:
        """运行单个策略的回测"""
        if strategy_name not in STRATEGIES:
            raise ValueError(f"未知策略: {strategy_name}")
        
        strategy_class = STRATEGIES[strategy_name]
        print(f"正在回测: {strategy_class.name}...")
        
        # 生成信号
        data_with_signals = strategy_class.generate_signals(self.data, self.base_config)
        
        # 运行回测
        engine = BacktestEngine(self.base_config)
        result = engine.run_backtest(data_with_signals)
        
        # 保存结果
        self.results[strategy_name] = {
            'strategy_name': strategy_class.name,
            'metrics': result['metrics'],
            'portfolio': result['portfolio'],
            'data': data_with_signals
        }
        
        return self.results[strategy_name]


class StrategyComparator:
    """策略对比分析器"""
    
    @staticmethod
    def create_comparison_table(results: Dict) -> pd.DataFrame:
        """创建策略对比表"""
        comparison_data = []
        
        for strategy_name, result in results.items():
            metrics = result['metrics']
            comparison_data.append({
                '策略': result['strategy_name'],
                '总交易数': metrics.get('total_trades', 0),
                '胜率(%)': metrics.get('win_rate', 0),
                '总收益(%)': metrics.get('total_return', 0),
                '平均PnL': metrics.get('avg_pnl', 0),
                '最大回撤(%)': metrics.get('max_drawdown', 0),
                '夏普比率': metrics.get('sharpe_ratio', 0),
                '利润因子': metrics.get('profit_factor', 0),
                '最大连胜': metrics.get('max_consecutive_wins', 0),
                '最大连亏': metrics.get('max_consecutive_losses', 0),
            })
        
        df = pd.DataFrame(comparison_data)
        return df
    
    @staticmethod
    def rank_strategies(results: Dict, metric: str = 'sharpe_ratio') -> List[Tuple[str, float]]:
        """按指定指标排序策略"""
        rankings = []
        
        for strategy_name, result in results.items():
            metrics = result['metrics']
            value = metrics.get(metric, 0)
            rankings.append((result['strategy_name'], value))
        
        # 按值降序排序
        rankings.sort(key=lambda x: x[1], reverse=True)
        
        return rankings
    
    @staticmethod
    def get_best_strategy(results: Dict, metric: str = 'sharpe_ratio') -> Tuple[str, Dict]:
        """获取最佳策略"""
        best_strategy = None
        best_value = -float('inf')
        
        for strategy_name, result in results.items():
            metrics = result['metrics']
            value = metrics.get(metric, 0)
            
            if value > best_value:
                best_value = value
                best_strategy = strategy_name
        
        if best_strategy:
            return best_strategy, results[best_strategy]
        return None, None


class StrategyVisualizer:
    """策略可视化"""
    
    @staticmethod
    def plot_strategy_comparison(results: Dict, output_path: str = "strategy_comparison.png"):
        """绘制策略对比图"""
        comparison_df = StrategyComparator.create_comparison_table(results)
        
        # 选择关键指标
        metrics = ['胜率(%)', '总收益(%)', '最大回撤(%)', '夏普比率']
        
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        axes = axes.flatten()
        
        for idx, metric in enumerate(metrics):
            ax = axes[idx]
            
            # 准备数据
            strategies = comparison_df['策略'].values
            values = comparison_df[metric].values
            
            # 确定颜色
            if metric == '最大回撤(%)':
                colors = ['#d62728' if v > 0 else '#2ca02c' for v in values]
            else:
                colors = ['#2ca02c' if v > 0 else '#d62728' for v in values]
            
            # 绘制柱状图
            bars = ax.bar(range(len(strategies)), values, color=colors, alpha=0.7, edgecolor='black')
            
            # 添加数值标签
            for bar, value in zip(bars, values):
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height,
                       f'{value:.2f}', ha='center', va='bottom', fontsize=9)
            
            ax.set_ylabel(metric, fontsize=11)
            ax.set_title(metric, fontsize=12, fontweight='bold')
            ax.set_xticks(range(len(strategies)))
            ax.set_xticklabels(strategies, rotation=45, ha='right')
            ax.grid(True, alpha=0.3, axis='y')
            ax.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 策略对比图已保存: {output_path}")
    
    @staticmethod
    def plot_equity_curves_comparison(results: Dict, output_path: str = "equity_curves_comparison.png"):
        """绘制权益曲线对比"""
        fig, ax = plt.subplots(figsize=(14, 7))
        
        colors = plt.cm.tab10(np.linspace(0, 1, len(results)))
        
        for (strategy_name, result), color in zip(results.items(), colors):
            portfolio = result['portfolio']
            
            if not portfolio.snapshots:
                continue
            
            timestamps = [s.timestamp for s in portfolio.snapshots]
            values = [s.total_value for s in portfolio.snapshots]
            
            ax.plot(timestamps, values, linewidth=2, label=result['strategy_name'], color=color)
        
        ax.set_xlabel('时间', fontsize=12)
        ax.set_ylabel('账户价值 (USDT)', fontsize=12)
        ax.set_title('策略权益曲线对比', fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3)
        ax.legend(loc='best', fontsize=10)
        
        # 格式化 x 轴
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        ax.xaxis.set_major_locator(mdates.AutoDateLocator())
        plt.xticks(rotation=45)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 权益曲线对比图已保存: {output_path}")
    
    @staticmethod
    def plot_metrics_radar(results: Dict, output_path: str = "metrics_radar.png"):
        """绘制性能指标雷达图"""
        from math import pi
        
        comparison_df = StrategyComparator.create_comparison_table(results)
        
        # 选择指标
        metrics = ['胜率(%)', '总收益(%)', '夏普比率', '利润因子']
        
        # 归一化指标
        normalized_df = comparison_df.copy()
        for metric in metrics:
            max_val = normalized_df[metric].max()
            min_val = normalized_df[metric].min()
            if max_val > min_val:
                normalized_df[metric] = (normalized_df[metric] - min_val) / (max_val - min_val) * 100
            else:
                normalized_df[metric] = 50
        
        # 创建雷达图
        num_vars = len(metrics)
        angles = [n / float(num_vars) * 2 * pi for n in range(num_vars)]
        angles += angles[:1]
        
        fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(projection='polar'))
        
        colors = plt.cm.tab10(np.linspace(0, 1, len(results)))
        
        for idx, (strategy_name, result) in enumerate(results.items()):
            values = normalized_df.iloc[idx][metrics].values.tolist()
            values += values[:1]
            
            ax.plot(angles, values, 'o-', linewidth=2, label=result['strategy_name'], color=colors[idx])
            ax.fill(angles, values, alpha=0.15, color=colors[idx])
        
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(metrics, fontsize=10)
        ax.set_ylim(0, 100)
        ax.set_title('策略性能指标雷达图', fontsize=14, fontweight='bold', pad=20)
        ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=10)
        ax.grid(True)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 雷达图已保存: {output_path}")
    
    @staticmethod
    def plot_win_rate_vs_return(results: Dict, output_path: str = "win_rate_vs_return.png"):
        """绘制胜率 vs 收益散点图"""
        comparison_df = StrategyComparator.create_comparison_table(results)
        
        fig, ax = plt.subplots(figsize=(12, 7))
        
        for idx, row in comparison_df.iterrows():
            ax.scatter(row['胜率(%)'], row['总收益(%)'], s=300, alpha=0.6, label=row['策略'])
            ax.annotate(row['策略'], 
                       (row['胜率(%)'], row['总收益(%)']),
                       xytext=(5, 5), textcoords='offset points', fontsize=9)
        
        ax.set_xlabel('胜率 (%)', fontsize=12)
        ax.set_ylabel('总收益 (%)', fontsize=12)
        ax.set_title('胜率 vs 收益分析', fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3)
        ax.axhline(y=0, color='red', linestyle='--', linewidth=1)
        ax.axvline(x=50, color='blue', linestyle='--', linewidth=1)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"✓ 胜率 vs 收益图已保存: {output_path}")


# 示例使用
if __name__ == "__main__":
    # 生成示例数据
    print("生成测试数据...")
    data = BacktestDataSource.generate_sample_data("BTCUSDT", days=120)
    
    # 创建配置
    config = BacktestConfig()
    config.initial_capital = 1000.0
    
    # 运行回测
    print("\n开始策略回测...\n")
    runner = StrategyBacktestRunner(data, config)
    results = runner.run_all_strategies()
    
    # 对比分析
    print("\n策略对比分析:\n")
    comparison_df = StrategyComparator.create_comparison_table(results)
    print(comparison_df.to_string(index=False))
    
    # 排序
    print("\n按夏普比率排序:")
    rankings = StrategyComparator.rank_strategies(results, 'sharpe_ratio')
    for rank, (strategy_name, value) in enumerate(rankings, 1):
        print(f"{rank}. {strategy_name}: {value:.2f}")
    
    # 生成可视化
    print("\n生成可视化报告...")
    visualizer = StrategyVisualizer()
    visualizer.plot_strategy_comparison(results, "results/strategy_comparison.png")
    visualizer.plot_equity_curves_comparison(results, "results/equity_curves_comparison.png")
    visualizer.plot_metrics_radar(results, "results/metrics_radar.png")
    visualizer.plot_win_rate_vs_return(results, "results/win_rate_vs_return.png")
    
    print("\n✓ 所有分析完成！")
