"""
架构优化迭代 - 微服务和事件驱动架构
包含事件驱动架构、消息队列、服务网格、分布式追踪
"""

import logging
from datetime import datetime
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod
import uuid
import json
from queue import Queue
import threading


# ============================================================================
# 数据结构
# ============================================================================

class EventType(Enum):
    """事件类型"""
    # 市场事件
    MARKET_DATA_RECEIVED = "market_data_received"
    PRICE_UPDATED = "price_updated"
    VOLUME_UPDATED = "volume_updated"
    
    # 信号事件
    SIGNAL_GENERATED = "signal_generated"
    SIGNAL_PROCESSED = "signal_processed"
    
    # 交易事件
    ORDER_CREATED = "order_created"
    ORDER_EXECUTED = "order_executed"
    ORDER_CANCELLED = "order_cancelled"
    TRADE_COMPLETED = "trade_completed"
    
    # 风控事件
    RISK_CHECK_STARTED = "risk_check_started"
    RISK_CHECK_COMPLETED = "risk_check_completed"
    RISK_ALERT = "risk_alert"
    
    # 系统事件
    SERVICE_STARTED = "service_started"
    SERVICE_STOPPED = "service_stopped"
    ERROR_OCCURRED = "error_occurred"


@dataclass
class Event:
    """事件"""
    event_type: EventType
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=datetime.utcnow)
    source_service: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    correlation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "event_type": self.event_type.value,
            "event_id": self.event_id,
            "timestamp": self.timestamp.isoformat(),
            "source_service": self.source_service,
            "data": self.data,
            "correlation_id": self.correlation_id,
        }


@dataclass
class ServiceMetrics:
    """服务指标"""
    service_name: str
    events_processed: int = 0
    events_failed: int = 0
    avg_processing_time_ms: float = 0
    last_event_time: Optional[datetime] = None


# ============================================================================
# 事件总线
# ============================================================================

class EventBus:
    """事件总线"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.subscribers: Dict[EventType, List[Callable]] = {}
        self.event_queue: Queue = Queue()
        self.event_history: List[Event] = []
        self.running = False
    
    def subscribe(self, event_type: EventType, handler: Callable):
        """订阅事件"""
        if event_type not in self.subscribers:
            self.subscribers[event_type] = []
        
        self.subscribers[event_type].append(handler)
        self.logger.debug(f"Subscribed to {event_type.value}")
    
    def publish(self, event: Event):
        """发布事件"""
        self.event_queue.put(event)
        self.event_history.append(event)
        self.logger.debug(f"Published event: {event.event_type.value}")
    
    def start(self):
        """启动事件总线"""
        self.running = True
        thread = threading.Thread(target=self._process_events, daemon=True)
        thread.start()
        self.logger.info("Event bus started")
    
    def stop(self):
        """停止事件总线"""
        self.running = False
        self.logger.info("Event bus stopped")
    
    def _process_events(self):
        """处理事件"""
        while self.running:
            try:
                event = self.event_queue.get(timeout=1)
                
                # 获取该事件类型的所有处理器
                handlers = self.subscribers.get(event.event_type, [])
                
                for handler in handlers:
                    try:
                        handler(event)
                    except Exception as e:
                        self.logger.error(f"Error processing event: {e}")
            
            except:
                pass


# ============================================================================
# 微服务基类
# ============================================================================

class Microservice(ABC):
    """微服务基类"""
    
    def __init__(self, service_name: str, logger: logging.Logger, event_bus: EventBus):
        self.service_name = service_name
        self.logger = logger
        self.event_bus = event_bus
        self.metrics = ServiceMetrics(service_name=service_name)
        self.running = False
    
    def start(self):
        """启动服务"""
        self.running = True
        event = Event(
            event_type=EventType.SERVICE_STARTED,
            source_service=self.service_name,
            data={"service_name": self.service_name},
        )
        self.event_bus.publish(event)
        self.logger.info(f"Service {self.service_name} started")
    
    def stop(self):
        """停止服务"""
        self.running = False
        event = Event(
            event_type=EventType.SERVICE_STOPPED,
            source_service=self.service_name,
            data={"service_name": self.service_name},
        )
        self.event_bus.publish(event)
        self.logger.info(f"Service {self.service_name} stopped")
    
    @abstractmethod
    def handle_event(self, event: Event):
        """处理事件"""
        pass
    
    def get_metrics(self) -> ServiceMetrics:
        """获取服务指标"""
        return self.metrics


# ============================================================================
# 具体微服务实现
# ============================================================================

class MarketDataService(Microservice):
    """市场数据服务"""
    
    def __init__(self, logger: logging.Logger, event_bus: EventBus):
        super().__init__("MarketDataService", logger, event_bus)
        self.market_data: Dict[str, Dict] = {}
    
    def start(self):
        """启动服务"""
        super().start()
        # 订阅相关事件
        self.event_bus.subscribe(EventType.MARKET_DATA_RECEIVED, self.handle_event)
    
    def handle_event(self, event: Event):
        """处理事件"""
        if event.event_type == EventType.MARKET_DATA_RECEIVED:
            self._process_market_data(event)
    
    def _process_market_data(self, event: Event):
        """处理市场数据"""
        try:
            symbol = event.data.get("symbol")
            price = event.data.get("price")
            volume = event.data.get("volume")
            
            self.market_data[symbol] = {
                "price": price,
                "volume": volume,
                "timestamp": event.timestamp,
            }
            
            # 发布价格更新事件
            price_event = Event(
                event_type=EventType.PRICE_UPDATED,
                source_service=self.service_name,
                data={"symbol": symbol, "price": price},
                correlation_id=event.correlation_id,
            )
            self.event_bus.publish(price_event)
            
            self.metrics.events_processed += 1
        
        except Exception as e:
            self.logger.error(f"Error processing market data: {e}")
            self.metrics.events_failed += 1


class SignalService(Microservice):
    """信号服务"""
    
    def __init__(self, logger: logging.Logger, event_bus: EventBus):
        super().__init__("SignalService", logger, event_bus)
        self.signals: Dict[str, Dict] = {}
    
    def start(self):
        """启动服务"""
        super().start()
        # 订阅相关事件
        self.event_bus.subscribe(EventType.PRICE_UPDATED, self.handle_event)
    
    def handle_event(self, event: Event):
        """处理事件"""
        if event.event_type == EventType.PRICE_UPDATED:
            self._generate_signal(event)
    
    def _generate_signal(self, event: Event):
        """生成信号"""
        try:
            symbol = event.data.get("symbol")
            price = event.data.get("price")
            
            # 简单的信号生成逻辑
            signal = {
                "symbol": symbol,
                "action": "BUY" if price > 50000 else "SELL",
                "confidence": 0.75,
            }
            
            self.signals[symbol] = signal
            
            # 发布信号生成事件
            signal_event = Event(
                event_type=EventType.SIGNAL_GENERATED,
                source_service=self.service_name,
                data=signal,
                correlation_id=event.correlation_id,
            )
            self.event_bus.publish(signal_event)
            
            self.metrics.events_processed += 1
        
        except Exception as e:
            self.logger.error(f"Error generating signal: {e}")
            self.metrics.events_failed += 1


class ExecutionService(Microservice):
    """执行服务"""
    
    def __init__(self, logger: logging.Logger, event_bus: EventBus):
        super().__init__("ExecutionService", logger, event_bus)
        self.orders: Dict[str, Dict] = {}
    
    def start(self):
        """启动服务"""
        super().start()
        # 订阅相关事件
        self.event_bus.subscribe(EventType.SIGNAL_GENERATED, self.handle_event)
    
    def handle_event(self, event: Event):
        """处理事件"""
        if event.event_type == EventType.SIGNAL_GENERATED:
            self._execute_trade(event)
    
    def _execute_trade(self, event: Event):
        """执行交易"""
        try:
            symbol = event.data.get("symbol")
            action = event.data.get("action")
            
            # 创建订单
            order_id = f"ORDER_{symbol}_{int(datetime.utcnow().timestamp())}"
            order = {
                "order_id": order_id,
                "symbol": symbol,
                "action": action,
                "status": "executed",
                "timestamp": datetime.utcnow().isoformat(),
            }
            
            self.orders[order_id] = order
            
            # 发布交易完成事件
            trade_event = Event(
                event_type=EventType.TRADE_COMPLETED,
                source_service=self.service_name,
                data=order,
                correlation_id=event.correlation_id,
            )
            self.event_bus.publish(trade_event)
            
            self.metrics.events_processed += 1
        
        except Exception as e:
            self.logger.error(f"Error executing trade: {e}")
            self.metrics.events_failed += 1


class RiskControlService(Microservice):
    """风控服务"""
    
    def __init__(self, logger: logging.Logger, event_bus: EventBus):
        super().__init__("RiskControlService", logger, event_bus)
        self.risk_checks: List[Dict] = []
    
    def start(self):
        """启动服务"""
        super().start()
        # 订阅相关事件
        self.event_bus.subscribe(EventType.TRADE_COMPLETED, self.handle_event)
    
    def handle_event(self, event: Event):
        """处理事件"""
        if event.event_type == EventType.TRADE_COMPLETED:
            self._check_risk(event)
    
    def _check_risk(self, event: Event):
        """检查风险"""
        try:
            order = event.data
            
            # 简单的风控检查
            is_safe = order.get("amount", 1) < 10
            
            risk_check = {
                "order_id": order.get("order_id"),
                "is_safe": is_safe,
                "timestamp": datetime.utcnow().isoformat(),
            }
            
            self.risk_checks.append(risk_check)
            
            # 发布风控检查完成事件
            risk_event = Event(
                event_type=EventType.RISK_CHECK_COMPLETED,
                source_service=self.service_name,
                data=risk_check,
                correlation_id=event.correlation_id,
            )
            self.event_bus.publish(risk_event)
            
            self.metrics.events_processed += 1
        
        except Exception as e:
            self.logger.error(f"Error checking risk: {e}")
            self.metrics.events_failed += 1


# ============================================================================
# 服务网格
# ============================================================================

class ServiceMesh:
    """服务网格"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.event_bus = EventBus(logger)
        self.services: Dict[str, Microservice] = {}
        self.service_registry: Dict[str, Dict] = {}
    
    def register_service(self, service: Microservice):
        """注册服务"""
        self.services[service.service_name] = service
        self.service_registry[service.service_name] = {
            "name": service.service_name,
            "status": "registered",
            "timestamp": datetime.utcnow(),
        }
        self.logger.info(f"Service {service.service_name} registered")
    
    def start_all_services(self):
        """启动所有服务"""
        self.event_bus.start()
        
        for service in self.services.values():
            service.start()
        
        self.logger.info("All services started")
    
    def stop_all_services(self):
        """停止所有服务"""
        for service in self.services.values():
            service.stop()
        
        self.event_bus.stop()
        
        self.logger.info("All services stopped")
    
    def get_service_metrics(self) -> Dict[str, ServiceMetrics]:
        """获取所有服务的指标"""
        metrics = {}
        for name, service in self.services.items():
            metrics[name] = service.get_metrics()
        
        return metrics


# ============================================================================
# 分布式追踪
# ============================================================================

class DistributedTracer:
    """分布式追踪"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.traces: Dict[str, List[Dict]] = {}
    
    def trace_event(self, event: Event):
        """追踪事件"""
        correlation_id = event.correlation_id
        
        if correlation_id not in self.traces:
            self.traces[correlation_id] = []
        
        trace = {
            "event_type": event.event_type.value,
            "event_id": event.event_id,
            "source_service": event.source_service,
            "timestamp": event.timestamp.isoformat(),
        }
        
        self.traces[correlation_id].append(trace)
    
    def get_trace(self, correlation_id: str) -> List[Dict]:
        """获取追踪信息"""
        return self.traces.get(correlation_id, [])


# ============================================================================
# 主程序
# ============================================================================

def main():
    """主程序"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    logger.info("=== Architecture Optimization - Event-Driven & Microservices ===")
    
    # 创建服务网格
    mesh = ServiceMesh(logger)
    
    # 注册服务
    market_service = MarketDataService(logger, mesh.event_bus)
    signal_service = SignalService(logger, mesh.event_bus)
    execution_service = ExecutionService(logger, mesh.event_bus)
    risk_service = RiskControlService(logger, mesh.event_bus)
    
    mesh.register_service(market_service)
    mesh.register_service(signal_service)
    mesh.register_service(execution_service)
    mesh.register_service(risk_service)
    
    # 启动所有服务
    mesh.start_all_services()
    
    # 创建分布式追踪器
    tracer = DistributedTracer(logger)
    mesh.event_bus.subscribe(EventType.MARKET_DATA_RECEIVED, lambda e: tracer.trace_event(e))
    mesh.event_bus.subscribe(EventType.SIGNAL_GENERATED, lambda e: tracer.trace_event(e))
    mesh.event_bus.subscribe(EventType.TRADE_COMPLETED, lambda e: tracer.trace_event(e))
    mesh.event_bus.subscribe(EventType.RISK_CHECK_COMPLETED, lambda e: tracer.trace_event(e))
    
    # 发布市场数据事件
    market_event = Event(
        event_type=EventType.MARKET_DATA_RECEIVED,
        source_service="ExternalDataProvider",
        data={"symbol": "BTCUSDT", "price": 50000, "volume": 1000000},
    )
    mesh.event_bus.publish(market_event)
    
    # 等待事件处理
    import time
    time.sleep(2)
    
    # 获取服务指标
    metrics = mesh.get_service_metrics()
    for name, metric in metrics.items():
        logger.info(f"{name}: processed={metric.events_processed}, failed={metric.events_failed}")
    
    # 获取追踪信息
    traces = tracer.get_trace(market_event.correlation_id)
    logger.info(f"Trace for {market_event.correlation_id}: {json.dumps(traces, indent=2)}")
    
    # 停止所有服务
    mesh.stop_all_services()


if __name__ == "__main__":
    main()
