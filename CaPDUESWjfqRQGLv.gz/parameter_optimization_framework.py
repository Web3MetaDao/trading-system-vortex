#!/usr/bin/env python3
"""
参数优化框架

功能：
1. 定义参数优化问题
2. 实现多种优化算法
3. 评估优化结果
4. 生成优化报告
"""

import json
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Callable, Any
from dataclasses import dataclass
from datetime import datetime
import itertools

from backtest_framework import BacktestConfig
from backtest_engine import BacktestEngine


@dataclass
class ParameterRange:
    """参数范围定义"""
    name: str
    min_value: float
    max_value: float
    step: float
    description: str = ""
    
    def get_values(self) -> List[float]:
        """获取参数范围内的所有值"""
        num_steps = int((self.max_value - self.min_value) / self.step) + 1
        return np.linspace(self.min_value, self.max_value, num_steps).tolist()


@dataclass
class OptimizationResult:
    """优化结果"""
    parameters: Dict[str, float]
    metric_value: float
    metrics: Dict
    timestamp: datetime
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            'parameters': self.parameters,
            'metric_value': self.metric_value,
            'metrics': self.metrics,
            'timestamp': self.timestamp.isoformat()
        }


class ParameterOptimizationFramework:
    """参数优化框架"""
    
    def __init__(self, data: pd.DataFrame, base_config: BacktestConfig):
        """初始化优化框架
        
        Args:
            data: 历史数据
            base_config: 基础配置
        """
        self.data = data
        self.base_config = base_config
        self.results: List[OptimizationResult] = []
        self.best_result: OptimizationResult = None
    
    def grid_search(
        self,
        param_ranges: Dict[str, ParameterRange],
        strategy_class,
        metric: str = 'sharpe_ratio',
        verbose: bool = True
    ) -> OptimizationResult:
        """网格搜索优化
        
        Args:
            param_ranges: 参数范围字典
            strategy_class: 策略类
            metric: 优化指标
            verbose: 是否输出详细信息
            
        Returns:
            最优结果
        """
        print(f"\n开始网格搜索 ({metric})...")
        
        # 生成参数组合
        param_names = list(param_ranges.keys())
        param_values_list = [param_ranges[name].get_values() for name in param_names]
        
        total_combinations = np.prod([len(v) for v in param_values_list])
        print(f"总参数组合数: {int(total_combinations)}")
        
        best_value = -float('inf')
        best_params = None
        
        # 遍历所有参数组合
        for idx, param_values in enumerate(itertools.product(*param_values_list)):
            # 创建参数字典
            params = dict(zip(param_names, param_values))
            
            # 创建配置
            config = BacktestConfig()
            for key, value in params.items():
                if hasattr(config, key):
                    setattr(config, key, value)
            
            try:
                # 运行回测
                data_with_signals = strategy_class.generate_signals(self.data, config)
                engine = BacktestEngine(config)
                result = engine.run_backtest(data_with_signals)
                metrics = result['metrics']
                
                # 获取指标值
                metric_value = metrics.get(metric, 0)
                
                # 保存结果
                opt_result = OptimizationResult(
                    parameters=params,
                    metric_value=metric_value,
                    metrics=metrics,
                    timestamp=datetime.now()
                )
                self.results.append(opt_result)
                
                # 更新最优结果
                if metric_value > best_value:
                    best_value = metric_value
                    best_params = params
                    self.best_result = opt_result
                
                # 进度输出
                if verbose and (idx + 1) % max(1, int(total_combinations / 10)) == 0:
                    progress = (idx + 1) / total_combinations * 100
                    print(f"  进度: {idx + 1}/{int(total_combinations)} ({progress:.1f}%)")
            
            except Exception as e:
                if verbose:
                    print(f"  组合 {idx + 1} 失败: {str(e)}")
        
        print(f"✓ 网格搜索完成！最优值: {best_value:.4f}")
        return self.best_result
    
    def random_search(
        self,
        param_ranges: Dict[str, ParameterRange],
        strategy_class,
        num_iterations: int = 100,
        metric: str = 'sharpe_ratio',
        verbose: bool = True
    ) -> OptimizationResult:
        """随机搜索优化
        
        Args:
            param_ranges: 参数范围字典
            strategy_class: 策略类
            num_iterations: 迭代次数
            metric: 优化指标
            verbose: 是否输出详细信息
            
        Returns:
            最优结果
        """
        print(f"\n开始随机搜索 ({metric})...")
        print(f"迭代次数: {num_iterations}")
        
        best_value = -float('inf')
        best_params = None
        
        for iteration in range(num_iterations):
            # 随机生成参数
            params = {}
            for name, param_range in param_ranges.items():
                value = np.random.uniform(param_range.min_value, param_range.max_value)
                params[name] = value
            
            # 创建配置
            config = BacktestConfig()
            for key, value in params.items():
                if hasattr(config, key):
                    setattr(config, key, value)
            
            try:
                # 运行回测
                data_with_signals = strategy_class.generate_signals(self.data, config)
                engine = BacktestEngine(config)
                result = engine.run_backtest(data_with_signals)
                metrics = result['metrics']
                
                # 获取指标值
                metric_value = metrics.get(metric, 0)
                
                # 保存结果
                opt_result = OptimizationResult(
                    parameters=params,
                    metric_value=metric_value,
                    metrics=metrics,
                    timestamp=datetime.now()
                )
                self.results.append(opt_result)
                
                # 更新最优结果
                if metric_value > best_value:
                    best_value = metric_value
                    best_params = params
                    self.best_result = opt_result
                
                # 进度输出
                if verbose and (iteration + 1) % max(1, num_iterations // 10) == 0:
                    progress = (iteration + 1) / num_iterations * 100
                    print(f"  进度: {iteration + 1}/{num_iterations} ({progress:.1f}%)")
            
            except Exception as e:
                if verbose:
                    print(f"  迭代 {iteration + 1} 失败: {str(e)}")
        
        print(f"✓ 随机搜索完成！最优值: {best_value:.4f}")
        return self.best_result
    
    def get_results_dataframe(self) -> pd.DataFrame:
        """获取结果数据框"""
        data = []
        for result in self.results:
            row = result.parameters.copy()
            row['metric_value'] = result.metric_value
            for key, value in result.metrics.items():
                row[f'metric_{key}'] = value
            data.append(row)
        
        return pd.DataFrame(data)
    
    def get_top_results(self, n: int = 10) -> List[OptimizationResult]:
        """获取前 N 个最优结果"""
        sorted_results = sorted(self.results, key=lambda x: x.metric_value, reverse=True)
        return sorted_results[:n]
    
    def analyze_parameter_sensitivity(self, param_name: str) -> pd.DataFrame:
        """分析参数敏感性"""
        df = self.get_results_dataframe()
        
        # 按参数值分组
        grouped = df.groupby(param_name)['metric_value'].agg(['mean', 'std', 'min', 'max', 'count'])
        
        return grouped.sort_index()


# 预定义的参数优化配置

class TrendFollowingOptimizationConfig:
    """趋势跟踪策略参数优化配置"""
    
    @staticmethod
    def get_param_ranges() -> Dict[str, ParameterRange]:
        """获取参数范围"""
        return {
            'ema_fast': ParameterRange(
                name='ema_fast',
                min_value=5,
                max_value=30,
                step=5,
                description='快线周期'
            ),
            'ema_slow': ParameterRange(
                name='ema_slow',
                min_value=30,
                max_value=100,
                step=10,
                description='慢线周期'
            ),
            'stop_loss_pct': ParameterRange(
                name='stop_loss_pct',
                min_value=1.0,
                max_value=5.0,
                step=0.5,
                description='止损百分比'
            ),
            'take_profit_pct': ParameterRange(
                name='take_profit_pct',
                min_value=2.0,
                max_value=8.0,
                step=1.0,
                description='止盈百分比'
            ),
        }
    
    @staticmethod
    def get_optimization_targets() -> Dict[str, str]:
        """获取优化目标"""
        return {
            'sharpe_ratio': '夏普比率（风险调整收益）',
            'total_return': '总收益率',
            'profit_factor': '利润因子（风险收益比）',
            'win_rate': '胜率',
        }


class HybridOptimizationConfig:
    """组合策略参数优化配置"""
    
    @staticmethod
    def get_param_ranges() -> Dict[str, ParameterRange]:
        """获取参数范围"""
        return {
            'ema_fast': ParameterRange(
                name='ema_fast',
                min_value=10,
                max_value=40,
                step=5,
                description='快线周期'
            ),
            'ema_slow': ParameterRange(
                name='ema_slow',
                min_value=40,
                max_value=120,
                step=10,
                description='慢线周期'
            ),
            'stop_loss_pct': ParameterRange(
                name='stop_loss_pct',
                min_value=1.5,
                max_value=4.0,
                step=0.5,
                description='止损百分比'
            ),
            'take_profit_pct': ParameterRange(
                name='take_profit_pct',
                min_value=3.0,
                max_value=10.0,
                step=1.0,
                description='止盈百分比'
            ),
            'max_position_size': ParameterRange(
                name='max_position_size',
                min_value=0.3,
                max_value=0.7,
                step=0.1,
                description='最大头寸占比'
            ),
        }
    
    @staticmethod
    def get_optimization_targets() -> Dict[str, str]:
        """获取优化目标"""
        return {
            'sharpe_ratio': '夏普比率',
            'total_return': '总收益率',
            'profit_factor': '利润因子',
        }


class ScalpingOptimizationConfig:
    """短线交易策略参数优化配置"""
    
    @staticmethod
    def get_param_ranges() -> Dict[str, ParameterRange]:
        """获取参数范围"""
        return {
            'stop_loss_pct': ParameterRange(
                name='stop_loss_pct',
                min_value=0.5,
                max_value=2.0,
                step=0.25,
                description='止损百分比'
            ),
            'take_profit_pct': ParameterRange(
                name='take_profit_pct',
                min_value=0.5,
                max_value=2.0,
                step=0.25,
                description='止盈百分比'
            ),
            'max_position_size': ParameterRange(
                name='max_position_size',
                min_value=0.2,
                max_value=0.6,
                step=0.1,
                description='最大头寸占比'
            ),
            'max_open_positions': ParameterRange(
                name='max_open_positions',
                min_value=3,
                max_value=10,
                step=1,
                description='最大开放头寸数'
            ),
        }
    
    @staticmethod
    def get_optimization_targets() -> Dict[str, str]:
        """获取优化目标"""
        return {
            'sharpe_ratio': '夏普比率',
            'total_return': '总收益率',
            'win_rate': '胜率',
        }


# 示例使用
if __name__ == "__main__":
    from backtest_framework import BacktestDataSource
    from trading_strategies import TrendFollowingStrategy
    
    # 生成数据
    data = BacktestDataSource.generate_sample_data("BTCUSDT", days=120)
    
    # 创建配置
    base_config = BacktestConfig()
    
    # 创建优化框架
    framework = ParameterOptimizationFramework(data, base_config)
    
    # 获取参数范围
    param_ranges = TrendFollowingOptimizationConfig.get_param_ranges()
    
    # 运行网格搜索
    best_result = framework.grid_search(
        param_ranges,
        TrendFollowingStrategy,
        metric='sharpe_ratio'
    )
    
    print(f"\n最优参数: {best_result.parameters}")
    print(f"最优值: {best_result.metric_value:.4f}")
