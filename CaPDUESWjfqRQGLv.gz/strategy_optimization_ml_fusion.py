"""
策略优化迭代 - 多因子信号融合和机器学习增强
包含多因子融合、机器学习模型、动态参数调整、策略组合优化
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from decimal import Decimal
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
import pickle


# ============================================================================
# 数据结构
# ============================================================================

@dataclass
class SignalComponent:
    """信号分量"""
    name: str
    value: float  # -1 到 1 之间
    weight: float = 1.0
    confidence: float = 0.5
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class FusedSignal:
    """融合信号"""
    symbol: str
    components: List[SignalComponent]
    fused_value: float  # -1 到 1 之间
    confidence: float
    action: str  # BUY, SELL, HOLD
    strength: str  # STRONG, MEDIUM, WEAK
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class MLPrediction:
    """机器学习预测"""
    symbol: str
    prediction: int  # 1: BUY, 0: HOLD, -1: SELL
    probability: float
    model_name: str
    timestamp: datetime = field(default_factory=datetime.utcnow)


# ============================================================================
# 信号分量生成
# ============================================================================

class SignalComponentGenerator:
    """信号分量生成器"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
    
    def generate_ema_signal(self, prices: List[float], fast_period: int = 12, 
                           slow_period: int = 26) -> SignalComponent:
        """生成 EMA 信号"""
        if len(prices) < slow_period:
            return SignalComponent("EMA", 0, confidence=0)
        
        fast_ema = self._calculate_ema(prices, fast_period)
        slow_ema = self._calculate_ema(prices, slow_period)
        
        # 信号值：-1 到 1
        signal_value = (fast_ema - slow_ema) / slow_ema if slow_ema != 0 else 0
        signal_value = max(-1, min(1, signal_value * 10))  # 归一化
        
        confidence = min(1.0, abs(signal_value))
        
        return SignalComponent(
            name="EMA",
            value=signal_value,
            weight=0.3,
            confidence=confidence,
        )
    
    def generate_rsi_signal(self, prices: List[float], period: int = 14) -> SignalComponent:
        """生成 RSI 信号"""
        if len(prices) < period:
            return SignalComponent("RSI", 0, confidence=0)
        
        rsi = self._calculate_rsi(prices, period)
        
        # 信号值：-1 到 1
        # RSI < 30: 超卖（买入信号）
        # RSI > 70: 超买（卖出信号）
        if rsi < 30:
            signal_value = -1 + (rsi / 30)  # -1 到 0
        elif rsi > 70:
            signal_value = (rsi - 70) / 30  # 0 到 1
        else:
            signal_value = 0
        
        confidence = 1.0 if rsi < 30 or rsi > 70 else 0.5
        
        return SignalComponent(
            name="RSI",
            value=signal_value,
            weight=0.25,
            confidence=confidence,
        )
    
    def generate_macd_signal(self, prices: List[float]) -> SignalComponent:
        """生成 MACD 信号"""
        if len(prices) < 26:
            return SignalComponent("MACD", 0, confidence=0)
        
        ema12 = self._calculate_ema(prices, 12)
        ema26 = self._calculate_ema(prices, 26)
        macd = ema12 - ema26
        
        signal_line = self._calculate_ema([macd], 9)
        histogram = macd - signal_line
        
        # 信号值：-1 到 1
        signal_value = np.tanh(histogram / 100)  # 使用 tanh 归一化
        
        confidence = min(1.0, abs(histogram) / 100)
        
        return SignalComponent(
            name="MACD",
            value=signal_value,
            weight=0.25,
            confidence=confidence,
        )
    
    def generate_volatility_signal(self, prices: List[float], period: int = 20) -> SignalComponent:
        """生成波动率信号"""
        if len(prices) < period:
            return SignalComponent("Volatility", 0, confidence=0)
        
        recent_prices = prices[-period:]
        volatility = np.std(recent_prices) / np.mean(recent_prices)
        
        # 高波动率：卖出信号（风险大）
        # 低波动率：买入信号（机会多）
        signal_value = -volatility / 0.1  # 假设 10% 是基准
        signal_value = max(-1, min(1, signal_value))
        
        confidence = 0.5
        
        return SignalComponent(
            name="Volatility",
            value=signal_value,
            weight=0.2,
            confidence=confidence,
        )
    
    def _calculate_ema(self, prices: List[float], period: int) -> float:
        """计算 EMA"""
        if len(prices) < period:
            return np.mean(prices)
        
        multiplier = 2 / (period + 1)
        ema = np.mean(prices[:period])
        
        for price in prices[period:]:
            ema = price * multiplier + ema * (1 - multiplier)
        
        return ema
    
    def _calculate_rsi(self, prices: List[float], period: int) -> float:
        """计算 RSI"""
        if len(prices) < period + 1:
            return 50
        
        deltas = np.diff(prices)
        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)
        
        avg_gain = np.mean(gains[-period:])
        avg_loss = np.mean(losses[-period:])
        
        if avg_loss == 0:
            return 100 if avg_gain > 0 else 50
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi


# ============================================================================
# 多因子信号融合
# ============================================================================

class MultiFactorSignalFusion:
    """多因子信号融合"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.component_generator = SignalComponentGenerator(logger)
    
    def fuse_signals(self, symbol: str, prices: List[float]) -> FusedSignal:
        """融合多个信号"""
        # 生成各个信号分量
        components = [
            self.component_generator.generate_ema_signal(prices),
            self.component_generator.generate_rsi_signal(prices),
            self.component_generator.generate_macd_signal(prices),
            self.component_generator.generate_volatility_signal(prices),
        ]
        
        # 加权融合
        total_weight = sum(c.weight for c in components)
        fused_value = sum(c.value * c.weight for c in components) / total_weight if total_weight > 0 else 0
        
        # 计算融合信号的置信度
        confidence = sum(c.confidence * c.weight for c in components) / total_weight if total_weight > 0 else 0
        
        # 确定交易方向
        if fused_value > 0.3:
            action = "BUY"
            strength = "STRONG" if fused_value > 0.6 else "MEDIUM"
        elif fused_value < -0.3:
            action = "SELL"
            strength = "STRONG" if fused_value < -0.6 else "MEDIUM"
        else:
            action = "HOLD"
            strength = "WEAK"
        
        return FusedSignal(
            symbol=symbol,
            components=components,
            fused_value=fused_value,
            confidence=confidence,
            action=action,
            strength=strength,
        )


# ============================================================================
# 机器学习模型
# ============================================================================

class MLSignalPredictor:
    """机器学习信号预测器"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.scaler = StandardScaler()
        self.rf_model: Optional[RandomForestClassifier] = None
        self.gb_model: Optional[GradientBoostingClassifier] = None
        self.model_trained = False
    
    def train_models(self, X_train: np.ndarray, y_train: np.ndarray):
        """训练机器学习模型"""
        # 标准化特征
        X_scaled = self.scaler.fit_transform(X_train)
        
        # 训练随机森林模型
        self.rf_model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42,
            n_jobs=-1,
        )
        self.rf_model.fit(X_scaled, y_train)
        
        # 训练梯度提升模型
        self.gb_model = GradientBoostingClassifier(
            n_estimators=100,
            learning_rate=0.1,
            max_depth=5,
            random_state=42,
        )
        self.gb_model.fit(X_scaled, y_train)
        
        self.model_trained = True
        self.logger.info("ML models trained successfully")
    
    def predict(self, X: np.ndarray) -> Tuple[MLPrediction, MLPrediction]:
        """进行预测"""
        if not self.model_trained:
            raise RuntimeError("Models not trained yet")
        
        X_scaled = self.scaler.transform(X)
        
        # 随机森林预测
        rf_pred = self.rf_model.predict(X_scaled)[0]
        rf_prob = self.rf_model.predict_proba(X_scaled)[0]
        rf_confidence = max(rf_prob)
        
        # 梯度提升预测
        gb_pred = self.gb_model.predict(X_scaled)[0]
        gb_prob = self.gb_model.predict_proba(X_scaled)[0]
        gb_confidence = max(gb_prob)
        
        rf_prediction = MLPrediction(
            symbol="",
            prediction=rf_pred,
            probability=rf_confidence,
            model_name="RandomForest",
        )
        
        gb_prediction = MLPrediction(
            symbol="",
            prediction=gb_pred,
            probability=gb_confidence,
            model_name="GradientBoosting",
        )
        
        return rf_prediction, gb_prediction
    
    def save_models(self, filepath: str):
        """保存模型"""
        with open(filepath, "wb") as f:
            pickle.dump({
                "scaler": self.scaler,
                "rf_model": self.rf_model,
                "gb_model": self.gb_model,
            }, f)
        self.logger.info(f"Models saved to {filepath}")
    
    def load_models(self, filepath: str):
        """加载模型"""
        with open(filepath, "rb") as f:
            data = pickle.load(f)
            self.scaler = data["scaler"]
            self.rf_model = data["rf_model"]
            self.gb_model = data["gb_model"]
        self.model_trained = True
        self.logger.info(f"Models loaded from {filepath}")


# ============================================================================
# 动态参数调整
# ============================================================================

class DynamicParameterAdjuster:
    """动态参数调整器"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.base_parameters = {
            "ema_fast": 12,
            "ema_slow": 26,
            "rsi_period": 14,
            "volatility_period": 20,
        }
        self.current_parameters = self.base_parameters.copy()
        self.adjustment_history: List[Dict] = []
    
    def adjust_parameters(self, market_condition: str, volatility: float):
        """根据市场条件调整参数"""
        if market_condition == "trending":
            # 趋势市场：使用较长周期
            self.current_parameters["ema_fast"] = 15
            self.current_parameters["ema_slow"] = 35
        elif market_condition == "ranging":
            # 盘整市场：使用较短周期
            self.current_parameters["ema_fast"] = 8
            self.current_parameters["ema_slow"] = 17
        elif market_condition == "volatile":
            # 高波动市场：使用中等周期
            self.current_parameters["ema_fast"] = 10
            self.current_parameters["ema_slow"] = 25
        
        # 根据波动率调整 RSI 周期
        if volatility > 0.05:
            self.current_parameters["rsi_period"] = 21
        else:
            self.current_parameters["rsi_period"] = 14
        
        self.adjustment_history.append({
            "timestamp": datetime.utcnow(),
            "market_condition": market_condition,
            "volatility": volatility,
            "parameters": self.current_parameters.copy(),
        })
        
        self.logger.info(f"Parameters adjusted for {market_condition} market")
    
    def get_current_parameters(self) -> Dict:
        """获取当前参数"""
        return self.current_parameters.copy()


# ============================================================================
# 策略组合优化
# ============================================================================

class StrategyPortfolioOptimizer:
    """策略组合优化器"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.strategies: Dict[str, Dict] = {}
    
    def register_strategy(self, name: str, performance_metrics: Dict):
        """注册策略"""
        self.strategies[name] = {
            "name": name,
            "win_rate": performance_metrics.get("win_rate", 0.5),
            "profit_factor": performance_metrics.get("profit_factor", 1.0),
            "sharpe_ratio": performance_metrics.get("sharpe_ratio", 0.5),
            "max_drawdown": performance_metrics.get("max_drawdown", 0.2),
            "weight": 0.0,
        }
    
    def optimize_weights(self) -> Dict[str, float]:
        """优化策略权重"""
        if not self.strategies:
            return {}
        
        # 计算每个策略的得分
        scores = {}
        for name, strategy in self.strategies.items():
            score = (
                strategy["win_rate"] * 0.3 +
                strategy["profit_factor"] * 0.3 +
                strategy["sharpe_ratio"] * 0.2 -
                strategy["max_drawdown"] * 0.2
            )
            scores[name] = max(0, score)
        
        # 归一化权重
        total_score = sum(scores.values())
        if total_score > 0:
            weights = {name: score / total_score for name, score in scores.items()}
        else:
            weights = {name: 1 / len(self.strategies) for name in self.strategies}
        
        # 更新策略权重
        for name, weight in weights.items():
            self.strategies[name]["weight"] = weight
        
        self.logger.info(f"Strategy weights optimized: {weights}")
        
        return weights
    
    def combine_signals(self, signals: Dict[str, float]) -> float:
        """组合多个策略的信号"""
        combined_signal = 0
        for name, signal in signals.items():
            if name in self.strategies:
                weight = self.strategies[name]["weight"]
                combined_signal += signal * weight
        
        return combined_signal


# ============================================================================
# 主程序
# ============================================================================

def main():
    """主程序"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    logger.info("=== Strategy Optimization - ML & Signal Fusion Test ===")
    
    # 1. 多因子信号融合
    logger.info("Testing multi-factor signal fusion...")
    fusion = MultiFactorSignalFusion(logger)
    
    # 模拟价格数据
    prices = [50000 + i * 100 for i in range(100)]
    fused_signal = fusion.fuse_signals("BTCUSDT", prices)
    logger.info(f"Fused signal: {fused_signal}")
    
    # 2. 机器学习预测
    logger.info("Testing ML prediction...")
    ml_predictor = MLSignalPredictor(logger)
    
    # 生成训练数据
    X_train = np.random.randn(1000, 10)
    y_train = np.random.randint(0, 3, 1000)  # 0: HOLD, 1: BUY, 2: SELL
    
    ml_predictor.train_models(X_train, y_train)
    
    # 进行预测
    X_test = np.random.randn(1, 10)
    rf_pred, gb_pred = ml_predictor.predict(X_test)
    logger.info(f"RF prediction: {rf_pred}")
    logger.info(f"GB prediction: {gb_pred}")
    
    # 3. 动态参数调整
    logger.info("Testing dynamic parameter adjustment...")
    param_adjuster = DynamicParameterAdjuster(logger)
    param_adjuster.adjust_parameters("trending", 0.03)
    logger.info(f"Current parameters: {param_adjuster.get_current_parameters()}")
    
    # 4. 策略组合优化
    logger.info("Testing strategy portfolio optimization...")
    portfolio = StrategyPortfolioOptimizer(logger)
    
    portfolio.register_strategy("strategy_1", {
        "win_rate": 0.55,
        "profit_factor": 1.5,
        "sharpe_ratio": 1.2,
        "max_drawdown": 0.15,
    })
    
    portfolio.register_strategy("strategy_2", {
        "win_rate": 0.60,
        "profit_factor": 1.8,
        "sharpe_ratio": 1.5,
        "max_drawdown": 0.12,
    })
    
    weights = portfolio.optimize_weights()
    logger.info(f"Optimized weights: {weights}")


if __name__ == "__main__":
    main()
