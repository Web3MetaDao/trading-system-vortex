"""
监控和告警系统
包含 Prometheus 指标、Grafana 仪表板、告警规则
"""

import time
import logging
from datetime import datetime
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass
from enum import Enum
from abc import ABC, abstractmethod

# ============================================================================
# 告警级别和规则
# ============================================================================

class AlertLevel(Enum):
    """告警级别"""
    P1_CRITICAL = "P1_CRITICAL"  # 严重 - 系统崩溃、账户亏损 > 5%
    P2_WARNING = "P2_WARNING"    # 警告 - 风控触发、连续亏损
    P3_INFO = "P3_INFO"          # 信息 - 性能下降、信号异常
    P4_DEBUG = "P4_DEBUG"        # 调试 - 常规操作、参数变化


class NotificationChannel(Enum):
    """通知渠道"""
    PHONE = "phone"
    SMS = "sms"
    EMAIL = "email"
    SLACK = "slack"
    WEBHOOK = "webhook"


@dataclass
class Alert:
    """告警"""
    alert_id: str
    level: AlertLevel
    title: str
    description: str
    timestamp: datetime
    service: str
    metric: str
    value: float
    threshold: float
    channels: List[NotificationChannel]
    acknowledged: bool = False
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[datetime] = None


# ============================================================================
# 指标收集器
# ============================================================================

class MetricCollector:
    """指标收集器"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.metrics: Dict[str, List[float]] = {}
        self.start_time = time.time()
    
    def record_metric(self, name: str, value: float, labels: Optional[Dict] = None) -> None:
        """记录指标"""
        key = f"{name}:{labels}" if labels else name
        
        if key not in self.metrics:
            self.metrics[key] = []
        
        self.metrics[key].append(value)
        
        # 只保留最近 1000 个数据点
        if len(self.metrics[key]) > 1000:
            self.metrics[key] = self.metrics[key][-1000:]
    
    def get_metric(self, name: str, labels: Optional[Dict] = None) -> Optional[float]:
        """获取指标"""
        key = f"{name}:{labels}" if labels else name
        
        if key in self.metrics and self.metrics[key]:
            return self.metrics[key][-1]
        
        return None
    
    def get_metric_stats(self, name: str, labels: Optional[Dict] = None) -> Dict:
        """获取指标统计"""
        key = f"{name}:{labels}" if labels else name
        
        if key not in self.metrics or not self.metrics[key]:
            return {}
        
        values = self.metrics[key]
        
        return {
            'count': len(values),
            'min': min(values),
            'max': max(values),
            'avg': sum(values) / len(values),
            'latest': values[-1],
        }


# ============================================================================
# 系统指标
# ============================================================================

class SystemMetrics:
    """系统指标"""
    
    def __init__(self, collector: MetricCollector):
        self.collector = collector
    
    def record_cpu_usage(self, value: float) -> None:
        """记录 CPU 使用率"""
        self.collector.record_metric('system_cpu_usage_percent', value)
    
    def record_memory_usage(self, value: float) -> None:
        """记录内存使用率"""
        self.collector.record_metric('system_memory_usage_percent', value)
    
    def record_disk_usage(self, value: float) -> None:
        """记录磁盘使用率"""
        self.collector.record_metric('system_disk_usage_percent', value)
    
    def record_network_latency(self, value: float) -> None:
        """记录网络延迟"""
        self.collector.record_metric('system_network_latency_ms', value)
    
    def record_api_response_time(self, endpoint: str, value: float) -> None:
        """记录 API 响应时间"""
        self.collector.record_metric('system_api_response_time_ms', value, {'endpoint': endpoint})


# ============================================================================
# 交易指标
# ============================================================================

class TradingMetrics:
    """交易指标"""
    
    def __init__(self, collector: MetricCollector):
        self.collector = collector
    
    def record_pnl(self, value: float) -> None:
        """记录 P&L"""
        self.collector.record_metric('trading_pnl', value)
    
    def record_account_value(self, value: float) -> None:
        """记录账户净值"""
        self.collector.record_metric('trading_account_value', value)
    
    def record_drawdown(self, value: float) -> None:
        """记录回撤"""
        self.collector.record_metric('trading_drawdown_percent', value)
    
    def record_trade_count(self, value: int) -> None:
        """记录交易数量"""
        self.collector.record_metric('trading_trade_count', float(value))
    
    def record_win_rate(self, value: float) -> None:
        """记录胜率"""
        self.collector.record_metric('trading_win_rate_percent', value)
    
    def record_average_pnl(self, value: float) -> None:
        """记录平均 P&L"""
        self.collector.record_metric('trading_average_pnl', value)
    
    def record_sharpe_ratio(self, value: float) -> None:
        """记录夏普比率"""
        self.collector.record_metric('trading_sharpe_ratio', value)
    
    def record_max_drawdown(self, value: float) -> None:
        """记录最大回撤"""
        self.collector.record_metric('trading_max_drawdown_percent', value)


# ============================================================================
# 策略指标
# ============================================================================

class StrategyMetrics:
    """策略指标"""
    
    def __init__(self, collector: MetricCollector):
        self.collector = collector
    
    def record_signal_count(self, signal_type: str, value: int) -> None:
        """记录信号数量"""
        self.collector.record_metric('strategy_signal_count', float(value), {'type': signal_type})
    
    def record_signal_accuracy(self, value: float) -> None:
        """记录信号准确性"""
        self.collector.record_metric('strategy_signal_accuracy_percent', value)
    
    def record_false_signal_rate(self, value: float) -> None:
        """记录虚假信号率"""
        self.collector.record_metric('strategy_false_signal_rate_percent', value)
    
    def record_parameter_value(self, param_name: str, value: float) -> None:
        """记录参数值"""
        self.collector.record_metric('strategy_parameter_value', value, {'name': param_name})
    
    def record_strategy_status(self, status: str) -> None:
        """记录策略状态"""
        # 0: stopped, 1: running, 2: paused
        status_map = {'stopped': 0, 'running': 1, 'paused': 2}
        self.collector.record_metric('strategy_status', float(status_map.get(status, 0)))


# ============================================================================
# 告警规则
# ============================================================================

class AlertRule:
    """告警规则"""
    
    def __init__(self, name: str, metric: str, threshold: float, level: AlertLevel,
                 channels: List[NotificationChannel], comparison: str = '>'):
        self.name = name
        self.metric = metric
        self.threshold = threshold
        self.level = level
        self.channels = channels
        self.comparison = comparison  # '>', '<', '==', '!='
        self.last_alert_time = 0
        self.alert_cooldown = 60  # 60 秒冷却时间
    
    def should_trigger(self, current_value: float) -> bool:
        """判断是否应该触发告警"""
        # 检查冷却时间
        if time.time() - self.last_alert_time < self.alert_cooldown:
            return False
        
        # 检查阈值
        if self.comparison == '>':
            return current_value > self.threshold
        elif self.comparison == '<':
            return current_value < self.threshold
        elif self.comparison == '==':
            return current_value == self.threshold
        elif self.comparison == '!=':
            return current_value != self.threshold
        
        return False
    
    def mark_triggered(self) -> None:
        """标记已触发"""
        self.last_alert_time = time.time()


# ============================================================================
# 告警管理器
# ============================================================================

class AlertManager:
    """告警管理器"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.rules: List[AlertRule] = []
        self.alerts: Dict[str, Alert] = {}
        self.notifiers: Dict[NotificationChannel, Callable] = {}
    
    def add_rule(self, rule: AlertRule) -> None:
        """添加告警规则"""
        self.rules.append(rule)
        self.logger.info(f"Alert rule added: {rule.name}")
    
    def register_notifier(self, channel: NotificationChannel, notifier: Callable) -> None:
        """注册通知器"""
        self.notifiers[channel] = notifier
        self.logger.info(f"Notifier registered: {channel.value}")
    
    async def check_rules(self, metrics: Dict[str, float]) -> List[Alert]:
        """检查告警规则"""
        triggered_alerts = []
        
        for rule in self.rules:
            if rule.metric in metrics:
                current_value = metrics[rule.metric]
                
                if rule.should_trigger(current_value):
                    alert = Alert(
                        alert_id=f"{rule.name}_{time.time()}",
                        level=rule.level,
                        title=rule.name,
                        description=f"{rule.metric} = {current_value} (threshold: {rule.threshold})",
                        timestamp=datetime.utcnow(),
                        service="unknown",
                        metric=rule.metric,
                        value=current_value,
                        threshold=rule.threshold,
                        channels=rule.channels,
                    )
                    
                    self.alerts[alert.alert_id] = alert
                    triggered_alerts.append(alert)
                    rule.mark_triggered()
                    
                    self.logger.warning(f"Alert triggered: {rule.name}")
        
        return triggered_alerts
    
    async def notify(self, alert: Alert) -> None:
        """发送通知"""
        for channel in alert.channels:
            if channel in self.notifiers:
                try:
                    await self.notifiers[channel](alert)
                    self.logger.info(f"Notification sent via {channel.value}")
                except Exception as e:
                    self.logger.error(f"Failed to send notification via {channel.value}: {e}")
    
    def acknowledge_alert(self, alert_id: str, acknowledged_by: str) -> bool:
        """确认告警"""
        if alert_id in self.alerts:
            alert = self.alerts[alert_id]
            alert.acknowledged = True
            alert.acknowledged_by = acknowledged_by
            alert.acknowledged_at = datetime.utcnow()
            self.logger.info(f"Alert acknowledged: {alert_id}")
            return True
        return False


# ============================================================================
# 监控系统
# ============================================================================

class MonitoringSystem:
    """监控系统"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.collector = MetricCollector(logger)
        self.system_metrics = SystemMetrics(self.collector)
        self.trading_metrics = TradingMetrics(self.collector)
        self.strategy_metrics = StrategyMetrics(self.collector)
        self.alert_manager = AlertManager(logger)
        self._setup_default_rules()
    
    def _setup_default_rules(self) -> None:
        """设置默认告警规则"""
        
        # P1 严重告警
        self.alert_manager.add_rule(AlertRule(
            name="CPU Usage Critical",
            metric="system_cpu_usage_percent",
            threshold=90,
            level=AlertLevel.P1_CRITICAL,
            channels=[NotificationChannel.PHONE, NotificationChannel.SMS],
            comparison='>'
        ))
        
        self.alert_manager.add_rule(AlertRule(
            name="Memory Usage Critical",
            metric="system_memory_usage_percent",
            threshold=95,
            level=AlertLevel.P1_CRITICAL,
            channels=[NotificationChannel.PHONE, NotificationChannel.SMS],
            comparison='>'
        ))
        
        self.alert_manager.add_rule(AlertRule(
            name="Daily Loss Limit",
            metric="trading_pnl",
            threshold=-2000,  # 假设账户 $100,000，2% = $2,000
            level=AlertLevel.P1_CRITICAL,
            channels=[NotificationChannel.PHONE, NotificationChannel.SMS],
            comparison='<'
        ))
        
        # P2 警告告警
        self.alert_manager.add_rule(AlertRule(
            name="High Drawdown",
            metric="trading_drawdown_percent",
            threshold=15,
            level=AlertLevel.P2_WARNING,
            channels=[NotificationChannel.SMS, NotificationChannel.EMAIL],
            comparison='>'
        ))
        
        self.alert_manager.add_rule(AlertRule(
            name="Low Win Rate",
            metric="trading_win_rate_percent",
            threshold=40,
            level=AlertLevel.P2_WARNING,
            channels=[NotificationChannel.EMAIL],
            comparison='<'
        ))
        
        # P3 信息告警
        self.alert_manager.add_rule(AlertRule(
            name="High API Latency",
            metric="system_api_response_time_ms",
            threshold=1000,
            level=AlertLevel.P3_INFO,
            channels=[NotificationChannel.EMAIL],
            comparison='>'
        ))
        
        self.alert_manager.add_rule(AlertRule(
            name="High False Signal Rate",
            metric="strategy_false_signal_rate_percent",
            threshold=10,
            level=AlertLevel.P3_INFO,
            channels=[NotificationChannel.EMAIL],
            comparison='>'
        ))
        
        self.logger.info("Default alert rules set up")
    
    async def check_and_alert(self) -> List[Alert]:
        """检查指标并触发告警"""
        # 获取所有指标
        metrics = {}
        for key in self.collector.metrics:
            metric_name = key.split(':')[0]
            if metric_name not in metrics:
                stats = self.collector.get_metric_stats(metric_name)
                if 'latest' in stats:
                    metrics[metric_name] = stats['latest']
        
        # 检查告警规则
        alerts = await self.alert_manager.check_rules(metrics)
        
        # 发送通知
        for alert in alerts:
            await self.alert_manager.notify(alert)
        
        return alerts
    
    def get_dashboard_data(self) -> Dict:
        """获取仪表板数据"""
        dashboard_data = {
            'timestamp': datetime.utcnow().isoformat(),
            'system_metrics': {},
            'trading_metrics': {},
            'strategy_metrics': {},
            'alerts': [],
        }
        
        # 系统指标
        for metric_name in ['system_cpu_usage_percent', 'system_memory_usage_percent',
                           'system_disk_usage_percent', 'system_network_latency_ms']:
            stats = self.collector.get_metric_stats(metric_name)
            dashboard_data['system_metrics'][metric_name] = stats
        
        # 交易指标
        for metric_name in ['trading_pnl', 'trading_account_value', 'trading_drawdown_percent',
                           'trading_win_rate_percent', 'trading_sharpe_ratio']:
            stats = self.collector.get_metric_stats(metric_name)
            dashboard_data['trading_metrics'][metric_name] = stats
        
        # 策略指标
        for metric_name in ['strategy_signal_count', 'strategy_signal_accuracy_percent',
                           'strategy_false_signal_rate_percent']:
            stats = self.collector.get_metric_stats(metric_name)
            dashboard_data['strategy_metrics'][metric_name] = stats
        
        # 告警
        for alert in self.alert_manager.alerts.values():
            if not alert.acknowledged:
                dashboard_data['alerts'].append({
                    'alert_id': alert.alert_id,
                    'level': alert.level.value,
                    'title': alert.title,
                    'description': alert.description,
                    'timestamp': alert.timestamp.isoformat(),
                })
        
        return dashboard_data


# ============================================================================
# 主程序
# ============================================================================

async def main():
    """主程序"""
    # 配置日志
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    # 初始化监控系统
    monitoring = MonitoringSystem(logger)
    
    # 注册通知器
    async def phone_notifier(alert: Alert):
        logger.info(f"[PHONE] {alert.title}: {alert.description}")
    
    async def sms_notifier(alert: Alert):
        logger.info(f"[SMS] {alert.title}: {alert.description}")
    
    async def email_notifier(alert: Alert):
        logger.info(f"[EMAIL] {alert.title}: {alert.description}")
    
    monitoring.alert_manager.register_notifier(NotificationChannel.PHONE, phone_notifier)
    monitoring.alert_manager.register_notifier(NotificationChannel.SMS, sms_notifier)
    monitoring.alert_manager.register_notifier(NotificationChannel.EMAIL, email_notifier)
    
    # 模拟指标
    monitoring.system_metrics.record_cpu_usage(45.0)
    monitoring.system_metrics.record_memory_usage(60.0)
    monitoring.trading_metrics.record_pnl(5000.0)
    monitoring.trading_metrics.record_account_value(105000.0)
    monitoring.trading_metrics.record_drawdown(5.0)
    monitoring.trading_metrics.record_win_rate(55.0)
    monitoring.strategy_metrics.record_false_signal_rate(8.0)
    
    # 检查和告警
    alerts = await monitoring.check_and_alert()
    logger.info(f"Triggered {len(alerts)} alerts")
    
    # 获取仪表板数据
    dashboard = monitoring.get_dashboard_data()
    logger.info(f"Dashboard data: {dashboard}")


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
