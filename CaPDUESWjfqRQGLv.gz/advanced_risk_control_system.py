"""
企业级多层风控系统
包含 L1-L5 五层风控、实时监控、异常检测、自动止损
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from decimal import Decimal
import asyncio


# ============================================================================
# 数据结构
# ============================================================================

class RiskLevel(Enum):
    """风险等级"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class RiskMetrics:
    """风险指标"""
    total_position: Decimal = Decimal("0")
    daily_loss: Decimal = Decimal("0")
    max_drawdown: Decimal = Decimal("0")
    consecutive_losses: int = 0
    portfolio_value: Decimal = Decimal("0")
    margin_usage: Decimal = Decimal("0")
    leverage_ratio: Decimal = Decimal("1")
    
    def calculate_risk_level(self) -> RiskLevel:
        """计算风险等级"""
        if self.margin_usage > Decimal("90") or self.leverage_ratio > Decimal("10"):
            return RiskLevel.CRITICAL
        elif self.margin_usage > Decimal("70") or self.leverage_ratio > Decimal("5"):
            return RiskLevel.HIGH
        elif self.margin_usage > Decimal("50") or self.leverage_ratio > Decimal("2"):
            return RiskLevel.MEDIUM
        else:
            return RiskLevel.LOW


@dataclass
class RiskAlert:
    """风险告警"""
    alert_id: str
    level: RiskLevel
    message: str
    metrics: RiskMetrics
    timestamp: datetime = field(default_factory=datetime.utcnow)
    acknowledged: bool = False


# ============================================================================
# L1 - 头寸限制
# ============================================================================

class L1PositionLimitControl:
    """L1 - 头寸限制控制"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.max_position_per_symbol = Decimal("10")
        self.max_total_position = Decimal("100")
        self.current_positions: Dict[str, Decimal] = {}
    
    def check_position_limit(self, symbol: str, amount: Decimal) -> Tuple[bool, str]:
        """检查头寸限制"""
        # 检查单个标的头寸限制
        current_position = self.current_positions.get(symbol, Decimal("0"))
        new_position = current_position + amount
        
        if new_position > self.max_position_per_symbol:
            return False, f"Position limit exceeded for {symbol}: {new_position} > {self.max_position_per_symbol}"
        
        # 检查总头寸限制
        total_position = sum(self.current_positions.values()) + amount
        
        if total_position > self.max_total_position:
            return False, f"Total position limit exceeded: {total_position} > {self.max_total_position}"
        
        return True, "Position limit check passed"
    
    def update_position(self, symbol: str, amount: Decimal):
        """更新头寸"""
        self.current_positions[symbol] = self.current_positions.get(symbol, Decimal("0")) + amount


# ============================================================================
# L2 - 日度亏损限制
# ============================================================================

class L2DailyLossControl:
    """L2 - 日度亏损限制控制"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.max_daily_loss = Decimal("-5000")  # 最多亏损 5000
        self.daily_pnl: Dict[str, Decimal] = {}
        self.daily_trades: List[Dict] = []
    
    def check_daily_loss(self, current_pnl: Decimal) -> Tuple[bool, str]:
        """检查日度亏损"""
        today = datetime.utcnow().date()
        today_pnl = self._get_today_pnl()
        
        if today_pnl + current_pnl < self.max_daily_loss:
            return False, f"Daily loss limit exceeded: {today_pnl + current_pnl} < {self.max_daily_loss}"
        
        return True, "Daily loss limit check passed"
    
    def _get_today_pnl(self) -> Decimal:
        """获取今天的 PnL"""
        today = datetime.utcnow().date()
        today_trades = [t for t in self.daily_trades if t["date"] == today]
        return sum(t["pnl"] for t in today_trades)
    
    def record_trade(self, pnl: Decimal):
        """记录交易"""
        self.daily_trades.append({
            "date": datetime.utcnow().date(),
            "pnl": pnl,
            "timestamp": datetime.utcnow(),
        })


# ============================================================================
# L3 - 最大回撤限制
# ============================================================================

class L3DrawdownControl:
    """L3 - 最大回撤限制控制"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.max_drawdown_ratio = Decimal("0.2")  # 最多回撤 20%
        self.peak_value = Decimal("100000")
        self.current_value = Decimal("100000")
    
    def check_drawdown(self) -> Tuple[bool, str]:
        """检查最大回撤"""
        drawdown_ratio = (self.peak_value - self.current_value) / self.peak_value
        
        if drawdown_ratio > self.max_drawdown_ratio:
            return False, f"Max drawdown exceeded: {drawdown_ratio:.2%} > {self.max_drawdown_ratio:.2%}"
        
        return True, "Drawdown limit check passed"
    
    def update_value(self, value: Decimal):
        """更新账户价值"""
        self.current_value = value
        if value > self.peak_value:
            self.peak_value = value


# ============================================================================
# L4 - 连续亏损限制
# ============================================================================

class L4ConsecutiveLossControl:
    """L4 - 连续亏损限制控制"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.max_consecutive_losses = 5
        self.consecutive_losses = 0
        self.trade_history: List[Dict] = []
    
    def check_consecutive_loss(self) -> Tuple[bool, str]:
        """检查连续亏损"""
        if self.consecutive_losses >= self.max_consecutive_losses:
            return False, f"Consecutive loss limit exceeded: {self.consecutive_losses} >= {self.max_consecutive_losses}"
        
        return True, "Consecutive loss limit check passed"
    
    def record_trade(self, pnl: Decimal):
        """记录交易"""
        self.trade_history.append({
            "pnl": pnl,
            "timestamp": datetime.utcnow(),
        })
        
        if pnl < 0:
            self.consecutive_losses += 1
        else:
            self.consecutive_losses = 0


# ============================================================================
# L5 - 系统级限制
# ============================================================================

class L5SystemLimitControl:
    """L5 - 系统级限制控制"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.max_open_orders = 100
        self.max_order_value = Decimal("50000")
        self.circuit_breaker_enabled = False
        self.circuit_breaker_threshold = Decimal("0.1")  # 10% 波动
    
    def check_system_limit(self, open_orders: int, order_value: Decimal) -> Tuple[bool, str]:
        """检查系统级限制"""
        # 检查开仓订单数
        if open_orders >= self.max_open_orders:
            return False, f"Max open orders exceeded: {open_orders} >= {self.max_open_orders}"
        
        # 检查单个订单价值
        if order_value > self.max_order_value:
            return False, f"Order value limit exceeded: {order_value} > {self.max_order_value}"
        
        return True, "System limit check passed"
    
    def check_circuit_breaker(self, price_change: Decimal) -> Tuple[bool, str]:
        """检查熔断机制"""
        if self.circuit_breaker_enabled and abs(price_change) > self.circuit_breaker_threshold:
            return False, f"Circuit breaker triggered: price change {price_change:.2%} > {self.circuit_breaker_threshold:.2%}"
        
        return True, "Circuit breaker check passed"


# ============================================================================
# 多层风控管理器
# ============================================================================

class MultiLayerRiskControlManager:
    """多层风控管理器"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.l1_position = L1PositionLimitControl(logger)
        self.l2_daily_loss = L2DailyLossControl(logger)
        self.l3_drawdown = L3DrawdownControl(logger)
        self.l4_consecutive = L4ConsecutiveLossControl(logger)
        self.l5_system = L5SystemLimitControl(logger)
        self.alerts: List[RiskAlert] = []
        self.risk_metrics = RiskMetrics()
    
    async def validate_trade(self, symbol: str, amount: Decimal, order_value: Decimal) -> Tuple[bool, List[str]]:
        """验证交易"""
        reasons = []
        
        # L1 - 头寸限制
        is_valid, message = self.l1_position.check_position_limit(symbol, amount)
        if not is_valid:
            reasons.append(f"L1: {message}")
        
        # L2 - 日度亏损限制
        is_valid, message = self.l2_daily_loss.check_daily_loss(Decimal("0"))
        if not is_valid:
            reasons.append(f"L2: {message}")
        
        # L3 - 最大回撤限制
        is_valid, message = self.l3_drawdown.check_drawdown()
        if not is_valid:
            reasons.append(f"L3: {message}")
        
        # L4 - 连续亏损限制
        is_valid, message = self.l4_consecutive.check_consecutive_loss()
        if not is_valid:
            reasons.append(f"L4: {message}")
        
        # L5 - 系统级限制
        open_orders = len([t for t in self.l4_consecutive.trade_history if t["pnl"] == 0])
        is_valid, message = self.l5_system.check_system_limit(open_orders, order_value)
        if not is_valid:
            reasons.append(f"L5: {message}")
        
        return len(reasons) == 0, reasons
    
    async def monitor_risk(self) -> RiskMetrics:
        """监控风险"""
        self.risk_metrics.calculate_risk_level()
        
        # 生成告警
        if self.risk_metrics.calculate_risk_level() == RiskLevel.CRITICAL:
            alert = RiskAlert(
                alert_id=f"ALERT_{datetime.utcnow().timestamp()}",
                level=RiskLevel.CRITICAL,
                message="Critical risk level detected",
                metrics=self.risk_metrics,
            )
            self.alerts.append(alert)
            self.logger.critical("Critical risk alert generated")
        
        return self.risk_metrics
    
    async def execute_stop_loss(self) -> bool:
        """执行止损"""
        if self.risk_metrics.calculate_risk_level() == RiskLevel.CRITICAL:
            self.logger.warning("Executing emergency stop loss")
            # 平仓所有头寸
            self.l1_position.current_positions.clear()
            return True
        
        return False


# ============================================================================
# 风险监控系统
# ============================================================================

class RiskMonitoringSystem:
    """风险监控系统"""
    
    def __init__(self, logger: logging.Logger, risk_manager: MultiLayerRiskControlManager):
        self.logger = logger
        self.risk_manager = risk_manager
        self.monitoring_interval = 10  # 秒
        self.alert_history: List[RiskAlert] = []
    
    async def start_monitoring(self):
        """启动监控"""
        while True:
            try:
                metrics = await self.risk_manager.monitor_risk()
                
                # 记录告警
                for alert in self.risk_manager.alerts:
                    if not alert.acknowledged:
                        self.alert_history.append(alert)
                        self.logger.warning(f"Risk alert: {alert.message}")
                
                await asyncio.sleep(self.monitoring_interval)
            
            except Exception as e:
                self.logger.error(f"Monitoring error: {e}")
                await asyncio.sleep(self.monitoring_interval)
    
    def get_alert_summary(self) -> Dict:
        """获取告警统计"""
        critical_alerts = [a for a in self.alert_history if a.level == RiskLevel.CRITICAL]
        high_alerts = [a for a in self.alert_history if a.level == RiskLevel.HIGH]
        
        return {
            "total_alerts": len(self.alert_history),
            "critical_alerts": len(critical_alerts),
            "high_alerts": len(high_alerts),
            "recent_alerts": [
                {
                    "timestamp": a.timestamp.isoformat(),
                    "level": a.level.value,
                    "message": a.message,
                }
                for a in self.alert_history[-10:]
            ],
        }


# ============================================================================
# 主程序
# ============================================================================

async def main():
    """主程序"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    # 初始化风控系统
    risk_manager = MultiLayerRiskControlManager(logger)
    monitoring_system = RiskMonitoringSystem(logger, risk_manager)
    
    logger.info("=== Advanced Risk Control System Test ===")
    
    # 1. 测试 L1 头寸限制
    is_valid, reasons = await risk_manager.validate_trade("BTCUSDT", Decimal("1"), Decimal("50000"))
    logger.info(f"L1 Position limit check: {is_valid}")
    
    # 2. 测试 L2 日度亏损限制
    risk_manager.l2_daily_loss.record_trade(Decimal("-1000"))
    is_valid, reasons = await risk_manager.validate_trade("BTCUSDT", Decimal("1"), Decimal("50000"))
    logger.info(f"L2 Daily loss check: {is_valid}")
    
    # 3. 测试 L3 最大回撤限制
    risk_manager.l3_drawdown.update_value(Decimal("90000"))
    is_valid, reasons = await risk_manager.validate_trade("BTCUSDT", Decimal("1"), Decimal("50000"))
    logger.info(f"L3 Drawdown check: {is_valid}")
    
    # 4. 测试 L4 连续亏损限制
    for _ in range(5):
        risk_manager.l4_consecutive.record_trade(Decimal("-100"))
    is_valid, reasons = await risk_manager.validate_trade("BTCUSDT", Decimal("1"), Decimal("50000"))
    logger.info(f"L4 Consecutive loss check: {is_valid}")
    
    # 5. 监控风险
    metrics = await risk_manager.monitor_risk()
    logger.info(f"Risk level: {metrics.calculate_risk_level().value}")
    
    # 6. 获取告警统计
    summary = monitoring_system.get_alert_summary()
    logger.info(f"Alert summary: {summary}")


if __name__ == "__main__":
    asyncio.run(main())
