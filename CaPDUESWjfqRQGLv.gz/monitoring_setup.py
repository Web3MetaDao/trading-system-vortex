#!/usr/bin/env python3
"""
交易系统基础监控设置脚本

功能：
1. 创建监控指标定义
2. 生成 Prometheus 配置
3. 创建告警规则
4. 生成 Grafana 仪表板配置
"""

import json
import yaml
from pathlib import Path
from datetime import datetime


class MonitoringSetup:
    """监控系统设置"""
    
    def __init__(self, output_dir: str = "."):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def create_metrics_definition(self) -> dict:
        """创建监控指标定义"""
        metrics = {
            "system": {
                "startup_time_ms": {
                    "description": "系统启动时间",
                    "unit": "ms",
                    "threshold": 10000,
                    "alert_level": "warning"
                },
                "cycle_duration_ms": {
                    "description": "交易循环执行时间",
                    "unit": "ms",
                    "threshold": 5000,
                    "alert_level": "warning"
                },
                "memory_usage_mb": {
                    "description": "内存占用",
                    "unit": "MB",
                    "threshold": 500,
                    "alert_level": "warning"
                },
                "error_count_per_hour": {
                    "description": "每小时错误数",
                    "unit": "count",
                    "threshold": 5,
                    "alert_level": "critical"
                },
                "cpu_usage_pct": {
                    "description": "CPU 使用率",
                    "unit": "%",
                    "threshold": 80,
                    "alert_level": "warning"
                }
            },
            "trading": {
                "signal_generation_rate": {
                    "description": "信号生成率",
                    "unit": "%",
                    "threshold": 50,
                    "alert_level": "warning"
                },
                "whipsaw_events_per_day": {
                    "description": "每日 Whipsaw 事件数",
                    "unit": "count",
                    "threshold": 5,
                    "alert_level": "warning"
                },
                "false_signal_rate": {
                    "description": "虚假信号率",
                    "unit": "%",
                    "threshold": 15,
                    "alert_level": "warning"
                },
                "average_pnl_pct": {
                    "description": "平均 PnL 百分比",
                    "unit": "%",
                    "threshold": -2,
                    "alert_level": "critical"
                },
                "open_positions": {
                    "description": "开放头寸数",
                    "unit": "count",
                    "threshold": 5,
                    "alert_level": "info"
                }
            },
            "data": {
                "data_health_status": {
                    "description": "数据健康状态",
                    "unit": "status",
                    "values": ["ok", "partial", "degraded"],
                    "alert_level": "warning"
                },
                "api_response_time_ms": {
                    "description": "API 响应时间",
                    "unit": "ms",
                    "threshold": 1000,
                    "alert_level": "warning"
                },
                "data_staleness_minutes": {
                    "description": "数据延迟",
                    "unit": "minutes",
                    "threshold": 10,
                    "alert_level": "critical"
                },
                "missing_data_rate": {
                    "description": "数据缺失率",
                    "unit": "%",
                    "threshold": 5,
                    "alert_level": "critical"
                }
            },
            "risk": {
                "daily_loss_pct": {
                    "description": "日度亏损百分比",
                    "unit": "%",
                    "threshold": -1,
                    "alert_level": "critical"
                },
                "max_drawdown_pct": {
                    "description": "最大回撤",
                    "unit": "%",
                    "threshold": -15,
                    "alert_level": "warning"
                },
                "consecutive_losses": {
                    "description": "连续亏损次数",
                    "unit": "count",
                    "threshold": 5,
                    "alert_level": "warning"
                },
                "risk_control_triggers": {
                    "description": "风控触发次数",
                    "unit": "count",
                    "threshold": 10,
                    "alert_level": "info"
                }
            }
        }
        
        return metrics
    
    def create_prometheus_config(self) -> dict:
        """创建 Prometheus 配置"""
        config = {
            "global": {
                "scrape_interval": "15s",
                "evaluation_interval": "15s",
                "external_labels": {
                    "monitor": "trading-system"
                }
            },
            "scrape_configs": [
                {
                    "job_name": "trading-system",
                    "static_configs": [
                        {
                            "targets": ["localhost:8000"]
                        }
                    ],
                    "scrape_interval": "5s",
                    "scrape_timeout": "3s"
                }
            ]
        }
        
        return config
    
    def create_alert_rules(self) -> dict:
        """创建告警规则"""
        rules = {
            "groups": [
                {
                    "name": "trading_system",
                    "interval": "30s",
                    "rules": [
                        {
                            "alert": "HighErrorRate",
                            "expr": "rate(error_count[5m]) > 0.1",
                            "for": "5m",
                            "labels": {
                                "severity": "critical"
                            },
                            "annotations": {
                                "summary": "系统错误率过高",
                                "description": "错误率: {{ $value }}"
                            }
                        },
                        {
                            "alert": "HighMemoryUsage",
                            "expr": "memory_usage_mb > 500",
                            "for": "10m",
                            "labels": {
                                "severity": "warning"
                            },
                            "annotations": {
                                "summary": "内存占用过高",
                                "description": "内存占用: {{ $value }} MB"
                            }
                        },
                        {
                            "alert": "DataStaleness",
                            "expr": "data_staleness_minutes > 10",
                            "for": "5m",
                            "labels": {
                                "severity": "critical"
                            },
                            "annotations": {
                                "summary": "数据延迟过高",
                                "description": "数据延迟: {{ $value }} 分钟"
                            }
                        },
                        {
                            "alert": "DailyLossThreshold",
                            "expr": "daily_loss_pct < -1",
                            "for": "1m",
                            "labels": {
                                "severity": "critical"
                            },
                            "annotations": {
                                "summary": "日度亏损超过阈值",
                                "description": "日度亏损: {{ $value }}%"
                            }
                        },
                        {
                            "alert": "WhipsawEvents",
                            "expr": "whipsaw_events_per_day > 5",
                            "for": "10m",
                            "labels": {
                                "severity": "warning"
                            },
                            "annotations": {
                                "summary": "Whipsaw 事件过多",
                                "description": "今日 Whipsaw 事件: {{ $value }}"
                            }
                        }
                    ]
                }
            ]
        }
        
        return rules
    
    def create_grafana_dashboard(self) -> dict:
        """创建 Grafana 仪表板配置"""
        dashboard = {
            "dashboard": {
                "title": "交易系统监控",
                "tags": ["trading", "system"],
                "timezone": "browser",
                "panels": [
                    {
                        "title": "系统健康状态",
                        "type": "stat",
                        "targets": [
                            {
                                "expr": "up{job='trading-system'}",
                                "legendFormat": "系统状态"
                            }
                        ]
                    },
                    {
                        "title": "内存占用趋势",
                        "type": "graph",
                        "targets": [
                            {
                                "expr": "memory_usage_mb",
                                "legendFormat": "内存 (MB)"
                            }
                        ]
                    },
                    {
                        "title": "循环执行时间",
                        "type": "graph",
                        "targets": [
                            {
                                "expr": "cycle_duration_ms",
                                "legendFormat": "执行时间 (ms)"
                            }
                        ]
                    },
                    {
                        "title": "交易信号",
                        "type": "graph",
                        "targets": [
                            {
                                "expr": "signal_generation_rate",
                                "legendFormat": "生成率 (%)"
                            }
                        ]
                    },
                    {
                        "title": "日度 PnL",
                        "type": "stat",
                        "targets": [
                            {
                                "expr": "average_pnl_pct",
                                "legendFormat": "PnL (%)"
                            }
                        ]
                    },
                    {
                        "title": "数据健康状态",
                        "type": "stat",
                        "targets": [
                            {
                                "expr": "data_health_status",
                                "legendFormat": "状态"
                            }
                        ]
                    },
                    {
                        "title": "错误率",
                        "type": "graph",
                        "targets": [
                            {
                                "expr": "rate(error_count[5m])",
                                "legendFormat": "错误率"
                            }
                        ]
                    },
                    {
                        "title": "开放头寸",
                        "type": "stat",
                        "targets": [
                            {
                                "expr": "open_positions",
                                "legendFormat": "头寸数"
                            }
                        ]
                    }
                ]
            }
        }
        
        return dashboard
    
    def create_logging_config(self) -> dict:
        """创建日志配置"""
        config = {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "standard": {
                    "format": "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
                },
                "detailed": {
                    "format": "%(asctime)s [%(levelname)s] %(name)s:%(filename)s:%(lineno)d: %(message)s"
                }
            },
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "level": "INFO",
                    "formatter": "standard",
                    "stream": "ext://sys.stdout"
                },
                "file": {
                    "class": "logging.handlers.RotatingFileHandler",
                    "level": "DEBUG",
                    "formatter": "detailed",
                    "filename": "logs/trading.log",
                    "maxBytes": 10485760,  # 10MB
                    "backupCount": 10
                },
                "error_file": {
                    "class": "logging.handlers.RotatingFileHandler",
                    "level": "ERROR",
                    "formatter": "detailed",
                    "filename": "logs/error.log",
                    "maxBytes": 10485760,
                    "backupCount": 5
                }
            },
            "loggers": {
                "trading_system": {
                    "level": "DEBUG",
                    "handlers": ["console", "file", "error_file"]
                }
            },
            "root": {
                "level": "INFO",
                "handlers": ["console", "file"]
            }
        }
        
        return config
    
    def save_all_configs(self):
        """保存所有配置文件"""
        
        # 1. 保存指标定义
        metrics = self.create_metrics_definition()
        metrics_file = self.output_dir / "metrics_definition.json"
        with open(metrics_file, 'w', encoding='utf-8') as f:
            json.dump(metrics, f, indent=2, ensure_ascii=False)
        print(f"✓ 指标定义已保存: {metrics_file}")
        
        # 2. 保存 Prometheus 配置
        prometheus_config = self.create_prometheus_config()
        prometheus_file = self.output_dir / "prometheus.yml"
        with open(prometheus_file, 'w', encoding='utf-8') as f:
            yaml.dump(prometheus_config, f, default_flow_style=False)
        print(f"✓ Prometheus 配置已保存: {prometheus_file}")
        
        # 3. 保存告警规则
        alert_rules = self.create_alert_rules()
        alert_file = self.output_dir / "alert_rules.yml"
        with open(alert_file, 'w', encoding='utf-8') as f:
            yaml.dump(alert_rules, f, default_flow_style=False)
        print(f"✓ 告警规则已保存: {alert_file}")
        
        # 4. 保存 Grafana 配置
        grafana_config = self.create_grafana_dashboard()
        grafana_file = self.output_dir / "grafana_dashboard.json"
        with open(grafana_file, 'w', encoding='utf-8') as f:
            json.dump(grafana_config, f, indent=2, ensure_ascii=False)
        print(f"✓ Grafana 配置已保存: {grafana_file}")
        
        # 5. 保存日志配置
        logging_config = self.create_logging_config()
        logging_file = self.output_dir / "logging_config.json"
        with open(logging_file, 'w', encoding='utf-8') as f:
            json.dump(logging_config, f, indent=2, ensure_ascii=False)
        print(f"✓ 日志配置已保存: {logging_file}")
        
        # 6. 生成 README
        self.generate_readme()
    
    def generate_readme(self):
        """生成监控设置说明"""
        readme = """# 交易系统监控设置

## 快速开始

### 1. 安装依赖
```bash
pip install prometheus-client pyyaml
```

### 2. 启动 Prometheus
```bash
docker run -d \\
  -p 9090:9090 \\
  -v $(pwd)/prometheus.yml:/etc/prometheus/prometheus.yml \\
  -v $(pwd)/alert_rules.yml:/etc/prometheus/alert_rules.yml \\
  prom/prometheus
```

### 3. 启动 Grafana
```bash
docker run -d \\
  -p 3000:3000 \\
  grafana/grafana
```

### 4. 导入仪表板
- 访问 http://localhost:3000
- 默认用户名/密码: admin/admin
- 导入 grafana_dashboard.json

## 监控指标

### 系统指标
- 启动时间: < 10s
- 循环时间: < 5s
- 内存占用: < 500MB
- 错误率: < 1%

### 交易指标
- 信号生成率: > 50%
- Whipsaw 事件: < 5/day
- 虚假信号率: < 15%
- 平均 PnL: > 0%

### 数据指标
- 数据健康: ok/partial/degraded
- API 响应时间: < 1000ms
- 数据延迟: < 10 minutes
- 数据缺失率: < 5%

## 告警规则

| 告警 | 条件 | 严重级别 |
|-----|------|--------|
| HighErrorRate | 错误率 > 0.1 | critical |
| HighMemoryUsage | 内存 > 500MB | warning |
| DataStaleness | 延迟 > 10min | critical |
| DailyLossThreshold | 日损 < -1% | critical |
| WhipsawEvents | 事件 > 5/day | warning |

## 日志位置

- 主日志: logs/trading.log
- 错误日志: logs/error.log

## 故障排查

### 无法连接 Prometheus
- 检查 Prometheus 是否运行: `curl http://localhost:9090`
- 检查配置文件语法: `promtool check config prometheus.yml`

### 告警未触发
- 检查告警规则: `promtool check rules alert_rules.yml`
- 检查 Alertmanager 配置

### 指标缺失
- 检查应用是否导出指标
- 检查 Prometheus 数据源配置
- 查看 Prometheus 日志

## 更多信息

- Prometheus 文档: https://prometheus.io/docs/
- Grafana 文档: https://grafana.com/docs/
"""
        
        readme_file = self.output_dir / "MONITORING_README.md"
        with open(readme_file, 'w', encoding='utf-8') as f:
            f.write(readme)
        print(f"✓ 监控说明已保存: {readme_file}")


def main():
    """主函数"""
    print("=" * 60)
    print("交易系统监控设置")
    print("=" * 60)
    
    setup = MonitoringSetup(output_dir="monitoring_config")
    setup.save_all_configs()
    
    print("\n" + "=" * 60)
    print("✓ 所有配置文件已生成")
    print("=" * 60)
    print("\n下一步:")
    print("1. 查看 monitoring_config/ 目录下的配置文件")
    print("2. 根据 MONITORING_README.md 部署监控系统")
    print("3. 在应用中集成 Prometheus 指标导出")


if __name__ == "__main__":
    main()
