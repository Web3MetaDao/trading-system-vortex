"""
企业级高可用架构和负载均衡系统
包含服务注册、负载均衡、健康检查、自动扩展
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import random


# ============================================================================
# 数据结构
# ============================================================================

class InstanceStatus(Enum):
    """实例状态"""
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    STARTING = "starting"
    STOPPING = "stopping"
    STOPPED = "stopped"


class LoadBalancingStrategy(Enum):
    """负载均衡策略"""
    ROUND_ROBIN = "round_robin"
    LEAST_CONNECTIONS = "least_connections"
    WEIGHTED_ROUND_ROBIN = "weighted_round_robin"
    IP_HASH = "ip_hash"


@dataclass
class ServiceInstance:
    """服务实例"""
    instance_id: str
    service_name: str
    host: str
    port: int
    status: InstanceStatus = InstanceStatus.STARTING
    weight: int = 1
    connections: int = 0
    max_connections: int = 1000
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_health_check: Optional[datetime] = None
    health_check_failures: int = 0
    
    def is_available(self) -> bool:
        """检查实例是否可用"""
        return (
            self.status == InstanceStatus.HEALTHY and
            self.connections < self.max_connections
        )


@dataclass
class HealthCheckResult:
    """健康检查结果"""
    instance_id: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    is_healthy: bool = False
    response_time_ms: float = 0
    error_message: Optional[str] = None


# ============================================================================
# 服务注册系统
# ============================================================================

class ServiceRegistry:
    """服务注册系统"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.services: Dict[str, List[ServiceInstance]] = {}
        self.registry_lock = asyncio.Lock()
    
    async def register_service(self, service_name: str, instance: ServiceInstance) -> bool:
        """注册服务实例"""
        async with self.registry_lock:
            if service_name not in self.services:
                self.services[service_name] = []
            
            # 检查实例是否已存在
            for existing_instance in self.services[service_name]:
                if existing_instance.instance_id == instance.instance_id:
                    self.logger.warning(f"Instance {instance.instance_id} already registered")
                    return False
            
            self.services[service_name].append(instance)
            self.logger.info(f"Service registered: {service_name}/{instance.instance_id}")
            
            return True
    
    async def deregister_service(self, service_name: str, instance_id: str) -> bool:
        """注销服务实例"""
        async with self.registry_lock:
            if service_name not in self.services:
                return False
            
            self.services[service_name] = [
                inst for inst in self.services[service_name]
                if inst.instance_id != instance_id
            ]
            
            self.logger.info(f"Service deregistered: {service_name}/{instance_id}")
            
            return True
    
    async def get_service_instances(self, service_name: str) -> List[ServiceInstance]:
        """获取服务实例列表"""
        if service_name not in self.services:
            return []
        
        return self.services[service_name]
    
    async def get_healthy_instances(self, service_name: str) -> List[ServiceInstance]:
        """获取健康的服务实例"""
        instances = await self.get_service_instances(service_name)
        return [inst for inst in instances if inst.is_available()]


# ============================================================================
# 健康检查系统
# ============================================================================

class HealthCheckSystem:
    """健康检查系统"""
    
    def __init__(self, logger: logging.Logger, service_registry: ServiceRegistry):
        self.logger = logger
        self.service_registry = service_registry
        self.health_check_results: List[HealthCheckResult] = []
        self.health_check_interval = 10  # 秒
        self.health_check_timeout = 5  # 秒
        self.max_failures_before_unhealthy = 3
    
    async def start_health_checks(self):
        """启动健康检查"""
        while True:
            try:
                await self._perform_health_checks()
                await asyncio.sleep(self.health_check_interval)
            except Exception as e:
                self.logger.error(f"Health check error: {e}")
                await asyncio.sleep(self.health_check_interval)
    
    async def _perform_health_checks(self):
        """执行健康检查"""
        for service_name, instances in self.service_registry.services.items():
            for instance in instances:
                result = await self._check_instance_health(instance)
                self.health_check_results.append(result)
                
                # 更新实例状态
                if result.is_healthy:
                    instance.health_check_failures = 0
                    if instance.status != InstanceStatus.HEALTHY:
                        instance.status = InstanceStatus.HEALTHY
                        self.logger.info(f"Instance recovered: {instance.instance_id}")
                else:
                    instance.health_check_failures += 1
                    if instance.health_check_failures >= self.max_failures_before_unhealthy:
                        instance.status = InstanceStatus.UNHEALTHY
                        self.logger.warning(f"Instance marked unhealthy: {instance.instance_id}")
                
                instance.last_health_check = datetime.utcnow()
    
    async def _check_instance_health(self, instance: ServiceInstance) -> HealthCheckResult:
        """检查实例健康状态"""
        result = HealthCheckResult(instance_id=instance.instance_id)
        
        try:
            # 这里应该调用实际的健康检查接口
            # 示例：HTTP GET /health, 数据库连接测试等
            
            # 模拟健康检查
            await asyncio.sleep(0.1)
            
            result.is_healthy = True
            result.response_time_ms = random.uniform(10, 100)
            
        except asyncio.TimeoutError:
            result.error_message = "Health check timeout"
        except Exception as e:
            result.error_message = str(e)
        
        return result


# ============================================================================
# 负载均衡系统
# ============================================================================

class LoadBalancer:
    """负载均衡系统"""
    
    def __init__(self, logger: logging.Logger, service_registry: ServiceRegistry):
        self.logger = logger
        self.service_registry = service_registry
        self.strategy = LoadBalancingStrategy.ROUND_ROBIN
        self.round_robin_index: Dict[str, int] = {}
        self.request_log: List[Dict] = []
    
    async def select_instance(self, service_name: str, client_ip: Optional[str] = None) -> Optional[ServiceInstance]:
        """选择实例"""
        healthy_instances = await self.service_registry.get_healthy_instances(service_name)
        
        if not healthy_instances:
            self.logger.warning(f"No healthy instances available for {service_name}")
            return None
        
        if self.strategy == LoadBalancingStrategy.ROUND_ROBIN:
            instance = self._select_round_robin(service_name, healthy_instances)
        elif self.strategy == LoadBalancingStrategy.LEAST_CONNECTIONS:
            instance = self._select_least_connections(healthy_instances)
        elif self.strategy == LoadBalancingStrategy.WEIGHTED_ROUND_ROBIN:
            instance = self._select_weighted_round_robin(service_name, healthy_instances)
        elif self.strategy == LoadBalancingStrategy.IP_HASH:
            instance = self._select_ip_hash(healthy_instances, client_ip)
        else:
            instance = healthy_instances[0]
        
        if instance:
            instance.connections += 1
            self.request_log.append({
                "timestamp": datetime.utcnow(),
                "service_name": service_name,
                "instance_id": instance.instance_id,
                "strategy": self.strategy.value,
            })
        
        return instance
    
    def _select_round_robin(self, service_name: str, instances: List[ServiceInstance]) -> ServiceInstance:
        """轮询选择"""
        if service_name not in self.round_robin_index:
            self.round_robin_index[service_name] = 0
        
        index = self.round_robin_index[service_name]
        instance = instances[index % len(instances)]
        
        self.round_robin_index[service_name] = (index + 1) % len(instances)
        
        return instance
    
    def _select_least_connections(self, instances: List[ServiceInstance]) -> ServiceInstance:
        """最少连接选择"""
        return min(instances, key=lambda inst: inst.connections)
    
    def _select_weighted_round_robin(self, service_name: str, instances: List[ServiceInstance]) -> ServiceInstance:
        """加权轮询选择"""
        total_weight = sum(inst.weight for inst in instances)
        
        if service_name not in self.round_robin_index:
            self.round_robin_index[service_name] = 0
        
        index = self.round_robin_index[service_name]
        current_weight = 0
        
        for instance in instances:
            current_weight += instance.weight
            if index < current_weight:
                self.round_robin_index[service_name] = (index + 1) % total_weight
                return instance
        
        return instances[0]
    
    def _select_ip_hash(self, instances: List[ServiceInstance], client_ip: Optional[str]) -> ServiceInstance:
        """IP 哈希选择"""
        if not client_ip:
            return instances[0]
        
        hash_value = hash(client_ip)
        index = hash_value % len(instances)
        
        return instances[index]
    
    async def release_instance(self, instance: ServiceInstance):
        """释放实例连接"""
        if instance.connections > 0:
            instance.connections -= 1


# ============================================================================
# 自动扩展系统
# ============================================================================

class AutoScalingSystem:
    """自动扩展系统"""
    
    def __init__(self, logger: logging.Logger, service_registry: ServiceRegistry):
        self.logger = logger
        self.service_registry = service_registry
        self.scaling_policies: Dict[str, Dict] = {}
        self.scaling_history: List[Dict] = []
    
    def set_scaling_policy(self, service_name: str, policy: Dict):
        """设置扩展策略"""
        self.scaling_policies[service_name] = {
            "min_instances": policy.get("min_instances", 1),
            "max_instances": policy.get("max_instances", 10),
            "target_cpu_usage": policy.get("target_cpu_usage", 70),
            "target_memory_usage": policy.get("target_memory_usage", 80),
            "scale_up_threshold": policy.get("scale_up_threshold", 80),
            "scale_down_threshold": policy.get("scale_down_threshold", 30),
            "cooldown_period": policy.get("cooldown_period", 300),  # 秒
        }
        
        self.logger.info(f"Scaling policy set for {service_name}: {policy}")
    
    async def evaluate_scaling(self, service_name: str) -> bool:
        """评估是否需要扩展"""
        if service_name not in self.scaling_policies:
            return False
        
        instances = await self.service_registry.get_service_instances(service_name)
        policy = self.scaling_policies[service_name]
        
        # 计算平均 CPU 使用率
        avg_cpu_usage = self._calculate_avg_cpu_usage(instances)
        
        # 计算平均内存使用率
        avg_memory_usage = self._calculate_avg_memory_usage(instances)
        
        # 检查是否需要扩展
        if (avg_cpu_usage > policy["scale_up_threshold"] or 
            avg_memory_usage > policy["scale_up_threshold"]):
            
            if len(instances) < policy["max_instances"]:
                await self._scale_up(service_name)
                return True
        
        # 检查是否需要缩容
        elif (avg_cpu_usage < policy["scale_down_threshold"] and 
              avg_memory_usage < policy["scale_down_threshold"]):
            
            if len(instances) > policy["min_instances"]:
                await self._scale_down(service_name)
                return True
        
        return False
    
    def _calculate_avg_cpu_usage(self, instances: List[ServiceInstance]) -> float:
        """计算平均 CPU 使用率"""
        # 这里应该从实际的监控系统获取 CPU 使用率
        # 示例：Prometheus, CloudWatch 等
        
        # 模拟计算
        return random.uniform(20, 90)
    
    def _calculate_avg_memory_usage(self, instances: List[ServiceInstance]) -> float:
        """计算平均内存使用率"""
        # 这里应该从实际的监控系统获取内存使用率
        
        # 模拟计算
        return random.uniform(20, 90)
    
    async def _scale_up(self, service_name: str) -> bool:
        """扩展"""
        self.logger.info(f"Scaling up service: {service_name}")
        
        # 创建新实例
        instances = await self.service_registry.get_service_instances(service_name)
        new_instance_id = f"{service_name}_instance_{len(instances) + 1}"
        
        new_instance = ServiceInstance(
            instance_id=new_instance_id,
            service_name=service_name,
            host="localhost",
            port=8000 + len(instances),
        )
        
        await self.service_registry.register_service(service_name, new_instance)
        
        self.scaling_history.append({
            "timestamp": datetime.utcnow(),
            "service_name": service_name,
            "action": "scale_up",
            "new_instance_id": new_instance_id,
        })
        
        return True
    
    async def _scale_down(self, service_name: str) -> bool:
        """缩容"""
        self.logger.info(f"Scaling down service: {service_name}")
        
        instances = await self.service_registry.get_service_instances(service_name)
        
        if instances:
            # 移除最后一个实例
            instance_to_remove = instances[-1]
            await self.service_registry.deregister_service(service_name, instance_to_remove.instance_id)
            
            self.scaling_history.append({
                "timestamp": datetime.utcnow(),
                "service_name": service_name,
                "action": "scale_down",
                "removed_instance_id": instance_to_remove.instance_id,
            })
            
            return True
        
        return False


# ============================================================================
# 主程序
# ============================================================================

async def main():
    """主程序"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    # 初始化系统
    service_registry = ServiceRegistry(logger)
    health_check_system = HealthCheckSystem(logger, service_registry)
    load_balancer = LoadBalancer(logger, service_registry)
    auto_scaling = AutoScalingSystem(logger, service_registry)
    
    logger.info("=== High Availability System Test ===")
    
    # 1. 注册服务实例
    for i in range(3):
        instance = ServiceInstance(
            instance_id=f"trading_service_{i}",
            service_name="trading_service",
            host="localhost",
            port=8000 + i,
        )
        await service_registry.register_service("trading_service", instance)
    
    # 2. 设置扩展策略
    auto_scaling.set_scaling_policy("trading_service", {
        "min_instances": 2,
        "max_instances": 10,
        "target_cpu_usage": 70,
        "scale_up_threshold": 80,
        "scale_down_threshold": 30,
    })
    
    # 3. 选择实例进行负载均衡
    for i in range(10):
        instance = await load_balancer.select_instance("trading_service", "192.168.1.1")
        if instance:
            logger.info(f"Request {i+1} routed to {instance.instance_id}")
            await load_balancer.release_instance(instance)
    
    # 4. 评估是否需要扩展
    should_scale = await auto_scaling.evaluate_scaling("trading_service")
    logger.info(f"Scaling evaluation result: {should_scale}")
    
    # 5. 获取健康实例
    healthy_instances = await service_registry.get_healthy_instances("trading_service")
    logger.info(f"Healthy instances: {len(healthy_instances)}")


if __name__ == "__main__":
    asyncio.run(main())
