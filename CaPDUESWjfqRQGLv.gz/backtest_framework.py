#!/usr/bin/env python3
"""
交易系统回测框架

功能：
1. 历史数据加载和回放
2. 交易信号生成和执行
3. 头寸管理和风控
4. 性能指标计算
5. 结果可视化
"""

import json
import numpy as np
import pandas as pd
from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple, Optional
from datetime import datetime, timedelta
from enum import Enum


class OrderType(Enum):
    """订单类型"""
    BUY = "buy"
    SELL = "sell"
    CLOSE = "close"


class OrderStatus(Enum):
    """订单状态"""
    PENDING = "pending"
    FILLED = "filled"
    CANCELLED = "cancelled"
    REJECTED = "rejected"


@dataclass
class Order:
    """订单数据结构"""
    order_id: str
    timestamp: datetime
    symbol: str
    order_type: OrderType
    quantity: float
    price: float
    status: OrderStatus = OrderStatus.PENDING
    filled_price: Optional[float] = None
    filled_quantity: Optional[float] = None
    commission: float = 0.0
    notes: str = ""
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "order_id": self.order_id,
            "timestamp": self.timestamp.isoformat(),
            "symbol": self.symbol,
            "order_type": self.order_type.value,
            "quantity": self.quantity,
            "price": self.price,
            "status": self.status.value,
            "filled_price": self.filled_price,
            "filled_quantity": self.filled_quantity,
            "commission": self.commission,
            "notes": self.notes
        }


@dataclass
class Position:
    """头寸数据结构"""
    symbol: str
    entry_time: datetime
    entry_price: float
    quantity: float
    side: str  # "long" or "short"
    exit_time: Optional[datetime] = None
    exit_price: Optional[float] = None
    pnl: float = 0.0
    pnl_pct: float = 0.0
    max_profit: float = 0.0
    max_loss: float = 0.0
    holding_days: int = 0
    notes: str = ""
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "symbol": self.symbol,
            "entry_time": self.entry_time.isoformat(),
            "entry_price": self.entry_price,
            "quantity": self.quantity,
            "side": self.side,
            "exit_time": self.exit_time.isoformat() if self.exit_time else None,
            "exit_price": self.exit_price,
            "pnl": self.pnl,
            "pnl_pct": self.pnl_pct,
            "max_profit": self.max_profit,
            "max_loss": self.max_loss,
            "holding_days": self.holding_days,
            "notes": self.notes
        }


@dataclass
class PortfolioSnapshot:
    """投资组合快照"""
    timestamp: datetime
    total_value: float
    cash: float
    positions_value: float
    open_positions: int
    closed_positions: int
    daily_pnl: float
    cumulative_pnl: float
    win_rate: float
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "timestamp": self.timestamp.isoformat(),
            "total_value": self.total_value,
            "cash": self.cash,
            "positions_value": self.positions_value,
            "open_positions": self.open_positions,
            "closed_positions": self.closed_positions,
            "daily_pnl": self.daily_pnl,
            "cumulative_pnl": self.cumulative_pnl,
            "win_rate": self.win_rate
        }


class BacktestConfig:
    """回测配置"""
    
    def __init__(self):
        self.initial_capital = 100.0  # 初始资金（USDT）
        self.commission_rate = 0.001  # 手续费率（0.1%）
        self.slippage_rate = 0.0005   # 滑点率（0.05%）
        self.max_position_size = 0.5  # 最大头寸占比（50%）
        self.max_open_positions = 5   # 最大开放头寸数
        self.stop_loss_pct = 2.5      # 止损百分比
        self.take_profit_pct = 4.5    # 止盈百分比
        self.daily_loss_limit = 1.0   # 日度亏损限制
        self.consecutive_loss_limit = 3  # 连续亏损限制
        
        # 信号参数
        self.ema_fast = 20
        self.ema_slow = 50
        self.vwap_lookback = 24
        
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "initial_capital": self.initial_capital,
            "commission_rate": self.commission_rate,
            "slippage_rate": self.slippage_rate,
            "max_position_size": self.max_position_size,
            "max_open_positions": self.max_open_positions,
            "stop_loss_pct": self.stop_loss_pct,
            "take_profit_pct": self.take_profit_pct,
            "daily_loss_limit": self.daily_loss_limit,
            "consecutive_loss_limit": self.consecutive_loss_limit,
            "ema_fast": self.ema_fast,
            "ema_slow": self.ema_slow,
            "vwap_lookback": self.vwap_lookback
        }
    
    @staticmethod
    def from_dict(config_dict: dict) -> 'BacktestConfig':
        """从字典创建配置"""
        config = BacktestConfig()
        for key, value in config_dict.items():
            if hasattr(config, key):
                setattr(config, key, value)
        return config


class BacktestPortfolio:
    """回测投资组合"""
    
    def __init__(self, config: BacktestConfig):
        self.config = config
        self.initial_capital = config.initial_capital
        self.cash = config.initial_capital
        self.open_positions: Dict[str, Position] = {}
        self.closed_positions: List[Position] = []
        self.orders: List[Order] = []
        self.snapshots: List[PortfolioSnapshot] = []
        self.daily_pnl_list: List[Tuple[datetime, float]] = []
        
    def get_total_value(self, current_prices: Dict[str, float]) -> float:
        """计算总资产价值"""
        positions_value = sum(
            pos.quantity * current_prices.get(pos.symbol, pos.entry_price)
            for pos in self.open_positions.values()
        )
        return self.cash + positions_value
    
    def get_positions_value(self, current_prices: Dict[str, float]) -> float:
        """计算头寸总价值"""
        return sum(
            pos.quantity * current_prices.get(pos.symbol, pos.entry_price)
            for pos in self.open_positions.values()
        )
    
    def get_cumulative_pnl(self) -> float:
        """计算累计 PnL"""
        closed_pnl = sum(pos.pnl for pos in self.closed_positions)
        return closed_pnl
    
    def get_win_rate(self) -> float:
        """计算胜率"""
        if not self.closed_positions:
            return 0.0
        wins = sum(1 for pos in self.closed_positions if pos.pnl > 0)
        return wins / len(self.closed_positions)
    
    def get_max_drawdown(self) -> float:
        """计算最大回撤"""
        if not self.snapshots:
            return 0.0
        
        values = [s.total_value for s in self.snapshots]
        peak = values[0]
        max_dd = 0.0
        
        for value in values:
            if value > peak:
                peak = value
            dd = (peak - value) / peak if peak > 0 else 0
            max_dd = max(max_dd, dd)
        
        return max_dd
    
    def get_sharpe_ratio(self, risk_free_rate: float = 0.02) -> float:
        """计算夏普比率"""
        if len(self.daily_pnl_list) < 2:
            return 0.0
        
        daily_returns = [pnl / self.initial_capital for _, pnl in self.daily_pnl_list]
        
        if not daily_returns:
            return 0.0
        
        mean_return = np.mean(daily_returns)
        std_return = np.std(daily_returns)
        
        if std_return == 0:
            return 0.0
        
        # 年化夏普比率（假设 252 个交易日）
        annual_return = mean_return * 252
        annual_std = std_return * np.sqrt(252)
        
        sharpe = (annual_return - risk_free_rate) / annual_std if annual_std > 0 else 0
        return sharpe
    
    def add_snapshot(self, timestamp: datetime, current_prices: Dict[str, float]):
        """添加投资组合快照"""
        total_value = self.get_total_value(current_prices)
        positions_value = self.get_positions_value(current_prices)
        cumulative_pnl = self.get_cumulative_pnl()
        
        # 计算日度 PnL
        if self.snapshots:
            daily_pnl = total_value - self.snapshots[-1].total_value
        else:
            daily_pnl = 0.0
        
        snapshot = PortfolioSnapshot(
            timestamp=timestamp,
            total_value=total_value,
            cash=self.cash,
            positions_value=positions_value,
            open_positions=len(self.open_positions),
            closed_positions=len(self.closed_positions),
            daily_pnl=daily_pnl,
            cumulative_pnl=cumulative_pnl,
            win_rate=self.get_win_rate()
        )
        
        self.snapshots.append(snapshot)
        self.daily_pnl_list.append((timestamp, daily_pnl))
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "initial_capital": self.initial_capital,
            "cash": self.cash,
            "open_positions": {k: v.to_dict() for k, v in self.open_positions.items()},
            "closed_positions": [p.to_dict() for p in self.closed_positions],
            "orders": [o.to_dict() for o in self.orders],
            "snapshots": [s.to_dict() for s in self.snapshots]
        }


class BacktestMetrics:
    """回测指标计算"""
    
    @staticmethod
    def calculate_metrics(portfolio: BacktestPortfolio) -> dict:
        """计算所有回测指标"""
        
        if not portfolio.snapshots:
            return {}
        
        # 基础指标
        total_trades = len(portfolio.closed_positions)
        winning_trades = sum(1 for p in portfolio.closed_positions if p.pnl > 0)
        losing_trades = total_trades - winning_trades
        win_rate = winning_trades / total_trades if total_trades > 0 else 0
        
        # 收益指标
        total_pnl = portfolio.get_cumulative_pnl()
        initial_capital = portfolio.initial_capital
        total_return = total_pnl / initial_capital if initial_capital > 0 else 0
        
        # 风险指标
        max_drawdown = portfolio.get_max_drawdown()
        sharpe_ratio = portfolio.get_sharpe_ratio()
        
        # 平均指标
        avg_pnl = total_pnl / total_trades if total_trades > 0 else 0
        avg_profit = sum(p.pnl for p in portfolio.closed_positions if p.pnl > 0) / winning_trades if winning_trades > 0 else 0
        avg_loss = sum(p.pnl for p in portfolio.closed_positions if p.pnl < 0) / losing_trades if losing_trades > 0 else 0
        
        # 风险收益比
        profit_factor = abs(avg_profit * winning_trades / (avg_loss * losing_trades)) if avg_loss != 0 and losing_trades > 0 else 0
        
        # 最大连续胜负
        max_consecutive_wins = BacktestMetrics._get_max_consecutive(portfolio.closed_positions, True)
        max_consecutive_losses = BacktestMetrics._get_max_consecutive(portfolio.closed_positions, False)
        
        return {
            "total_trades": total_trades,
            "winning_trades": winning_trades,
            "losing_trades": losing_trades,
            "win_rate": round(win_rate * 100, 2),
            "total_pnl": round(total_pnl, 2),
            "total_return": round(total_return * 100, 2),
            "max_drawdown": round(max_drawdown * 100, 2),
            "sharpe_ratio": round(sharpe_ratio, 2),
            "avg_pnl": round(avg_pnl, 2),
            "avg_profit": round(avg_profit, 2),
            "avg_loss": round(avg_loss, 2),
            "profit_factor": round(profit_factor, 2),
            "max_consecutive_wins": max_consecutive_wins,
            "max_consecutive_losses": max_consecutive_losses
        }
    
    @staticmethod
    def _get_max_consecutive(positions: List[Position], is_win: bool) -> int:
        """计算最大连续胜负"""
        max_consecutive = 0
        current_consecutive = 0
        
        for pos in positions:
            if (is_win and pos.pnl > 0) or (not is_win and pos.pnl < 0):
                current_consecutive += 1
                max_consecutive = max(max_consecutive, current_consecutive)
            else:
                current_consecutive = 0
        
        return max_consecutive


class BacktestDataSource:
    """回测数据源"""
    
    @staticmethod
    def generate_sample_data(symbol: str, days: int = 30) -> pd.DataFrame:
        """生成示例 OHLCV 数据"""
        dates = pd.date_range(end=datetime.now(), periods=days, freq='D')
        
        # 生成价格数据
        np.random.seed(42)
        close_prices = 100 + np.cumsum(np.random.randn(days) * 2)
        
        data = pd.DataFrame({
            'timestamp': dates,
            'symbol': symbol,
            'open': close_prices + np.random.randn(days) * 0.5,
            'high': close_prices + abs(np.random.randn(days) * 1),
            'low': close_prices - abs(np.random.randn(days) * 1),
            'close': close_prices,
            'volume': np.random.randint(1000000, 5000000, days)
        })
        
        return data
    
    @staticmethod
    def load_csv_data(filepath: str) -> pd.DataFrame:
        """从 CSV 加载数据"""
        df = pd.read_csv(filepath)
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        return df
    
    @staticmethod
    def load_json_data(filepath: str) -> pd.DataFrame:
        """从 JSON 加载数据"""
        with open(filepath, 'r') as f:
            data = json.load(f)
        df = pd.DataFrame(data)
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        return df


# 示例使用
if __name__ == "__main__":
    # 创建配置
    config = BacktestConfig()
    print("回测配置:")
    print(json.dumps(config.to_dict(), indent=2, ensure_ascii=False))
    
    # 创建投资组合
    portfolio = BacktestPortfolio(config)
    print("\n投资组合初始化完成")
    
    # 生成示例数据
    data = BacktestDataSource.generate_sample_data("BTCUSDT", days=30)
    print(f"\n生成了 {len(data)} 行数据")
    print(data.head())
